using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UIElements;
using YUCP.DevTools.Components;
using YUCP.DevTools.Editor.PackageExporter.UI.Components;
using YUCP.Motion;
using YUCP.Motion.Core;

namespace YUCP.DevTools.Editor.PackageExporter
{
    /// <summary>
    /// Represents a folder node in the hierarchical tree structure
    /// </summary>
    internal class FolderTreeNode
    {
        public string Name { get; set; }
        public string FullPath { get; set; }
        public List<FolderTreeNode> Children { get; set; } = new List<FolderTreeNode>();
        public List<DiscoveredAsset> Assets { get; set; } = new List<DiscoveredAsset>();
        public bool IsExpanded { get; set; } = true;
        
        public FolderTreeNode(string name, string fullPath)
        {
            Name = name;
            FullPath = fullPath;
        }
    }
    
    /// <summary>
    /// Represents a menu item in the toolbar
    /// </summary>
    internal struct ToolbarMenuItem
    {
        public string Label;
        public string Tooltip;
        public Action Callback;
        public bool IsSeparator;
        
        public static ToolbarMenuItem Separator()
        {
            return new ToolbarMenuItem { IsSeparator = true };
        }
    }
    
    /// <summary>
    /// Main Package Exporter window with profile management and batch export capabilities.
    /// Modern UI Toolkit implementation matching Package Guardian design system.
    /// </summary>
    public class YUCPPackageExporterWindow : EditorWindow
    {
        [MenuItem("Tools/YUCP/Package Exporter")]
        public static void ShowWindow()
        {
            var window = GetWindow<YUCPPackageExporterWindow>();
            var icon = AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.yucp.devtools/Resources/DevTools.png");
            window.titleContent = new GUIContent("YUCP Package Exporter", icon);
            window.minSize = new Vector2(800, 700); // Increased default window size
            window.Show();
        }
        
        // UI Elements
        private ScrollView _profileListScrollView;
        private ScrollView _rightPaneScrollView;
        private VisualElement _profileListContainer;
        private VisualElement _profileListContainerOverlay;
        private VisualElement _profileDetailsContainer;
        private VisualElement _emptyState;
        private VisualElement _bottomBar;
        private VisualElement _progressContainer;
        private YucpSidebar _sidebar;
        private YucpSidebar _sidebarOverlay;
        private VisualElement _progressFill;
        private VisualElement _bannerImageContainer;
        private VisualElement _bannerGradientOverlay;
        private VisualElement _metadataSection;
        private VisualElement _bannerContainer;
        private Button _changeBannerButton;
        private EventCallback<GeometryChangedEvent> _bannerButtonGeometryCallback;
        private Label _progressText;
        private VisualElement _multiSelectInfo;
        private Button _exportSelectedButton;
        private Button _exportAllButton;
        private VisualElement _supportToast;
        
        // Animated GIF support
        private Dictionary<string, AnimatedGifData> animatedGifs = new Dictionary<string, AnimatedGifData>();
        
        // Resizable inspector state
        private bool isResizingInspector = false;
        private float resizeStartY = 0f;
        private float resizeStartHeight = 0f;
        private VisualElement currentResizableContainer = null; // Track which container is being resized
        private Rect currentResizeRect = Rect.zero; // Store the resize rect for cursor
        
        // Resizable left pane state
        private bool isResizingLeftPane = false;
        private float resizeStartX = 0f;
        private float resizeStartWidth = 0f;
        private VisualElement _resizeHandle;
        private Rect currentLeftPaneResizeRect = Rect.zero; // Store the resize rect for cursor
        private const string LeftPaneWidthKey = "com.yucp.devtools.packageexporter.leftpanewidth";
        private const float DefaultLeftPaneWidth = 270f;
        private const float MinLeftPaneWidth = 150f;
        private const float MaxLeftPaneWidth = 600f;
        
        // State
        private List<ExportProfile> allProfiles = new List<ExportProfile>();
        private ExportProfile selectedProfile;
        private HashSet<int> selectedProfileIndices = new HashSet<int>();
        private int lastClickedProfileIndex = -1;
        private bool isExporting = false;
        private float currentProgress = 0f;
        private string currentStatus = "";
        
        // Drag-and-drop state
        private int draggingIndex = -1;
        private VisualElement draggingElement = null;
        private Vector2 dragOffset = Vector2.zero;
        private Vector2 dragStartPosition = Vector2.zero;
        private bool hasDragged = false;
        private const float DRAG_THRESHOLD = 5f; // Pixels to move before considering it a drag
        private int potentialDropIndex = -1; // Where the item would be dropped
        private Dictionary<VisualElement, MotionHandle> motionHandles = new Dictionary<VisualElement, MotionHandle>(); // Motion handles for smooth animations
        private Dictionary<int, float> rowGaps = new Dictionary<int, float>(); // Track gaps for smooth spacing animation (vFavorites approach)
        private float draggedItemY = 0f; // Y position of dragged item (absolute)
        private VisualElement draggedItemContainer = null; // Container for absolutely positioned dragged item
        private int draggingItemFromPageAtIndex = -1; // Original index of dragged item (vFavorites approach)
        private int insertDraggedItemAtIndex = -1; // Where item will be inserted (calculated from mouse position)
        // private float draggedItemHoldOffset = 0f; // Offset from mouse to item center when drag started (vFavorites approach) - kept for potential future use
        private int draggingVisualIndex = -1; // Visual index of dragged item in list
        
        // Stack-to-create folder state
        private VisualElement stackTargetElement = null;
        private int stackTargetIndex = -1;
        private double stackHoverStartTime = 0;
        private const double STACK_HOVER_THRESHOLD = 0.5; // 500ms
        private Vector2 stackHoverPosition = Vector2.zero;
        private const float STACK_POSITION_TOLERANCE = 15f; // pixels
        private bool isStackReady = false;
        
        // Delayed rename tracking
        private double lastPackageNameChangeTime = 0;
        private const double RENAME_DELAY_SECONDS = 1.5;
        private ExportProfile pendingRenameProfile = null;
        private string pendingRenamePackageName = "";
        
        // Folder renaming state
        private string folderBeingRenamed = null;
        // Client ID provided by the user for fetching official product icons
        private const string BrandfetchClientId = "1bxid64Mup7aczewSAYMX";
        
        // Export Inspector state
        private string inspectorSearchFilter = "";
        private bool showOnlyIncluded = false;
        private bool showOnlyExcluded = false;
        private bool showExportInspector = true;
		private bool showOnlyDerived = false;
        private string sourceProfileFilter = "All";
        private Dictionary<string, bool> folderExpandedStates = new Dictionary<string, bool>();
        
        // Exclusion Filters state
        private bool showExclusionFilters = false;
        
        // Dependencies filter state
        private string dependenciesSearchFilter = "";
        
        // Profile list sort and filter state
        private enum ProfileSortOption
        {
            Name,
            Version,
            LastExportDate
        }
        
        private ProfileSortOption currentSortOption = ProfileSortOption.Name;
        private List<string> selectedFilterTags = new List<string>();
        private string selectedFilterFolder = null; // null means "All Folders"
        private string _currentSearchText = "";
        private YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField _mainSearchField;
        private YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField _overlaySearchField;
        
        // Collapsible section states
        private bool showExportOptions = true;
        private bool showFolders = true;
        private bool showDependencies = true;
        private bool showQuickActions = true;
        
        private Texture2D logoTexture;
        private Texture2D bannerGradientTexture;
        private Texture2D dottedBorderTexture;
        
        private const float BannerHeight = 410f;
        private const string DefaultGridPlaceholderPath = "Packages/com.yucp.devtools/Resources/DefaultGrid.png";
        
        // Responsive design elements
        private Button _mobileToggleButton;
        private VisualElement _leftPaneOverlay;
        private VisualElement _overlayBackdrop;
        private VisualElement _contentContainer;
        private VisualElement _leftPane;
        private bool _isOverlayOpen = false;

        // Support banner prefs (devtools scope)
        private const string SupportUrl = "http://patreon.com/Yeusepe";
        private const string SupportPrefNeverKey = "com.yucp.devtools.support.never";
        private const string SupportPrefCounterKey = "com.yucp.devtools.support.counter";
        private const string SupportPrefCadenceKey = "com.yucp.devtools.support.cadence"; // optional override
        private const string SupportSessionDismissKey = "com.yucp.devtools.support.dismissed.session";
        
        // Package reordering prefs
        private const string PackageOrderKey = "com.yucp.devtools.packageexporter.order";
        private const string PackageFoldersKey = "com.yucp.devtools.packageexporter.folders";
        private const string UnifiedOrderKey = "com.yucp.devtools.packageexporter.unifiedorder";
        private const string UnifiedOrderMigratedKey = "com.yucp.devtools.packageexporter.unifiedorder.migrated";
        
        // Folder state
        private List<string> projectFolders = new List<string>();
        private HashSet<string> collapsedFolders = new HashSet<string>();
        private const string CollapsedFoldersKey = "com.yucp.devtools.packageexporter.collapsedfolders";
        
        // Unified order (profiles and folders mixed)
        private List<UnifiedOrderItem> unifiedOrder = new List<UnifiedOrderItem>();

        private void OnEnable()
        {
            // Initialize Motion system
            global::YUCP.Motion.Motion.Initialize();
            
            LoadProfiles();
            LoadProjectFolders();
            LoadResources();
            
            // Migrate to unified order if needed
            MigrateToUnifiedOrder();
            LoadUnifiedOrder();
            
            // Refresh dependencies on domain reload
            EditorApplication.delayCall += RefreshDependenciesOnDomainReload;
            
            // Register update for gap animation (vFavorites approach)
            EditorApplication.update -= UpdateGapAnimations;
            EditorApplication.update += UpdateGapAnimations;
        }
        
        private void OnDisable()
        {
            EditorApplication.update -= UpdateGapAnimations;
        }
        
        private void RefreshDependenciesOnDomainReload()
        {
            // Refresh dependencies for all profiles that have dependencies configured
            if (selectedProfile != null && selectedProfile.dependencies.Count > 0)
            {
                // Silently refresh dependencies to pick up newly installed packages
                ScanProfileDependencies(selectedProfile, silent: true);
            }
        }
        
        private void LoadResources()
        {
            logoTexture = AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.yucp.devtools/Resources/DevTools.png");
            CreateBannerGradientTexture();
            CreateDottedBorderTexture();
        }
        
        private static bool IsDefaultGridPlaceholder(Texture2D texture)
        {
            if (texture == null) return false;
            string assetPath = AssetDatabase.GetAssetPath(texture);
            return assetPath == DefaultGridPlaceholderPath;
        }
        
        private static Texture2D GetPlaceholderTexture()
        {
            return AssetDatabase.LoadAssetAtPath<Texture2D>(DefaultGridPlaceholderPath);
        }
        
        private void CreateBannerGradientTexture()
        {
            if (bannerGradientTexture != null)
            {
                UnityEngine.Object.DestroyImmediate(bannerGradientTexture);
            }
            
            int width = 1;
            int height = Mathf.RoundToInt(BannerHeight);
            bannerGradientTexture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            
            // Configurable gradient parameters
            float segment1End = 0.3f;  // Top segment ends at 30% (was 20%)
            float segment2End = 0.7f;  // Middle segment ends at 70% (was 60%)
            float alpha1 = 0.2f;        // First segment alpha (was 0.3f)
            float alpha2 = 0.6f;        // Second segment alpha (was 0.8f)
            float alpha3 = 1.0f;
            
            for (int y = 0; y < height; y++)
            {
                float t = (float)y / (height - 1);
                Color color;
                
                if (t < segment1End)
                {
                    float localT = t / segment1End;
                    color = new Color(0.082f, 0.082f, 0.082f, Mathf.Lerp(0f, alpha1, localT));
                }
                else if (t < segment2End)
                {
                    float localT = (t - segment1End) / (segment2End - segment1End);
                    color = new Color(0.082f, 0.082f, 0.082f, Mathf.Lerp(alpha1, alpha2, localT));
                }
                else
                {
                    float localT = (t - segment2End) / (1.0f - segment2End);
                    color = new Color(0.082f, 0.082f, 0.082f, Mathf.Lerp(alpha2, alpha3, localT));
                }
                
                for (int x = 0; x < width; x++)
                {
                    bannerGradientTexture.SetPixel(x, height - 1 - y, color);
                }
            }
            
            bannerGradientTexture.Apply();
        }
        
        private void CreateDottedBorderTexture()
        {
            int size = 16;
            dottedBorderTexture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            
            Color transparent = new Color(0, 0, 0, 0);
            Color teal = new Color(54f / 255f, 191f / 255f, 177f / 255f, 0.6f);
            
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    bool isBorder = (x == 0 || x == size - 1 || y == 0 || y == size - 1);
                    bool isDot = isBorder && ((x % 4 < 2 && y == 0) || (x % 4 < 2 && y == size - 1) || 
                                              (y % 4 < 2 && x == 0) || (y % 4 < 2 && x == size - 1));
                    dottedBorderTexture.SetPixel(x, y, isDot ? teal : transparent);
                }
            }
            
            dottedBorderTexture.Apply();
            dottedBorderTexture.wrapMode = TextureWrapMode.Repeat;
        }
        
        private void OnGUI()
        {
            // Handle cursor changes for resize handle
            // Use the stored rect instead of worldBound to avoid coordinate issues
            if (!currentResizeRect.Equals(Rect.zero) && !isResizingInspector)
            {
                EditorGUIUtility.AddCursorRect(currentResizeRect, MouseCursor.ResizeVertical);
            }
            
            // Handle cursor for left pane resize handle
            if (!currentLeftPaneResizeRect.Equals(Rect.zero) && !isResizingLeftPane)
            {
                EditorGUIUtility.AddCursorRect(currentLeftPaneResizeRect, MouseCursor.ResizeHorizontal);
            }
        }
        
        private void CreateGUI()
        {
            var root = rootVisualElement;
            root.AddToClassList("yucp-window");
            
            // Load shared design system stylesheet first
            var sharedStyleSheet = AssetDatabase.LoadAssetAtPath<StyleSheet>(
                "Packages/com.yucp.devtools/Editor/Styles/YucpDesignSystem.uss");
            if (sharedStyleSheet != null)
            {
                root.styleSheets.Add(sharedStyleSheet);
            }
            
            // Load component-specific stylesheet
            var styleSheet = AssetDatabase.LoadAssetAtPath<StyleSheet>(
                "Packages/com.yucp.devtools/Editor/PackageExporter/Styles/PackageExporter.uss");
            if (styleSheet != null)
            {
                root.styleSheets.Add(styleSheet);
            }
            
            // Main container
            var mainContainer = new VisualElement();
            mainContainer.AddToClassList("yucp-main-container");
            
            // Top Bar
            mainContainer.Add(CreateTopBar());

            // Content Container (Left + Right Panes)
            _contentContainer = new VisualElement();
            _contentContainer.AddToClassList("yucp-content-container");
            
            // Create overlay backdrop (for mobile menu)
            _overlayBackdrop = new VisualElement();
            _overlayBackdrop.AddToClassList("yucp-overlay-backdrop");
            _overlayBackdrop.RegisterCallback<ClickEvent>(evt => CloseOverlay());
            _overlayBackdrop.style.display = DisplayStyle.None;
            _overlayBackdrop.style.visibility = Visibility.Hidden;
            _contentContainer.Add(_overlayBackdrop);
            
            // Load saved width or use default (shared between overlay and normal pane)
            float savedWidth = EditorPrefs.GetFloat(LeftPaneWidthKey, DefaultLeftPaneWidth);
            savedWidth = Mathf.Clamp(savedWidth, MinLeftPaneWidth, MaxLeftPaneWidth);
            
            // Create left pane overlay (for mobile)
            _leftPaneOverlay = CreateLeftPane(isOverlay: true);
            _leftPaneOverlay.AddToClassList("yucp-left-pane-overlay");
            // Use the same width as the normal left pane
            _leftPaneOverlay.style.width = new Length(savedWidth, LengthUnit.Pixel);
            _leftPaneOverlay.style.minWidth = MinLeftPaneWidth;
            _leftPaneOverlay.style.maxWidth = MaxLeftPaneWidth;
            _leftPaneOverlay.style.display = DisplayStyle.None;
            _leftPaneOverlay.style.visibility = Visibility.Hidden;
            _contentContainer.Add(_leftPaneOverlay);
            
            // Create normal left pane
            _leftPane = CreateLeftPane(isOverlay: false);
            _leftPane.style.width = new Length(savedWidth, LengthUnit.Pixel);
            _leftPane.style.minWidth = MinLeftPaneWidth;
            _leftPane.style.maxWidth = MaxLeftPaneWidth;
            _leftPane.style.flexShrink = 0;
            _leftPane.style.flexGrow = 0;
            _contentContainer.Add(_leftPane);
            
            // Create resize handle between left and right panes
            _resizeHandle = new VisualElement();
            _resizeHandle.AddToClassList("yucp-resize-handle");
            _resizeHandle.style.width = 4f;
            _resizeHandle.style.flexShrink = 0;
            _resizeHandle.style.cursor = new StyleCursor(StyleKeyword.None);
            _resizeHandle.pickingMode = PickingMode.Position;
            
            // Setup resize handle mouse events
            SetupLeftPaneResizeHandle();
            
            _contentContainer.Add(_resizeHandle);
            
            _contentContainer.Add(CreateRightPane());
            mainContainer.Add(_contentContainer);
            
            // Bottom Bar
            _bottomBar = CreateBottomBar();
            mainContainer.Add(_bottomBar);
            
            root.Add(mainContainer);
            
            // Optional non-intrusive support toast (appears rarely)
            _supportToast = CreateSupportToast();
            if (_supportToast != null)
            {
                // Start hidden for fade-in animation
                _supportToast.style.opacity = 0;
                _supportToast.style.translate = new Translate(0, -20);
                
                root.Add(_supportToast);
                
                // Animate in
                root.schedule.Execute(() => {
                    if (_supportToast != null)
                    {
                        _supportToast.style.opacity = 1;
                        _supportToast.style.translate = new Translate(0, 0);
                    }
                }).StartingIn(100);
            }
            
            // Schedule delayed rename checks
            root.schedule.Execute(CheckDelayedRename).Every(100);
            
            // Initial UI update
            UpdateProfileList();
            UpdateBottomBar();
            
            // Register for geometry changes to handle responsive layout
            root.RegisterCallback<GeometryChangedEvent>(OnGeometryChanged);
            
            // Schedule initial responsive check after layout is ready
            root.schedule.Execute(() => 
            {
                UpdateResponsiveLayout(rootVisualElement.resolvedStyle.width);
            }).StartingIn(100);
        }

        private VisualElement CreateBannerSection(ExportProfile profile)
        {
            var bannerContainer = new VisualElement();
            bannerContainer.AddToClassList("yucp-banner-container");
            _bannerContainer = bannerContainer;
            
            bannerContainer.style.position = Position.Relative;
            bannerContainer.style.height = BannerHeight;
            bannerContainer.style.marginBottom = 0;
            bannerContainer.style.width = Length.Percent(100);
            bannerContainer.style.paddingLeft = 0;
            bannerContainer.style.paddingRight = 0;
            bannerContainer.style.paddingTop = 0;
            bannerContainer.style.paddingBottom = 0;
            bannerContainer.style.flexShrink = 0;
            bannerContainer.style.overflow = Overflow.Visible;
            
            _bannerImageContainer = new VisualElement();
            _bannerImageContainer.AddToClassList("yucp-banner-image-container");
            _bannerImageContainer.style.position = Position.Absolute;
            _bannerImageContainer.style.top = 0;
            _bannerImageContainer.style.left = 0;
            _bannerImageContainer.style.right = 0;
            _bannerImageContainer.style.bottom = 0;
            Texture2D displayBanner = profile?.banner;
            if (displayBanner == null)
            {
                displayBanner = GetPlaceholderTexture();
            }
            if (displayBanner != null)
            {
                _bannerImageContainer.style.backgroundImage = new StyleBackground(displayBanner);
                
                // Check if banner is a GIF and animate it
                string bannerPath = AssetDatabase.GetAssetPath(displayBanner);
                if (!string.IsNullOrEmpty(bannerPath) && bannerPath.EndsWith(".gif", StringComparison.OrdinalIgnoreCase))
                {
                    StartGifAnimation(_bannerImageContainer, bannerPath);
                }
            }
            bannerContainer.Add(_bannerImageContainer);
            
            _bannerGradientOverlay = new VisualElement();
            _bannerGradientOverlay.AddToClassList("yucp-banner-gradient-overlay");
            _bannerGradientOverlay.style.position = Position.Absolute;
            _bannerGradientOverlay.style.top = 0;
            _bannerGradientOverlay.style.left = 0;
            _bannerGradientOverlay.style.right = 0;
            _bannerGradientOverlay.style.bottom = -10;
            if (bannerGradientTexture != null)
            {
                _bannerGradientOverlay.style.backgroundImage = new StyleBackground(bannerGradientTexture);
            }
            // Gradient overlay needs to receive pointer events for hover detection but allow button clicks to pass through
            _bannerGradientOverlay.pickingMode = PickingMode.Position;
            // Add as sibling so it can use its own parallax factor
            bannerContainer.Add(_bannerGradientOverlay);
            
            // Button will be added to _profileDetailsContainer after contentWrapper
            // so it's on top of everything
            
            return bannerContainer;
        }
        
        private void UpdateBannerButtonPosition()
        {
            if (_changeBannerButton == null || _bannerContainer == null || _metadataSection == null || _rightPaneScrollView == null)
                return;
            
            var bannerWidth = _bannerContainer.resolvedStyle.width;
            var buttonWidth = _changeBannerButton.resolvedStyle.width;
            var buttonHeight = 24f;
            
            if (bannerWidth <= 0 || buttonWidth <= 0)
                return;
            
            // Get world positions to calculate button position relative to ScrollView
            var bannerBounds = _bannerContainer.worldBound;
            var metadataBounds = _metadataSection.worldBound;
            var scrollViewBounds = _rightPaneScrollView.worldBound;
            
            // Calculate metadata section position relative to banner
            // contentWrapper has marginTop = -400, banner height is 410
            // Metadata section is the first element in contentWrapper
            var metadataTop = 10f;
            
            if (bannerBounds.y >= 0 && metadataBounds.y >= 0)
            {
                // Calculate the difference in world Y coordinates
                var relativeTop = metadataBounds.y - bannerBounds.y;
                if (relativeTop > 0 && relativeTop < BannerHeight)
                {
                    metadataTop = relativeTop;
                }
            }
            
            // Ensure metadataTop is not negative or zero
            if (metadataTop <= 0)
                metadataTop = 10f;
            
            // Center vertically between top of banner and metadata section top
            var centerYInBanner = metadataTop / 2f;
            
            // Calculate button position relative to ScrollView
            var buttonY = bannerBounds.y - scrollViewBounds.y + centerYInBanner - (buttonHeight / 2f);
            var buttonX = bannerBounds.x - scrollViewBounds.x + (bannerWidth - buttonWidth) / 2f;
            
            _changeBannerButton.style.left = buttonX;
            _changeBannerButton.style.top = buttonY;
        }
        
        private void SetupParallaxScrolling()
        {
            if (_rightPaneScrollView == null) return;
            if (_bannerImageContainer == null && _bannerGradientOverlay == null) return;
            
            // Separate parallax speeds so image and gradient can move differently than the content
            // and differently from each other.
            const float imageParallaxSpeed = 0.07f;
            const float gradientParallaxSpeed = 0.069f;
            
            Action<float> updateParallax = (scrollY) =>
            {
                // Image offset: container moves at (1 - speed) of scroll
                if (_bannerImageContainer != null)
                {
                    var imageOffset = scrollY * (1.0f - imageParallaxSpeed);
                    _bannerImageContainer.style.translate = new StyleTranslate(new Translate(0, imageOffset));
                }
                
                // Gradient offset: independent speed so it can drift differently
                if (_bannerGradientOverlay != null)
                {
                    var gradientOffset = scrollY * (1.0f - gradientParallaxSpeed);
                    _bannerGradientOverlay.style.translate = new StyleTranslate(new Translate(0, gradientOffset));
                }
            };
            
            var verticalScroller = _rightPaneScrollView.verticalScroller;
            if (verticalScroller != null)
            {
                verticalScroller.valueChanged += (value) =>
                {
                    updateParallax(value);
                };
                
                // Set initial position
                updateParallax(verticalScroller.value);
            }
            
            // Also use scheduled callback as backup for continuous updates
            _rightPaneScrollView.schedule.Execute(() =>
            {
                if (_rightPaneScrollView == null) return;
                if (_bannerImageContainer == null && _bannerGradientOverlay == null) return;
                
                // Get current scroll position
                var scrollOffset = _rightPaneScrollView.scrollOffset;
                var scrollY = scrollOffset.y;
                
                updateParallax(scrollY);
            }).Every(16); // Update approximately every frame (60fps = ~16ms per frame)
        }
        
        private void EndResize()
        {
            if (!isResizingLeftPane) return;
            
            isResizingLeftPane = false;
            if (_resizeHandle != null && _resizeHandle.HasMouseCapture())
            {
                _resizeHandle.ReleaseMouse();
            }
            
            // Save the new width to EditorPrefs
            if (_leftPane != null)
            {
                float finalWidth = _leftPane.resolvedStyle.width;
                if (finalWidth <= 0)
                {
                    finalWidth = _leftPane.layout.width;
                }
                if (finalWidth > 0)
                {
                    EditorPrefs.SetFloat(LeftPaneWidthKey, finalWidth);
                }
            }
            
            currentLeftPaneResizeRect = Rect.zero;
        }
        
        private void SetupLeftPaneResizeHandle()
        {
            if (_resizeHandle == null || _leftPane == null) return;
            
            // Update resize rect for cursor when mouse moves over handle
            _resizeHandle.RegisterCallback<MouseEnterEvent>(evt =>
            {
                if (!isResizingLeftPane)
                {
                    var worldBounds = _resizeHandle.worldBound;
                    currentLeftPaneResizeRect = worldBounds;
                }
            });
            
            _resizeHandle.RegisterCallback<MouseLeaveEvent>(evt =>
            {
                if (!isResizingLeftPane)
                {
                    currentLeftPaneResizeRect = Rect.zero;
                }
            });
            
            // Start resizing on mouse down
            _resizeHandle.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button == 0) // Left mouse button
                {
                    isResizingLeftPane = true;
                    // Use world position for consistent tracking
                    var paneWorldBound = _leftPane.worldBound;
                    resizeStartX = evt.mousePosition.x;
                    float currentWidth = _leftPane.resolvedStyle.width;
                    if (currentWidth <= 0)
                    {
                        currentWidth = _leftPane.layout.width;
                    }
                    if (currentWidth <= 0 && paneWorldBound.width > 0)
                    {
                        currentWidth = paneWorldBound.width;
                    }
                    resizeStartWidth = currentWidth;
                    _resizeHandle.CaptureMouse();
                    evt.StopPropagation();
                }
            });
            
            // Update resize width - helper method for responsiveness
            System.Action<Vector2> updateResizeWidth = (mousePosition) =>
            {
                if (!isResizingLeftPane || !_resizeHandle.HasMouseCapture()) return;
                
                float deltaX = mousePosition.x - resizeStartX;
                float newWidth = resizeStartWidth + deltaX;
                newWidth = Mathf.Clamp(newWidth, MinLeftPaneWidth, MaxLeftPaneWidth);
                
                // Update left pane width immediately
                _leftPane.style.width = new Length(newWidth, LengthUnit.Pixel);
                _leftPane.style.flexShrink = 0;
                _leftPane.style.flexGrow = 0;
                
                // Force immediate repaint updates (layout will be recalculated automatically)
                _leftPane.MarkDirtyRepaint();
                
                // Also mark parent container for repaint
                if (_contentContainer != null)
                {
                    _contentContainer.MarkDirtyRepaint();
                }
                
                // Force immediate repaint of the window
                Repaint();
            };
            
            // Handle mouse move during resize - using both local and capture events for best tracking
            _resizeHandle.RegisterCallback<MouseMoveEvent>(evt =>
            {
                if (isResizingLeftPane && _resizeHandle.HasMouseCapture())
                {
                    updateResizeWidth(evt.mousePosition);
                    evt.StopPropagation();
                }
                else if (!isResizingLeftPane)
                {
                    // Update resize rect when hovering
                    var worldBounds = _resizeHandle.worldBound;
                    if (!worldBounds.Equals(Rect.zero))
                    {
                        currentLeftPaneResizeRect = worldBounds;
                    }
                }
            });
            
            // Also register on root for better tracking when mouse leaves the handle
            if (rootVisualElement != null)
            {
                rootVisualElement.RegisterCallback<MouseMoveEvent>(evt =>
                {
                    if (isResizingLeftPane && _resizeHandle.HasMouseCapture())
                    {
                        updateResizeWidth(evt.mousePosition);
                        evt.StopPropagation();
                    }
                }, TrickleDown.TrickleDown);
            }
            
            // End resizing on mouse up
            _resizeHandle.RegisterCallback<MouseUpEvent>(evt =>
            {
                if (evt.button == 0 && isResizingLeftPane)
                {
                    EndResize();
                    evt.StopPropagation();
                }
            });
            
            // Also handle mouse up on the root to ensure we release mouse capture even if mouse leaves handle
            if (rootVisualElement != null)
            {
                rootVisualElement.RegisterCallback<MouseUpEvent>(evt =>
                {
                    if (evt.button == 0 && isResizingLeftPane)
                    {
                        EndResize();
                    }
                });
            }
        }
        
        private void ForceBannerFullWidth()
        {
            if (_rightPaneScrollView == null || _profileDetailsContainer == null) return;
            
            var bannerWrapper = _profileDetailsContainer.Q("banner-wrapper-fullwidth");
            if (bannerWrapper == null) return;
            
            // Access ScrollView's content viewport to allow overflow
            var contentViewport = _rightPaneScrollView.Q(className: "unity-scroll-view__content-viewport");
            if (contentViewport != null)
            {
                contentViewport.style.overflow = Overflow.Visible;
            }
            
            // Get the right pane (parent of ScrollView) for full width
            var rightPane = _rightPaneScrollView?.parent;
            if (rightPane != null)
            {
                var paneWidth = rightPane.resolvedStyle.width;
                if (paneWidth > 0)
                {
                    // Set wrapper to full pane width and use negative margins to break out
                    bannerWrapper.style.position = Position.Relative;
                    bannerWrapper.style.width = paneWidth;
                    bannerWrapper.style.minWidth = paneWidth;
                    bannerWrapper.style.maxWidth = paneWidth;
                    bannerWrapper.style.marginLeft = -20;
                    bannerWrapper.style.marginRight = -24;
                    bannerWrapper.style.marginTop = -20;
                    bannerWrapper.style.marginBottom = 0;
                    bannerWrapper.style.paddingLeft = 0;
                    bannerWrapper.style.paddingRight = 0;
                    bannerWrapper.style.paddingTop = 0;
                    bannerWrapper.style.paddingBottom = 0;
                    bannerWrapper.style.left = 0;
                    bannerWrapper.style.flexShrink = 0;
                    
                    // Set banner container to match wrapper width
                    var bannerContainer = bannerWrapper.Q(className: "yucp-banner-container");
                    if (bannerContainer != null)
                    {
                        bannerContainer.style.width = paneWidth;
                        bannerContainer.style.minWidth = paneWidth;
                        bannerContainer.style.maxWidth = paneWidth;
                        bannerContainer.style.marginLeft = 0;
                        bannerContainer.style.marginRight = 0;
                        bannerContainer.style.marginTop = 0;
                    }
                }
            }
        }
        
        private void OnChangeBannerClicked(ExportProfile profile)
        {
            if (profile == null)
            {
                EditorUtility.DisplayDialog("No Profile", "Cannot change banner for this profile.", "OK");
                return;
            }
            
            string bannerPath = EditorUtility.OpenFilePanel("Select Banner Image", "", "png,jpg,jpeg,gif");
            if (!string.IsNullOrEmpty(bannerPath))
            {
                string projectPath = "Assets/YUCP/ExportProfiles/Banners/";
                if (!AssetDatabase.IsValidFolder("Assets/YUCP/ExportProfiles/Banners"))
                {
                    if (!AssetDatabase.IsValidFolder("Assets/YUCP"))
                        AssetDatabase.CreateFolder("Assets", "YUCP");
                    if (!AssetDatabase.IsValidFolder("Assets/YUCP/ExportProfiles"))
                        AssetDatabase.CreateFolder("Assets/YUCP", "ExportProfiles");
                    AssetDatabase.CreateFolder("Assets/YUCP/ExportProfiles", "Banners");
                }
                
                string fileName = Path.GetFileName(bannerPath);
                string targetPath = projectPath + fileName;
                
                File.Copy(bannerPath, targetPath, true);
                AssetDatabase.ImportAsset(targetPath);
                AssetDatabase.Refresh();
                
                profile.banner = AssetDatabase.LoadAssetAtPath<Texture2D>(targetPath);
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                
                UpdateProfileDetails();
            }
        }
        
        private VisualElement CreateTopBar()
        {
            var topBar = new VisualElement();
            topBar.AddToClassList("yucp-top-bar");
            
            // Mobile toggle button (hamburger menu)
            _mobileToggleButton = new Button(ToggleOverlay);
            _mobileToggleButton.text = "≡";
            _mobileToggleButton.AddToClassList("yucp-mobile-toggle");
            topBar.Add(_mobileToggleButton);
            
            
            // Logo image
            var packageLogo = AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.yucp.devtools/Resources/Icons/PackageLogo.png");
            if (packageLogo != null)
            {
                var logo = new VisualElement();
                logo.AddToClassList("yucp-package-logo");
                logo.style.backgroundImage = new StyleBackground(packageLogo);
                topBar.Add(logo);
            }
            
            // Spacer to push buttons to the right
            var spacer = new VisualElement();
            spacer.AddToClassList("yucp-menu-spacer");
            topBar.Add(spacer);
            
            // Menu button groups
            topBar.Add(CreateMenuButtonGroup());
            
            return topBar;
        }
        
        private VisualElement CreateMenuButtonGroup()
        {
            var container = new VisualElement();
            container.AddToClassList("yucp-menu-button-group");
            
            // Export dropdown button
            var exportButton = CreateDropdownButton("Export", GetExportMenuItems());
            container.Add(exportButton);
            
            // Texture Array Builder
            container.Add(CreateActionButton("Texture", "Open Texture Array Builder", () => {
                var windowType = System.Type.GetType("YUCP.DevTools.Editor.TextureArrayBuilder.TextureArrayBuilderWindow, yucp.devtools.Editor");
                if (windowType != null)
                {
                    var method = windowType.GetMethod("ShowWindow", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                    method?.Invoke(null, null);
                }
            }));
            
            // Utilities dropdown
            var utilitiesButton = CreateDropdownButton("Utilities", GetUtilitiesMenuItems());
            container.Add(utilitiesButton);
            
            // Debug dropdown
            var debugButton = CreateDropdownButton("Debug", GetDebugMenuItems());
            container.Add(debugButton);
            
            return container;
        }
        
        private Button CreateActionButton(string label, string tooltip, Action callback)
        {
            var button = new Button(callback);
            button.text = label;
            button.tooltip = tooltip;
            button.AddToClassList("yucp-menu-button");
            return button;
        }
        
        private Button CreateHoverOverlayButton(string text, Action onClick, VisualElement parentContainer)
        {
            var button = new Button(onClick);
            button.text = text;
            button.AddToClassList("yucp-overlay-hover-button");
            button.style.display = DisplayStyle.Flex;
            button.pickingMode = PickingMode.Ignore;
            
            parentContainer.RegisterCallback<MouseEnterEvent>(evt =>
            {
                button.AddToClassList("yucp-overlay-hover-button-visible");
                button.pickingMode = PickingMode.Position;
            });
            parentContainer.RegisterCallback<MouseLeaveEvent>(evt =>
            {
                button.RemoveFromClassList("yucp-overlay-hover-button-visible");
                button.pickingMode = PickingMode.Ignore;
            });
            
            parentContainer.Add(button);
            return button;
        }
        
        private Button CreateDropdownButton(string label, List<ToolbarMenuItem> items)
        {
            var button = new Button();
            button.clicked += () => ShowDropdownMenu(button, items);
            button.text = label + " ▼";
            button.AddToClassList("yucp-menu-button");
            button.AddToClassList("yucp-menu-dropdown");
            return button;
        }
        
        private void ShowDropdownMenu(VisualElement anchor, List<ToolbarMenuItem> items)
        {
            var menu = new GenericMenu();
            
            foreach (var item in items)
            {
                if (item.IsSeparator)
                {
                    menu.AddSeparator("");
                }
                else
                {
                    menu.AddItem(new GUIContent(item.Label), false, () => item.Callback?.Invoke());
                }
            }
            
            menu.ShowAsContext();
        }
        
        private List<ToolbarMenuItem> GetExportMenuItems()
        {
            return new List<ToolbarMenuItem>
            {
                new ToolbarMenuItem
                {
                    Label = "Export Selected",
                    Tooltip = "Export selected profile(s)",
                    Callback = () => ExportSelectedProfiles()
                },
                new ToolbarMenuItem
                {
                    Label = "Export All",
                    Tooltip = "Export all profiles",
                    Callback = () => ExportAllProfiles()
                },
                ToolbarMenuItem.Separator(),
                new ToolbarMenuItem
                {
                    Label = "Quick Export Current",
                    Tooltip = "Quick export the currently selected profile",
                    Callback = () => {
                        if (selectedProfile != null)
                        {
                            ExportProfile(selectedProfile);
                        }
                    }
                }
            };
        }
        
        private List<ToolbarMenuItem> GetUtilitiesMenuItems()
        {
            return new List<ToolbarMenuItem>
            {
                new ToolbarMenuItem
                {
                    Label = "Create Export Profile",
                    Tooltip = "Create a new export profile",
                    Callback = () => MenuItems.CreateExportProfileFromMenu()
                },
                new ToolbarMenuItem
                {
                    Label = "Open Profiles Folder",
                    Tooltip = "Open the export profiles folder",
                    Callback = () => MenuItems.OpenExportProfilesFolder()
                },
                ToolbarMenuItem.Separator(),
                new ToolbarMenuItem
                {
                    Label = "Check ConfuserEx Installation",
                    Tooltip = "Check if ConfuserEx is installed",
                    Callback = () => MenuItems.CheckConfuserExInstallation()
                },
                new ToolbarMenuItem
                {
                    Label = "Scan for @bump Directives",
                    Tooltip = "Scan project for version bump directives",
                    Callback = () => MenuItems.ScanProjectForVersionDirectives()
                }
            };
        }
        
        private List<ToolbarMenuItem> GetDebugMenuItems()
        {
            return new List<ToolbarMenuItem>
            {
                new ToolbarMenuItem
                {
                    Label = "Derived FBX Debug",
                    Tooltip = "Open Derived FBX Debug window",
                    Callback = () => {
                        var windowType = System.Type.GetType("YUCP.DevTools.Editor.PackageExporter.DerivedFbxDebugWindow, yucp.devtools.Editor");
                        if (windowType != null)
                        {
                            var method = windowType.GetMethod("ShowWindow", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                            method?.Invoke(null, null);
                        }
                    }
                },
                ToolbarMenuItem.Separator(),
                new ToolbarMenuItem
                {
                    Label = "Validate Install",
                    Tooltip = "Validate YUCP installation",
                    Callback = () => {
                        var menuItemsType = System.Type.GetType("YUCP.DevTools.Editor.PackageExporter.Templates.InstallerHealthTools, yucp.devtools.Editor");
                        if (menuItemsType != null)
                        {
                            var method = menuItemsType.GetMethod("ValidateInstall", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                            method?.Invoke(null, null);
                        }
                    }
                },
                new ToolbarMenuItem
                {
                    Label = "Repair Install",
                    Tooltip = "Repair YUCP installation",
                    Callback = () => {
                        var menuItemsType = System.Type.GetType("YUCP.DevTools.Editor.PackageExporter.Templates.InstallerHealthTools, yucp.devtools.Editor");
                        if (menuItemsType != null)
                        {
                            var method = menuItemsType.GetMethod("RepairInstall", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                            method?.Invoke(null, null);
                        }
                    }
                }
            };
        }

        private VisualElement CreateSupportToast()
        {
            if (EditorPrefs.GetBool(SupportPrefNeverKey, false))
            {
                return null;
            }
            
            if (SessionState.GetBool(SupportSessionDismissKey, false))
            {
                return null;
            }

            // Check if there's a milestone - if so, always show (bypass cadence)
            object milestone = null;
            bool hasMilestone = false;
            try
            {
                System.Type milestoneTrackerType = null;
                
                // Try to find the type by searching through all loaded assemblies
                foreach (var assembly in System.AppDomain.CurrentDomain.GetAssemblies())
                {
                    milestoneTrackerType = assembly.GetType("YUCP.Components.Editor.SupportBanner.MilestoneTracker");
                    if (milestoneTrackerType != null)
                        break;
                }
                
                if (milestoneTrackerType != null)
                {
                    var getMilestoneMethod = milestoneTrackerType.GetMethod("GetCurrentMilestone", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                    if (getMilestoneMethod != null)
                    {
                        milestone = getMilestoneMethod.Invoke(null, null);
                        hasMilestone = milestone != null;
                    }
                }
            }
            catch (System.Exception)
            {
                // Silently fail milestone check
            }

            int count = EditorPrefs.GetInt(SupportPrefCounterKey, 0) + 1;
            EditorPrefs.SetInt(SupportPrefCounterKey, count);

            if (!hasMilestone)
            {
                int cadence = Math.Max(1, EditorPrefs.GetInt(SupportPrefCadenceKey, 1000));
                if (count % cadence != 0)
                {
                    return null;
                }
            }

            // Toast container - positioned at top-right, yellow theme matching components
            var toast = new VisualElement();
            toast.AddToClassList("yucp-support-toast");
            toast.style.position = Position.Absolute;
            toast.style.backgroundColor = new Color(0.6f, 0.45f, 0.2f, 0.95f); // Darker yellow/brown

            // Content container with horizontal layout
            var content = new VisualElement();
            content.AddToClassList("yucp-support-toast-content");
            toast.Add(content);

            // Left: Icon
            var iconImage = new Image();
            var heartIcon = AssetDatabase.LoadAssetAtPath<Texture2D>("Packages/com.yucp.components/Resources/Icons/NucleoArcade/heart.png");
            if (heartIcon != null)
            {
                iconImage.image = heartIcon;
            }
            iconImage.style.width = 32;
            iconImage.style.height = 32;
            iconImage.style.marginRight = 10;
            content.Add(iconImage);

            // Middle: Title and Subtitle
            var textContainer = new VisualElement();
            textContainer.AddToClassList("yucp-support-text-container");
            textContainer.name = "yucp-support-text-container";
            textContainer.style.flexDirection = FlexDirection.Column;
            textContainer.style.flexGrow = 1;
            textContainer.style.flexShrink = 1;
            textContainer.style.minWidth = 0; // Allow shrinking below content size

            // Get milestone title and subtitle
            string titleText = "Your Support Keeps This Free";
            string subtitleText = "Enjoying these tools? Your support keeps them free and helps create more amazing features!";
            
            if (milestone != null)
            {
                try
                {
                    var titleProperty = milestone.GetType().GetProperty("Title");
                    var subtitleProperty = milestone.GetType().GetProperty("Subtitle");
                    titleText = titleProperty?.GetValue(milestone)?.ToString() ?? titleText;
                    subtitleText = subtitleProperty?.GetValue(milestone)?.ToString() ?? subtitleText;
                }
                catch (System.Exception)
                {
                    // Silently fail milestone text retrieval
                }
            }

            var title = new Label(titleText);
            title.AddToClassList("yucp-support-title");
            title.style.fontSize = 13;
            title.style.color = new Color(1f, 1f, 1f, 1f); // White text
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.marginBottom = 2;
            textContainer.Add(title);

            var subtitle = new Label(subtitleText);
            subtitle.AddToClassList("yucp-support-subtitle");
            subtitle.style.fontSize = 10;
            subtitle.style.color = new Color(0.95f, 0.95f, 0.95f, 1f); // Light gray text
            subtitle.style.whiteSpace = WhiteSpace.Normal;
            textContainer.Add(subtitle);

            content.Add(textContainer);

            // Right: Action buttons
            var actionsContainer = new VisualElement();
            actionsContainer.AddToClassList("yucp-support-actions-container");
            actionsContainer.name = "yucp-support-actions-container";
            actionsContainer.style.flexDirection = FlexDirection.Column;
            actionsContainer.style.alignItems = Align.FlexEnd;
            actionsContainer.style.flexShrink = 0;
            actionsContainer.style.minWidth = 90;

            var supportButton = new Button(() => Application.OpenURL(SupportUrl)) { text = "Support" };
            supportButton.AddToClassList("yucp-support-button");
            supportButton.style.minWidth = 85;
            supportButton.style.height = 24;
            supportButton.style.fontSize = 11;
            supportButton.style.unityFontStyleAndWeight = FontStyle.Bold;
            supportButton.style.backgroundColor = new Color(0.886f, 0.647f, 0.290f, 1f); // Yellow
            supportButton.style.color = new Color(0.1f, 0.1f, 0.1f, 1f); // Dark text
            supportButton.style.borderTopWidth = 0;
            supportButton.style.borderBottomWidth = 0;
            supportButton.style.borderLeftWidth = 0;
            supportButton.style.borderRightWidth = 0;
            supportButton.style.paddingLeft = 12;
            supportButton.style.paddingRight = 12;
            supportButton.style.marginBottom = 4;
            supportButton.RegisterCallback<MouseEnterEvent>(evt => {
                supportButton.style.backgroundColor = new Color(0.9f, 0.7f, 0.4f, 1f); // Lighter on hover
            });
            supportButton.RegisterCallback<MouseLeaveEvent>(evt => {
                supportButton.style.backgroundColor = new Color(0.8f, 0.6f, 0.3f, 1f);
            });
            actionsContainer.Add(supportButton);

            var linksContainer = new VisualElement();
            linksContainer.style.flexDirection = FlexDirection.Row;

            var dismissButton = new Button(() =>
            {
                SessionState.SetBool(SupportSessionDismissKey, true);
                toast.RemoveFromHierarchy();
            }) { text = "Dismiss" };
            dismissButton.style.backgroundColor = new StyleColor(StyleKeyword.None);
            dismissButton.style.borderTopWidth = 0;
            dismissButton.style.borderBottomWidth = 0;
            dismissButton.style.borderLeftWidth = 0;
            dismissButton.style.borderRightWidth = 0;
            dismissButton.style.color = new Color(0.7f, 0.65f, 0.5f, 1f);
            dismissButton.style.fontSize = 9;
            dismissButton.style.paddingLeft = 2;
            dismissButton.style.paddingRight = 2;
            dismissButton.style.minHeight = 16;
            dismissButton.style.marginRight = 6;
            dismissButton.RegisterCallback<MouseEnterEvent>(evt => {
                dismissButton.style.color = new Color(1f, 1f, 1f, 1f);
            });
            dismissButton.RegisterCallback<MouseLeaveEvent>(evt => {
                dismissButton.style.color = new Color(0.85f, 0.85f, 0.85f, 1f);
            });
            linksContainer.Add(dismissButton);

            var neverButton = new Button(() =>
            {
                EditorPrefs.SetBool(SupportPrefNeverKey, true);
                
                // Animate out before removing
                toast.style.opacity = 0;
                toast.style.translate = new Translate(0, -20);
                
                toast.schedule.Execute(() => {
                    toast.RemoveFromHierarchy();
                }).StartingIn(300);
            }) { text = "Never show" };
            neverButton.style.backgroundColor = new StyleColor(StyleKeyword.None);
            neverButton.style.borderTopWidth = 0;
            neverButton.style.borderBottomWidth = 0;
            neverButton.style.borderLeftWidth = 0;
            neverButton.style.borderRightWidth = 0;
            neverButton.style.color = new Color(0.85f, 0.85f, 0.85f, 1f);
            neverButton.style.fontSize = 9;
            neverButton.style.paddingLeft = 2;
            neverButton.style.paddingRight = 2;
            neverButton.style.minHeight = 16;
            neverButton.RegisterCallback<MouseEnterEvent>(evt => {
                neverButton.style.color = new Color(1f, 1f, 1f, 1f);
            });
            neverButton.RegisterCallback<MouseLeaveEvent>(evt => {
                neverButton.style.color = new Color(0.85f, 0.85f, 0.85f, 1f);
            });
            linksContainer.Add(neverButton);

            actionsContainer.Add(linksContainer);
            content.Add(actionsContainer);

            return toast;
        }

        // UI Helper Methods for Modern Design System
        
        /// <summary>
        /// Build a chip/badge component for tags
        /// </summary>
        private VisualElement BuildChip(string text, Action onRemove = null, bool isSelected = false)
        {
            var chip = new VisualElement();
            chip.AddToClassList("yucp-chip");
            if (isSelected)
                chip.AddToClassList("yucp-chip-selected");
            
            var label = new Label(text);
            label.AddToClassList("yucp-chip-label");
            chip.Add(label);
            
            if (onRemove != null)
            {
                var removeButton = new Button(onRemove) { text = "×" };
                removeButton.AddToClassList("yucp-chip-remove");
                chip.Add(removeButton);
            }
            
            return chip;
        }
        
        /// <summary>
        /// Build an icon button with optional badge
        /// </summary>
        private Button BuildIconButton(string label, Texture2D icon, Action onClick, string variant = "outline", int badgeCount = 0)
        {
            var button = new Button(onClick);
            button.AddToClassList("yucp-button");
            button.AddToClassList("yucp-button-outline");
            button.AddToClassList("yucp-button-icon-left");
            
            if (icon != null)
            {
                var iconImage = new Image { image = icon };
                button.Add(iconImage);
            }
            
            var labelElement = new Label(label);
            button.Add(labelElement);
            
            if (badgeCount > 0)
            {
                var badge = new Label(badgeCount.ToString());
                badge.AddToClassList("yucp-button-badge");
                button.Add(badge);
            }
            
            return button;
        }
        
        // Popover state
        private VisualElement _currentPopover = null;
        private VisualElement _popoverBackdrop = null;
        
        /// <summary>
        /// Show a popover as a floating panel
        /// </summary>
        private void ShowPopover(Rect position, VisualElement content, Action onClose = null)
        {
            // Close existing popover
            ClosePopover();
            
            // Create backdrop
            _popoverBackdrop = new VisualElement();
            _popoverBackdrop.style.position = Position.Absolute;
            _popoverBackdrop.style.left = 0;
            _popoverBackdrop.style.top = 0;
            _popoverBackdrop.style.right = 0;
            _popoverBackdrop.style.bottom = 0;
            _popoverBackdrop.style.backgroundColor = new Color(0, 0, 0, 0.1f);
            _popoverBackdrop.RegisterCallback<MouseDownEvent>(evt =>
            {
                ClosePopover();
                onClose?.Invoke();
            });
            rootVisualElement.Add(_popoverBackdrop);
            
            // Create popover panel
            _currentPopover = new VisualElement();
            _currentPopover.AddToClassList("yucp-popover");
            _currentPopover.style.position = Position.Absolute;
            _currentPopover.style.left = position.x;
            _currentPopover.style.top = position.y;
            _currentPopover.style.width = position.width;
            _currentPopover.style.minHeight = position.height;
            _currentPopover.style.maxHeight = 500;
            _currentPopover.style.overflow = Overflow.Hidden;
            
            // Add content directly (content should handle its own scrolling if needed)
            _currentPopover.Add(content);
            
            rootVisualElement.Add(_currentPopover);
        }
        
        /// <summary>
        /// Close the current popover
        /// </summary>
        private void ClosePopover()
        {
            if (_currentPopover != null)
            {
                _currentPopover.RemoveFromHierarchy();
                _currentPopover = null;
            }
            if (_popoverBackdrop != null)
            {
                _popoverBackdrop.RemoveFromHierarchy();
                _popoverBackdrop = null;
            }
        }
        
        /// <summary>
        /// Replaces the default sidebar header with custom header containing Sort/Filter buttons and Search
        /// </summary>
        private void ReplaceSidebarHeader(VisualElement sidebarContainer, YucpSidebar sidebar, bool isOverlay)
        {
            // Find the existing header/search area - try common class names
            var existingHeader = sidebarContainer.Q<VisualElement>(className: "yucp-sidebar-header");
            if (existingHeader == null)
            {
                // Try finding by structure - look for search field parent
                var searchField = sidebarContainer.Q<TextField>();
                if (searchField != null)
                {
                    existingHeader = searchField.parent;
                }
            }
            
            // Create new custom header
            var customHeader = CreateProfileListHeader(sidebar, isOverlay);
            
            if (existingHeader != null)
            {
                // Replace existing header
                var parent = existingHeader.parent;
                if (parent != null)
                {
                    int index = parent.IndexOf(existingHeader);
                    existingHeader.RemoveFromHierarchy();
                    parent.Insert(index, customHeader);
                }
                else
                {
                    // Fallback: add at top
                    sidebarContainer.Insert(0, customHeader);
                }
            }
            else
            {
                // No existing header found, add at top
                sidebarContainer.Insert(0, customHeader);
            }
        }
        
        /// <summary>
        /// Creates the custom header row with Sort button and TokenizedSearchField
        /// </summary>
        private VisualElement CreateProfileListHeader(YucpSidebar sidebar, bool isOverlay)
        {
            var headerRow = new VisualElement();
            headerRow.AddToClassList("yucp-toolbar");
            headerRow.style.backgroundColor = new StyleColor(Color.clear); // Remove grey background
            // headerRow.style.zIndex = 100; // Removed: Not supported in this Unity version
            headerRow.style.overflow = Overflow.Visible; // Allow dropdown to overflow
            
            // Ensure toolbar allows overlay to flow out if needed. 
            // Note: UI Toolkit 'absolute' is relative to parent. 
            // If z-index issues occur, might need to append overlay to root, but let's try this first.
            
            // Left group: Sort button only (Filter button removed)
            var leftGroup = new VisualElement();
            leftGroup.AddToClassList("yucp-toolbar-left");
            
            // Sort button with icon
            string sortLabel = GetSortLabel(currentSortOption);
            Button sortButton = null;
            sortButton = new Button(() => ShowSortPopover(sortButton, isOverlay));
            sortButton.AddToClassList("yucp-btn-outline");
            if (currentSortOption != ProfileSortOption.Name)
                sortButton.AddToClassList("active");
            
            // Add icon (using text as icon placeholder - can be replaced with actual icon texture)
            var sortIcon = new Label("⇅");
            sortIcon.AddToClassList("yucp-btn-icon");
            sortButton.Add(sortIcon);
            
            var sortLabelElement = new Label(sortLabel);
            sortLabelElement.AddToClassList("yucp-sort-label"); // Added class for easier finding
            sortButton.Add(sortLabelElement);
            leftGroup.Add(sortButton);
            
            headerRow.Add(leftGroup);
            
            // Right group: Search field (Tokenized)
            var rightGroup = new VisualElement();
            rightGroup.AddToClassList("yucp-toolbar-right");
            rightGroup.style.flexGrow = 1;
            // Ensure search container doesn't clip the dropdown
            rightGroup.style.overflow = Overflow.Visible;
            headerRow.style.overflow = Overflow.Visible;
            
            var searchField = new TokenizedSearchField();
            if (isOverlay) _overlaySearchField = searchField;
            else _mainSearchField = searchField;
            
            RefreshSearchOptions(searchField);
            
            // Initialize with current search text
            string currentSearch = sidebar != null ? sidebar.GetSearchText() : "";
            searchField.value = currentSearch;
            
            // Initialize with current tags
            var currentTags = new List<string>(selectedFilterTags);
            if (!string.IsNullOrEmpty(selectedFilterFolder))
            {
                currentTags.Add($"Folder: {selectedFilterFolder}");
            }
            searchField.SetActiveTags(currentTags);
            
            // Hook up events
            searchField.OnSearchValueChanged += (newValue) => 
            {
                _currentSearchText = newValue ?? ""; // Store locally for reliable access
                var setSearchMethod = sidebar?.GetType().GetMethod("SetSearchText", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                if (setSearchMethod != null)
                {
                    setSearchMethod.Invoke(sidebar, new object[] { newValue });
                }
                UpdateProfileList();
            };
            
            searchField.OnTagAdded += (tag) => 
            {
                if (tag.StartsWith("Folder: "))
                {
                    string folderName = tag.Substring("Folder: ".Length);
                    selectedFilterFolder = folderName;
                }
                else
                {
                    if (!selectedFilterTags.Contains(tag))
                        selectedFilterTags.Add(tag);
                }
                UpdateProfileList();
            };
            
            searchField.OnTagRemoved += (tag) => 
            {
                if (tag.StartsWith("Folder: "))
                {
                    selectedFilterFolder = null;
                }
                else
                {
                    selectedFilterTags.Remove(tag);
                }
                UpdateProfileList();
            };
            
            rightGroup.Add(searchField);
            
            // Attach overlay to root to fix layering (dropdown appearing behind items)
            searchField.AttachOverlayToRoot(rootVisualElement);
            
            headerRow.Add(rightGroup);
            
            headerRow.name = "profile-header-row";
            
            // Responsive layout: Collapse sort button text on small widths
            headerRow.RegisterCallback<GeometryChangedEvent>(evt => 
            {
                if (sortLabelElement == null) return;
                
                // Threshold width for collapsing (approximate width of sidebar when minimal)
                float collapseThreshold = 320f;
                bool shouldCollapse = evt.newRect.width < collapseThreshold;
                
                if (shouldCollapse)
                {
                    sortLabelElement.style.display = DisplayStyle.None;
                    // Ensure button didn't shrink too much
                    sortButton.tooltip = sortLabel; // Move label to tooltip
                }
                else
                {
                    sortLabelElement.style.display = DisplayStyle.Flex;
                    sortButton.tooltip = ""; 
                }
            });
            
            return headerRow;
        }
        
        /// <summary>
        /// Creates the active filters chips row
        /// </summary>
        // CreateActiveFiltersRow removed - tags are now inside TokenizedSearchField
        
        /// <summary>
        /// Gets the display label for sort option
        /// </summary>
        private string GetSortLabel(ProfileSortOption option)
        {
            return option switch
            {
                ProfileSortOption.Name => "Sort: Name",
                ProfileSortOption.Version => "Sort: Version",
                ProfileSortOption.LastExportDate => "Sort: Date",
                _ => "Sort"
            };
        }
        
        /// <summary>
        /// Shows the sort popover
        /// </summary>
        private void ShowSortPopover(Button anchorButton, bool isOverlay)
        {
            var popoverContent = CreateSortPopoverContent(isOverlay);
            
            // Get button position for popover
            var buttonRect = anchorButton.worldBound;
            var popoverRect = new Rect(buttonRect.x, buttonRect.yMax + 4, 300, 120);
            
            ShowPopover(popoverRect, popoverContent);
        }
        

        /// <summary>
        /// Creates the sort popover content
        /// </summary>
        private VisualElement CreateSortPopoverContent(bool isOverlay)
        {
            var container = new VisualElement();
            container.AddToClassList("yucp-popover");
            container.style.overflow = Overflow.Hidden;
            container.style.minWidth = 280;
            container.style.maxWidth = 300;
            
            var content = new VisualElement();
            content.AddToClassList("yucp-popover-content");
            content.style.overflow = Overflow.Hidden;
            content.style.minWidth = 0;
            
            // Sort options
            var nameOption = CreateSortOption("Name", ProfileSortOption.Name, currentSortOption == ProfileSortOption.Name, () =>
            {
                currentSortOption = ProfileSortOption.Name;
                UpdateProfileList();
                ClosePopover();
            });
            content.Add(nameOption);
            
            var versionOption = CreateSortOption("Version", ProfileSortOption.Version, currentSortOption == ProfileSortOption.Version, () =>
            {
                currentSortOption = ProfileSortOption.Version;
                UpdateProfileList();
                ClosePopover();
            });
            content.Add(versionOption);
            
            var dateOption = CreateSortOption("Last Export Date", ProfileSortOption.LastExportDate, currentSortOption == ProfileSortOption.LastExportDate, () =>
            {
                currentSortOption = ProfileSortOption.LastExportDate;
                UpdateProfileList();
                ClosePopover();
            });
            content.Add(dateOption);
            
            container.Add(content);
            return container;
        }
        
        /// <summary>
        /// Creates a sort option row
        /// </summary>
        private VisualElement CreateSortOption(string label, ProfileSortOption option, bool isSelected, Action onClick)
        {
            var optionRow = new VisualElement();
            optionRow.AddToClassList("yucp-sort-option");
            if (isSelected)
                optionRow.AddToClassList("selected");
            
            // Indicator (dot for selected)
            var indicator = new VisualElement();
            indicator.AddToClassList("yucp-sort-indicator");
            if (isSelected)
            {
                var dot = new VisualElement();
                dot.AddToClassList("yucp-sort-indicator-dot");
                indicator.Add(dot);
            }
            optionRow.Add(indicator);
            
            var labelElement = new Label(label);
            labelElement.AddToClassList("yucp-sort-option-label");
            optionRow.Add(labelElement);
            
            optionRow.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button == 0)
                {
                    onClick?.Invoke();
                    evt.StopPropagation();
                }
            });
            
            return optionRow;
        }

        /// <summary>
        /// Build a checkbox row with label - full row clickable
        /// </summary>
        private VisualElement BuildCheckboxRow(string id, string label, bool initial, Action<bool> onChanged)
        {
            var row = new VisualElement();
            row.AddToClassList("yucp-row-item");
            row.name = id;
            if (initial)
                row.AddToClassList("selected");
            
            var toggle = new Toggle { value = initial };
            toggle.AddToClassList("yucp-toggle");
            toggle.RegisterValueChangedCallback(evt =>
            {
                if (evt.newValue)
                    row.AddToClassList("selected");
                else
                    row.RemoveFromClassList("selected");
                onChanged?.Invoke(evt.newValue);
            });
            row.Add(toggle);
            
            var labelElement = new Label(label);
            labelElement.AddToClassList("yucp-row-item-label");
            row.Add(labelElement);
            
            // Make entire row clickable
            row.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button == 0)
                {
                    toggle.value = !toggle.value;
                    evt.StopPropagation();
                }
            });
            
            return row;
        }
        private VisualElement CreateLeftPane(bool isOverlay)
        {
            var leftPane = new VisualElement();
            leftPane.AddToClassList("yucp-left-pane");
            
            // Create sidebar configuration
            var config = new YucpSidebar.SidebarConfig
            {
                HeaderText = "Export Profiles",
                ShowSearch = true,
                OnSearchChanged = (searchText) => UpdateProfileList(),
                ActionButtons = new List<YucpSidebar.SidebarActionButton>
                {
                    new YucpSidebar.SidebarActionButton
                    {
                        Text = "+ New Profile",
                        IsPrimary = true,
                        OnClick = () => { CreateNewProfile(); CloseOverlay(); }
                    },
                    new YucpSidebar.SidebarActionButton
                    {
                        Text = "Clone",
                        OnClick = () => { CloneProfile(selectedProfile); CloseOverlay(); }
                    },
                    new YucpSidebar.SidebarActionButton
                    {
                        Text = "Delete",
                        IsDanger = true,
                        OnClick = () => { DeleteProfile(selectedProfile); CloseOverlay(); }
                    }
                }
            };
            
            // Create sidebar - use separate instances for overlay and normal
            YucpSidebar sidebar;
            if (isOverlay)
            {
                _sidebarOverlay = new YucpSidebar(config);
                sidebar = _sidebarOverlay;
            }
            else
            {
                _sidebar = new YucpSidebar(config);
                sidebar = _sidebar;
            }
            
            var container = sidebar.CreateSidebar(isOverlay);
            
            // Store references
            if (isOverlay)
            {
                _profileListContainerOverlay = sidebar.ListContainer;
            }
            else
            {
                _profileListScrollView = sidebar.ScrollView;
                _profileListContainer = sidebar.ListContainer;
            }
            
            // Replace the default header with our custom header that includes Sort/Filter + Search
            ReplaceSidebarHeader(container, sidebar, isOverlay);
            
            leftPane.Add(container);
            return leftPane;
        }

        private VisualElement CreateRightPane()
        {
            var rightPane = new VisualElement();
            rightPane.AddToClassList("yucp-right-pane");
            
            _rightPaneScrollView = new ScrollView();
            _rightPaneScrollView.AddToClassList("yucp-panel");
            _rightPaneScrollView.AddToClassList("yucp-scrollview");
            
            // Empty state
            _emptyState = CreateEmptyState();
            _rightPaneScrollView.Add(_emptyState);
            
            _profileDetailsContainer = new VisualElement();
            _profileDetailsContainer.style.display = DisplayStyle.None;
            _profileDetailsContainer.style.flexGrow = 0;
            _profileDetailsContainer.style.flexShrink = 1;
            _profileDetailsContainer.style.flexBasis = StyleKeyword.Auto;
            _rightPaneScrollView.Add(_profileDetailsContainer);
            
            rightPane.Add(_rightPaneScrollView);
            return rightPane;
        }

        private VisualElement CreateEmptyState()
        {
            var emptyState = new VisualElement();
            emptyState.AddToClassList("yucp-empty-state");
            
            var title = new Label("No Profile Selected");
            title.AddToClassList("yucp-empty-state-title");
            emptyState.Add(title);
            
            var description = new Label("Select a profile from the list or create a new one");
            description.AddToClassList("yucp-empty-state-description");
            emptyState.Add(description);
            
            return emptyState;
        }

        private VisualElement CreateBottomBar()
        {
            var bottomBar = new VisualElement();
            bottomBar.AddToClassList("yucp-bottom-bar");
            
            // Export buttons container
            var exportContainer = new VisualElement();
            exportContainer.AddToClassList("yucp-export-buttons");
            
            // Info section (left side)
            var infoSection = new VisualElement();
            infoSection.AddToClassList("yucp-export-info");
            
            _multiSelectInfo = new VisualElement();
            _multiSelectInfo.AddToClassList("yucp-multi-select-info");
            _multiSelectInfo.style.display = DisplayStyle.None;
            var multiSelectText = new Label();
            multiSelectText.AddToClassList("yucp-multi-select-text");
            multiSelectText.name = "multiSelectText";
            _multiSelectInfo.Add(multiSelectText);
            infoSection.Add(_multiSelectInfo);
            
            exportContainer.Add(infoSection);
            
            // Buttons (right side)
            _exportSelectedButton = new Button(ExportSelectedProfiles);
            _exportSelectedButton.AddToClassList("yucp-button");
            _exportSelectedButton.AddToClassList("yucp-button-primary");
            _exportSelectedButton.AddToClassList("yucp-button-large");
            exportContainer.Add(_exportSelectedButton);
            
            _exportAllButton = new Button(() => ExportAllProfiles()) { text = "Export All Profiles" };
            _exportAllButton.AddToClassList("yucp-button");
            _exportAllButton.AddToClassList("yucp-button-export");
            _exportAllButton.AddToClassList("yucp-button-large");
            exportContainer.Add(_exportAllButton);
            
            bottomBar.Add(exportContainer);
            
            // Progress container
            _progressContainer = new VisualElement();
            _progressContainer.AddToClassList("yucp-progress-container");
            _progressContainer.style.display = DisplayStyle.None;
            
            var progressBar = new VisualElement();
            progressBar.AddToClassList("yucp-progress-bar");
            
            _progressFill = new VisualElement();
            _progressFill.AddToClassList("yucp-progress-fill");
            _progressFill.style.width = Length.Percent(0);
            progressBar.Add(_progressFill);
            
            _progressText = new Label("0%");
            _progressText.AddToClassList("yucp-progress-text");
            progressBar.Add(_progressText);
            
            _progressContainer.Add(progressBar);
            bottomBar.Add(_progressContainer);
            
            return bottomBar;
        }

        private void UpdateProfileList()
        {
            // Update header buttons to reflect current state
            UpdateHeaderButtons();
            
            // Refresh options in case tags changed
            RefreshSearchOptions(_mainSearchField);
            RefreshSearchOptions(_overlaySearchField);
            
            // Update both normal and overlay sidebars using local search text
            if (_sidebar != null)
            {
                // Custom rendering for folders - use local _currentSearchText for reliable filtering
                RenderProfileListWithFolders(_sidebar.ListContainer, _currentSearchText);
            }
            
            if (_sidebarOverlay != null)
            {
                RenderProfileListWithFolders(_sidebarOverlay.ListContainer, _currentSearchText);
            }
        }
        
        /// <summary>
        /// Updates header buttons to reflect current sort state
        /// </summary>
        private void UpdateHeaderButtons()
        {
            // Find and update sort button
            var sortButton = rootVisualElement.Q<Button>(className: "yucp-btn-outline");
            if (sortButton != null)
            {
                var label = sortButton.Q<Label>(className: "yucp-sort-label");
                if (label != null)
                {
                    label.text = GetSortLabel(currentSortOption);
                }
                
                if (currentSortOption != ProfileSortOption.Name)
                    sortButton.AddToClassList("active");
                else
                    sortButton.RemoveFromClassList("active");
            }
        }

        private void RefreshSearchOptions(YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField field)
        {
            if (field == null) return;

            var options = new List<YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField.SearchProposal>();
            var seenTags = new HashSet<string>();
            
            // 1. Preset tags
            var presetTagsType = typeof(YUCP.DevTools.Editor.PackageExporter.ExportProfile);
            var presetTagsField = presetTagsType.GetField("AvailablePresetTags", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
            var presetTagsList = presetTagsField?.GetValue(null) as List<string>;
            if (presetTagsList != null)
            {
                foreach(var t in presetTagsList) 
                {
                    if(seenTags.Add(t))
                        options.Add(new YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField.SearchProposal { Label = t, Value = t, IsTag = true });
                }
            }
            
            // 2. Global Custom Tags (EditorPrefs)
            string rawGlobalTags = EditorPrefs.GetString("YUCP_GlobalCustomTags", "");
            if (!string.IsNullOrEmpty(rawGlobalTags))
            {
                var splits = rawGlobalTags.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                foreach(var t in splits)
                {
                     if(seenTags.Add(t))
                        options.Add(new YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField.SearchProposal { Label = t, Value = t, IsTag = true });
                }
            }
            
            // 3. Custom tags from Profiles
            foreach (var profile in allProfiles)
            {
                if (profile.customTags != null)
                {
                    foreach (var tag in profile.customTags)
                    {
                        if (!string.IsNullOrWhiteSpace(tag))
                        {
                            var tr = tag.Trim();
                            if(seenTags.Add(tr))
                                options.Add(new YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField.SearchProposal { Label = tr, Value = tr, IsTag = true });
                        }
                    }
                }
                
                // 4. Profile Names (as non-tags)
                if (!string.IsNullOrWhiteSpace(profile.profileName))
                {
                    options.Add(new YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField.SearchProposal { Label = profile.profileName, Value = profile.profileName, IsTag = false });
                }
            }
            
            // 5. Folders as tags
             if (projectFolders != null)
            {
                foreach(var f in projectFolders) 
                {
                    string label = $"Folder: {f}";
                    if(seenTags.Add(label))
                        options.Add(new YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedSearchField.SearchProposal { Label = label, Value = label, IsTag = true });
                }
            }
            
            field.SetAvailableOptions(options);
        }
        


        private void RenderProfileListWithFolders(VisualElement container, string searchText)
        {
            if (container == null) return;
            container.Clear();
            
            bool hasSearchFilter = !string.IsNullOrWhiteSpace(searchText);
            
            // Ensure unified order is up to date
            ValidateAndCleanUnifiedOrder();
            
            // Apply filters and sorting to profiles
            var filteredProfiles = allProfiles.AsEnumerable();
            
            // Apply search filter
            if (hasSearchFilter)
            {
                filteredProfiles = filteredProfiles.Where(p => 
                    GetProfileDisplayName(p).ToLowerInvariant().Contains(searchText.ToLowerInvariant()));
            }
            
            // Apply tag filter
            if (selectedFilterTags.Count > 0)
            {
                filteredProfiles = filteredProfiles.Where(p => 
                {
                    var profileTags = p.GetAllTags();
                    return selectedFilterTags.Any(tag => profileTags.Contains(tag));
                });
            }
            
            // Apply folder filter
            if (!string.IsNullOrEmpty(selectedFilterFolder))
            {
                filteredProfiles = filteredProfiles.Where(p => p.folderName == selectedFilterFolder);
            }
            
            // Apply sorting
            filteredProfiles = SortProfiles(filteredProfiles.ToList(), currentSortOption);
            
            // Rebuild folder structure with filtered and sorted profiles
            var profileGuidToProfile = filteredProfiles.ToDictionary(
                p => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p)),
                p => p
            );
            
            // If we are sorting by anything other than default Name/Manual, 
            // OR if we have a search query, we should probably render a Flat List to respect the sort order/search results.
            // UnifiedOrder enforces manual positioning which conflicts with dynamic sorting.
            
            bool isCustomSort = currentSortOption != ProfileSortOption.Name;
            
            if (isCustomSort)
            {
                // RENDER FLAT LIST (Respects Sort)
                // Just render all filtered profiles in order
                int index = 0;
                foreach (var profile in filteredProfiles)
                {
                    var item = CreateProfileItem(profile, index); 
                    if (item != null)
                    {
                        container.Add(item);
                        
                        // Add gap for drag and drop (though drag drop might be disabled in this mode)
                        var gap = new VisualElement();
                        gap.AddToClassList("yucp-list-gap");
                        container.Add(gap);
                    }
                    index++;
                }
                
                // If empty
                if (!filteredProfiles.Any())
                {
                   // Container empty, maybe show 'No results' but empty state is handled by parent if needed, 
                   // or we just leave it empty.
                }
                
                return; // Done
            }

            // DEFAULT: Render Unified Order (Folders + Manual Sort)
            
            var folderToProfiles = filteredProfiles
                .Where(p => !string.IsNullOrEmpty(p.folderName) && projectFolders.Contains(p.folderName))
                .GroupBy(p => p.folderName)
                .ToDictionary(g => g.Key, g => g.ToList());
            
            // Build filtered unified order
            var filteredUnifiedOrder = new List<UnifiedOrderItem>();
            foreach (var orderItem in unifiedOrder)
            {
                if (orderItem.isFolder)
                {
                    // Only include folder if it has filtered profiles
                    if (folderToProfiles.ContainsKey(orderItem.identifier) && 
                        folderToProfiles[orderItem.identifier].Count > 0)
                    {
                        filteredUnifiedOrder.Add(orderItem);
                    }
                }
                else
                {
                    // Only include profile if it's in the filtered list
                    if (profileGuidToProfile.ContainsKey(orderItem.identifier))
                    {
                        filteredUnifiedOrder.Add(orderItem);
                    }
                }
            }
            
            // Track what we've rendered to avoid duplicates
            var renderedProfiles = new HashSet<ExportProfile>();
            var renderedFolders = new HashSet<string>();
            
            // Render items in filtered unified order
            foreach (var orderItem in filteredUnifiedOrder)
            {
                if (orderItem.isFolder)
                {
                    // Render folder
                    string folderName = orderItem.identifier;
                    
                    if (!projectFolders.Contains(folderName))
                        continue; // Skip invalid folders
                    
                    // Get profiles in this folder (already filtered and sorted)
                    var folderProfiles = folderToProfiles.TryGetValue(folderName, out var profiles) 
                        ? profiles 
                        : new List<ExportProfile>();
                    
                    // Skip if no matching profiles
                    if (folderProfiles.Count == 0)
                        continue;
                    
                    // Create folder header
                    var folderHeader = CreateFolderHeader(folderName, folderProfiles.Count);
                    container.Add(folderHeader);
                    renderedFolders.Add(folderName);
                    
                    // Render profiles in folder if not collapsed (or if searching)
                    if (!collapsedFolders.Contains(folderName) || hasSearchFilter)
                    {
                        var folderContent = new VisualElement();
                        folderContent.AddToClassList("yucp-folder-content");
                        
                        foreach (var profile in folderProfiles)
                        {
                            var item = CreateProfileItem(profile, allProfiles.IndexOf(profile));
                            folderContent.Add(item);
                            renderedProfiles.Add(profile);
                        }
                        container.Add(folderContent);
                    }
                }
                else
                {
                    // Render profile (only if not in a folder that's already rendered)
                    if (profileGuidToProfile.TryGetValue(orderItem.identifier, out var profile))
                    {
                        // Skip if already rendered (in a folder)
                        if (renderedProfiles.Contains(profile))
                            continue;
                        
                        // Skip if in a folder (folders handle their own profiles)
                        if (!string.IsNullOrEmpty(profile.folderName) && projectFolders.Contains(profile.folderName))
                            continue;
                        
                        // Profile is already filtered, no need to check again
                        
                        var item = CreateProfileItem(profile, allProfiles.IndexOf(profile));
                        container.Add(item);
                        renderedProfiles.Add(profile);
                    }
                }
            }
            
            // Check if we have any items to show
            if (container.childCount == 0)
            {
                string emptyMessage = "No profiles found";
                if (hasSearchFilter || selectedFilterTags.Count > 0 || !string.IsNullOrEmpty(selectedFilterFolder))
                    emptyMessage = "No profiles match your filters";
                
                var emptyLabel = new Label(emptyMessage);
                emptyLabel.AddToClassList("yucp-label-secondary");
                emptyLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
                emptyLabel.style.paddingTop = 20;
                container.Add(emptyLabel);
            }
        }
        
        /// <summary>
        /// Sorts profiles by the specified option
        /// </summary>
        private List<ExportProfile> SortProfiles(List<ExportProfile> profiles, ProfileSortOption sortOption)
        {
            switch (sortOption)
            {
                case ProfileSortOption.Name:
                    return profiles.OrderBy(p => GetProfileDisplayName(p)).ToList();
                    
                case ProfileSortOption.Version:
                    return profiles.OrderByDescending(p => 
                    {
                        // Try to parse version for proper semver sorting
                        if (VersionUtility.TryParseVersion(p.version, out int major, out int minor, out int patch, out int? build, out string prerelease, out string metadata))
                        {
                            // Create a comparable value: major * 1000000 + minor * 1000 + patch + (build ?? 0)
                            long versionValue = (long)major * 1000000L + (long)minor * 1000L + (long)patch;
                            if (build.HasValue)
                                versionValue += build.Value;
                            return versionValue;
                        }
                        return 0L;
                    }).ToList();
                    
                case ProfileSortOption.LastExportDate:
                    return profiles.OrderByDescending(p => 
                    {
                        if (string.IsNullOrEmpty(p.LastExportTime))
                            return DateTime.MinValue;
                        if (DateTime.TryParse(p.LastExportTime, out var date))
                            return date;
                        return DateTime.MinValue;
                    }).ToList();
                    
                default:
                    return profiles;
            }
        }

        private VisualElement CreateFolderHeader(string folderName, int count)
        {
            bool isCollapsed = collapsedFolders.Contains(folderName);
            
            var header = new VisualElement();
            header.AddToClassList("yucp-folder-header");
            header.AddToClassList("yucp-profile-item"); // Reuse profile item styling
            header.userData = folderName; // Identifier for drag-drop targets
            
            // Check if renaming
            if (folderName == folderBeingRenamed)
            {
                // Icon container with folder icon
                var iconContainer = new VisualElement();
                iconContainer.AddToClassList("yucp-profile-item-icon-container");
                iconContainer.AddToClassList("yucp-folder-icon-container");
                
                var folderIcon = new Image();
                folderIcon.image = EditorGUIUtility.IconContent("Folder Icon").image;
                folderIcon.AddToClassList("yucp-folder-icon");
                iconContainer.Add(folderIcon);
                header.Add(iconContainer);
                
                // Render text field for renaming
                var textField = new TextField();
                textField.value = folderName;
                textField.style.flexGrow = 1;
                textField.style.marginRight = 8;
                textField.AddToClassList("yucp-folder-rename-field");
                
                textField.RegisterCallback<KeyDownEvent>(evt => 
                {
                    if (evt.keyCode == KeyCode.Return || evt.keyCode == KeyCode.KeypadEnter)
                    {
                        EndRenameFolder(folderName, textField.value);
                        evt.StopPropagation();
                    }
                    else if (evt.keyCode == KeyCode.Escape)
                    {
                        CancelRenameFolder();
                        evt.StopPropagation();
                    }
                });
                
                textField.RegisterCallback<FocusOutEvent>(evt => 
                {
                    EndRenameFolder(folderName, textField.value);
                });
                
                header.Add(textField);
                
                // Focus and select all
                header.schedule.Execute(() => 
                {
                    textField.Focus();
                    textField.SelectAll();
                });
                
                return header;
            }
            
            // Drag-and-drop support for folders
            header.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button == 0) // Left click
                {
                    // Initialize drag state for folder
                    draggingIndex = -1; // Use -1 to indicate folder drag
                    draggingElement = header;
                    dragOffset = evt.localMousePosition;
                    dragStartPosition = evt.mousePosition;
                    hasDragged = false;
                    
                    header.CaptureMouse();
                    evt.StopPropagation();
                }
                else if (evt.button == 1) // Right click
                {
                    ShowFolderContextMenu(folderName);
                    evt.StopPropagation();
                }
            });
            
            // Drag handlers for folder - using vFavorites approach (same as profile items)
            header.RegisterCallback<MouseMoveEvent>(evt =>
            {
                if (draggingIndex == -1 && draggingElement == header && header.HasMouseCapture())
                {
                    float dragDistance = Vector2.Distance(evt.mousePosition, dragStartPosition);
                    if (dragDistance > DRAG_THRESHOLD && !hasDragged)
                    {
                        // Start the drag - vFavorites approach: remove from layout, position absolutely
                        hasDragged = true;
                        header.AddToClassList("yucp-profile-item-dragging");
                        
                        var listContainer = header.parent;
                        if (listContainer != null)
                        {
                            // Store original position in world space
                            Rect originalRect = header.worldBound;
                            draggedItemY = originalRect.y;
                            
                            // Remove from hierarchy and create gap (vFavorites approach)
                            float itemHeight = header.resolvedStyle.height;
                            if (itemHeight <= 0) itemHeight = 60f;
                            float itemMargin = header.resolvedStyle.marginBottom;
                            if (itemMargin <= 0) itemMargin = 2f;
                            
                            // Store folder name for reordering
                            draggingItemFromPageAtIndex = -1; // -1 indicates folder
                            
                            // draggedItemHoldOffset = 0f;
                            
                            // Remove from layout (vFavorites approach)
                            header.RemoveFromHierarchy();
                            
                            // Determine visual index of the dragged folder
                            // Get all items (profiles and folders) in visual order
                            var allItems = new List<VisualElement>();
                            foreach (var child in listContainer.Children())
                            {
                                if (child.ClassListContains("yucp-folder-content")) continue;
                                if (child.ClassListContains("yucp-profile-item") || child.ClassListContains("yucp-folder-header"))
                                {
                                    allItems.Add(child);
                                }
                            }
                            allItems = allItems.OrderBy(el => el.worldBound.y).ToList();
                            
                            draggingVisualIndex = allItems.IndexOf(header);
                            if (draggingVisualIndex < 0) draggingVisualIndex = 0;
                            
                            // Set gap at original visual position
                            float gapSize = itemHeight + itemMargin;
                            rowGaps[draggingVisualIndex] = gapSize;
                            
                            // Initialize insert index to the original visual index
                            insertDraggedItemAtIndex = draggingVisualIndex;
                            
                            // Reset all other items' transforms before starting drag
                            foreach (var child in listContainer.Children())
                            {
                                if (motionHandles.ContainsKey(child))
                                {
                                    var handle = motionHandles[child];
                                    handle.Animate(new MotionTargets
                                    {
                                        HasY = true,
                                        Y = 0f
                                    }, new Transition(0f, EasingType.Linear)); // Instant reset
                                }
                            }
                            
                            // Create container for absolutely positioned dragged folder
                            draggedItemContainer = new VisualElement();
                            draggedItemContainer.AddToClassList("yucp-profile-item-dragging-container");
                            draggedItemContainer.style.position = Position.Absolute;
                            draggedItemContainer.style.left = originalRect.x;
                            draggedItemContainer.style.top = originalRect.y;
                            draggedItemContainer.style.width = originalRect.width;
                            draggedItemContainer.style.height = originalRect.height;
                            draggedItemContainer.pickingMode = PickingMode.Ignore;
                            
                            header.style.position = Position.Absolute;
                            header.style.left = 0;
                            header.style.top = 0;
                            header.style.width = Length.Percent(100);
                            
                            draggedItemContainer.Add(header);
                            rootVisualElement.Add(draggedItemContainer);
                            
                            // Visual feedback
                            header.style.scale = new Scale(new Vector2(0.95f, 0.95f));
                        }
                    }
                    
                    if (hasDragged)
                    {
                        Vector2 mousePos = evt.mousePosition;
                        
                        // Update dragged folder position to follow mouse
                        if (draggedItemContainer != null)
                        {
                            draggedItemContainer.style.left = mousePos.x - dragOffset.x;
                            draggedItemContainer.style.top = mousePos.y - dragOffset.y;
                        }
                        
                        var listContainer = _profileListContainer;
                        if (listContainer != null)
                        {
                            // Calculate insertDraggedItemAtIndex for folders (same logic as profiles)
                            var allItems = new List<VisualElement>();
                            foreach (var child in listContainer.Children())
                            {
                                if (child.ClassListContains("yucp-folder-content")) continue;
                                if (child.ClassListContains("yucp-profile-item") || child.ClassListContains("yucp-folder-header"))
                                {
                                    if (child != header) // Exclude dragged folder
                                    {
                                        allItems.Add(child);
                                    }
                                }
                            }
                            allItems = allItems.OrderBy(el => el.worldBound.y).ToList();
                            
                            int newInsertIndex = allItems.Count; // Default to end
                            
                            if (allItems.Count > 0)
                            {
                                // Check if mouse is above the first item's top edge
                                var firstItem = allItems[0];
                                Rect firstWorld = firstItem.worldBound;
                                
                                if (mousePos.y < firstWorld.y)
                                {
                                    // Mouse is above first item - insert at position 0
                                    newInsertIndex = 0;
                                }
                                else
                                {
                                    // Find insertion point by comparing with each item's center
                                    for (int i = 0; i < allItems.Count; i++)
                                    {
                                        var child = allItems[i];
                                        Rect childWorld = child.worldBound;
                                        float childCenterY = childWorld.y + childWorld.height / 2f;
                                        
                                        // If mouse is above center of this child, insert before it
                                        if (mousePos.y < childCenterY)
                                        {
                                            newInsertIndex = i;
                                            break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                // No items, insert at 0
                                newInsertIndex = 0;
                            }
                            
                            // Clamp to valid range
                            newInsertIndex = Mathf.Clamp(newInsertIndex, 0, allItems.Count);
                            
                            if (newInsertIndex != insertDraggedItemAtIndex)
                            {
                                insertDraggedItemAtIndex = newInsertIndex;
                            }
                            
                            // Calculate drop index for folder reordering
                            int newDropIndex = CalculateDropIndexForFolder(listContainer, mousePos, folderName);
                            
                            if (newDropIndex != potentialDropIndex)
                            {
                                potentialDropIndex = newDropIndex;
                            }
                            
                            UpdateDropTargets(listContainer, potentialDropIndex, header);
                        }
                        
                        evt.StopPropagation();
                    }
                }
            });
            
            header.RegisterCallback<MouseUpEvent>(evt =>
            {
                if (draggingIndex == -1 && draggingElement == header && header.HasMouseCapture())
                {
                    header.ReleaseMouse();
                    
                    if (hasDragged)
                    {
                        header.RemoveFromClassList("yucp-profile-item-dragging");
                        header.style.scale = new Scale(Vector2.one);
                        
                        var listContainer = _profileListContainer;
                        if (listContainer != null)
                        {
                            int targetIndex = potentialDropIndex >= 0 ? potentialDropIndex : -1;
                            
                            if (targetIndex >= 0)
                            {
                                ReorderFolder(folderName, targetIndex);
                            }
                            
                            ClearDropTargets(listContainer);
                        }
                        
                        // Clean up drag state (vFavorites approach)
                        draggingItemFromPageAtIndex = -1;
                        insertDraggedItemAtIndex = -1;
                        // draggedItemHoldOffset = 0f;
                        draggingVisualIndex = -1;
                        
                        // Remove dragged item container
                        if (draggedItemContainer != null)
                        {
                            draggedItemContainer.RemoveFromHierarchy();
                            draggedItemContainer = null;
                        }
                        
                        // Clear gaps and reset transforms
                        rowGaps.Clear();
                        foreach (var child in listContainer.Children())
                        {
                            if (motionHandles.ContainsKey(child))
                            {
                                var handle = motionHandles[child];
                                handle.Animate(new MotionTargets
                                {
                                    HasY = true,
                                    Y = 0f
                                }, new Transition(0.2f, EasingType.EaseOut));
                            }
                            child.style.marginTop = 0f;
                        }
                        
                        UpdateProfileList();
                    }
                    else
                    {
                        // It was just a click - toggle collapse
                        if (isCollapsed)
                            collapsedFolders.Remove(folderName);
                        else
                            collapsedFolders.Add(folderName);
                            
                        SaveCollapsedFolders();
                        UpdateProfileList();
                    }
                    
                    draggingIndex = -1;
                    draggingElement = null;
                    hasDragged = false;
                    potentialDropIndex = -1;
                    evt.StopPropagation();
                }
            });
            
            // Icon container with folder icon (like profile item icon)
            var mainIconContainer = new VisualElement();
            mainIconContainer.AddToClassList("yucp-profile-item-icon-container");
            mainIconContainer.AddToClassList("yucp-folder-icon-container");
            
            var mainFolderIcon = new Image();
            mainFolderIcon.image = EditorGUIUtility.IconContent(isCollapsed ? "Folder Icon" : "FolderOpened Icon").image;
            mainFolderIcon.AddToClassList("yucp-folder-icon");
            mainIconContainer.Add(mainFolderIcon);
            header.Add(mainIconContainer);
            
            // Content column (like profile item content)
            var contentColumn = new VisualElement();
            contentColumn.AddToClassList("yucp-profile-item-content");
            contentColumn.style.flexGrow = 1;
            
            // Folder name
            var nameLabel = new Label(folderName);
            nameLabel.AddToClassList("yucp-profile-item-name");
            contentColumn.Add(nameLabel);
            
            // Folder info
            var infoText = $"{count} profile{(count != 1 ? "s" : "")}";
            var infoLabel = new Label(infoText);
            infoLabel.AddToClassList("yucp-profile-item-info");
            contentColumn.Add(infoLabel);
            
            header.Add(contentColumn);
            
            // Chevron indicator
            var chevron = new Image();
            chevron.AddToClassList("yucp-folder-chevron");
            var chevronIcon = AssetDatabase.LoadAssetAtPath<Texture2D>(
                isCollapsed 
                ? "Packages/com.yucp.components/Resources/Icons/Nucleo/chevron-right-small.png"
                : "Packages/com.yucp.components/Resources/Icons/Nucleo/chevron-down-small.png");
            if (chevronIcon != null)
            {
                chevron.image = chevronIcon;
            }
            else
            {
                // Fallback to built-in
                chevron.image = EditorGUIUtility.IconContent(isCollapsed ? "d_forward" : "d_dropdown").image;
            }
            header.Add(chevron);
            
            return header;
        }

        private void LoadProjectFolders()
        {
            string foldersStr = EditorPrefs.GetString(PackageFoldersKey, "");
            projectFolders = !string.IsNullOrEmpty(foldersStr) 
                ? foldersStr.Split(';').Where(s => !string.IsNullOrEmpty(s)).ToList() 
                : new List<string>();
                
            string collapsedStr = EditorPrefs.GetString(CollapsedFoldersKey, "");
            collapsedFolders = !string.IsNullOrEmpty(collapsedStr)
                ? new HashSet<string>(collapsedStr.Split(';'))
                : new HashSet<string>();
        }
        
        private void SaveProjectFolders()
        {
            EditorPrefs.SetString(PackageFoldersKey, string.Join(";", projectFolders));
        }
        
        private void SaveCollapsedFolders()
        {
             EditorPrefs.SetString(CollapsedFoldersKey, string.Join(";", collapsedFolders));
        }
        
        private void ShowFolderContextMenu(string folderName)
        {
            var menu = new GenericMenu();
            menu.AddItem(new GUIContent("Rename Folder"), false, () => 
            {
                StartRenameFolder(folderName);
            });
            menu.AddItem(new GUIContent("Delete Folder"), false, () => 
            {
                if (EditorUtility.DisplayDialog("Delete Folder", 
                    $"Are you sure you want to delete folder '{folderName}'? Profiles inside will be moved to root.", "Delete", "Cancel"))
                {
                    DeleteFolder(folderName);
                }
            });
            menu.ShowAsContext();
        }
        
        private void RenameFolder(string oldName, string newName)
        {
            if (string.IsNullOrWhiteSpace(newName) || oldName == newName) return;
            if (projectFolders.Contains(newName))
            {
                EditorUtility.DisplayDialog("Error", "Folder already exists!", "OK");
                return;
            }
            
            // Update list
            int index = projectFolders.IndexOf(oldName);
            if (index >= 0) projectFolders[index] = newName;
            
            // Update unified order
            foreach (var item in unifiedOrder)
            {
                if (item.isFolder && item.identifier == oldName)
                {
                    item.identifier = newName;
                }
            }
            
            // Update profiles
            bool dirty = false;
            foreach (var p in allProfiles)
            {
                if (p.folderName == oldName)
                {
                    p.folderName = newName;
                    EditorUtility.SetDirty(p);
                    dirty = true;
                }
            }
            if (dirty) AssetDatabase.SaveAssets();
            
            SaveProjectFolders();
            SaveUnifiedOrder();
            UpdateProfileList();
        }
        
        private void DeleteFolder(string folderName)
        {
            projectFolders.Remove(folderName);
            
            // Remove folder from unified order
            unifiedOrder.RemoveAll(item => item.isFolder && item.identifier == folderName);
            
            // Move profiles to root and add them to unified order
            bool dirty = false;
            foreach (var p in allProfiles)
            {
                if (p.folderName == folderName)
                {
                    p.folderName = "";
                    EditorUtility.SetDirty(p);
                    dirty = true;
                    
                    // Add profile to unified order (at end for now)
                    string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p));
                    if (!unifiedOrder.Any(item => !item.isFolder && item.identifier == guid))
                    {
                        unifiedOrder.Add(new UnifiedOrderItem { isFolder = false, identifier = guid });
                    }
                }
            }
            if (dirty) AssetDatabase.SaveAssets();
            
            SaveProjectFolders();
            SaveUnifiedOrder();
            UpdateProfileList();
        }
        
        private void CreateNewFolder()
        {
            string newName = GetUniqueNewFolderName();
            projectFolders.Add(newName);
            SaveProjectFolders();
            
            // Add folder to unified order at the end (or at insertion point if dragging)
            // For now, add at end - can be enhanced later to support insertion point
            unifiedOrder.Add(new UnifiedOrderItem { isFolder = true, identifier = newName });
            SaveUnifiedOrder();
            
            StartRenameFolder(newName);
        }
        
        private void MoveProfileToFolder(ExportProfile profile, string folderName)
        {
            if (profile.folderName == folderName) return;
            
            string profileGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profile));
            
            // Remove profile from unified order (if it was there as uncategorized)
            unifiedOrder.RemoveAll(item => !item.isFolder && item.identifier == profileGuid);
            
            profile.folderName = folderName;
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            
            SaveUnifiedOrder();
            UpdateProfileList();
        }
        
        private void GroupSelectedProfilesIntoFolder()
        {
            if (selectedProfileIndices.Count < 2) return;
            
            string newName = GetUniqueNewFolderName();
            projectFolders.Add(newName);
            SaveProjectFolders();
            
            // Add folder to unified order (at position of first selected profile if possible)
            int insertIndex = -1;
            if (selectedProfileIndices.Count > 0)
            {
                int firstIndex = selectedProfileIndices.Min();
                var firstProfile = allProfiles[firstIndex];
                string firstGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(firstProfile));
                
                // Find position in unified order
                for (int i = 0; i < unifiedOrder.Count; i++)
                {
                    if (!unifiedOrder[i].isFolder && unifiedOrder[i].identifier == firstGuid)
                    {
                        insertIndex = i;
                        break;
                    }
                }
            }
            
            var folderItem = new UnifiedOrderItem { isFolder = true, identifier = newName };
            if (insertIndex >= 0)
            {
                unifiedOrder.Insert(insertIndex, folderItem);
            }
            else
            {
                unifiedOrder.Add(folderItem);
            }
            
            // Move profiles immediately and remove from unified order
            bool dirty = false;
            foreach (int idx in selectedProfileIndices)
            {
                if (idx >= 0 && idx < allProfiles.Count)
                {
                    var p = allProfiles[idx];
                    string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p));
                    
                    // Remove from unified order
                    unifiedOrder.RemoveAll(item => !item.isFolder && item.identifier == guid);
                    
                    p.folderName = newName;
                    EditorUtility.SetDirty(p);
                    dirty = true;
                }
            }
            if (dirty) AssetDatabase.SaveAssets();
            
            SaveUnifiedOrder();
            StartRenameFolder(newName);
        }
        
        private void CreateFolderWithProfiles(ExportProfile profileA, ExportProfile profileB)
        {
            string newName = GetUniqueNewFolderName();
            projectFolders.Add(newName);
            SaveProjectFolders();
            
            // Find position in unified order (between the two profiles)
            string guidA = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profileA));
            string guidB = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profileB));
            
            int insertIndex = -1;
            int indexA = -1, indexB = -1;
            for (int i = 0; i < unifiedOrder.Count; i++)
            {
                if (!unifiedOrder[i].isFolder)
                {
                    if (unifiedOrder[i].identifier == guidA) indexA = i;
                    if (unifiedOrder[i].identifier == guidB) indexB = i;
                }
            }
            
            if (indexA >= 0 && indexB >= 0)
            {
                insertIndex = Math.Min(indexA, indexB);
            }
            else if (indexA >= 0)
            {
                insertIndex = indexA;
            }
            else if (indexB >= 0)
            {
                insertIndex = indexB;
            }
            
            // Add folder to unified order
            var folderItem = new UnifiedOrderItem { isFolder = true, identifier = newName };
            if (insertIndex >= 0)
            {
                unifiedOrder.Insert(insertIndex, folderItem);
            }
            else
            {
                unifiedOrder.Add(folderItem);
            }
            
            // Remove profiles from unified order
            unifiedOrder.RemoveAll(item => !item.isFolder && (item.identifier == guidA || item.identifier == guidB));
            
            profileA.folderName = newName;
            profileB.folderName = newName;
            EditorUtility.SetDirty(profileA);
            EditorUtility.SetDirty(profileB);
            AssetDatabase.SaveAssets();
            
            SaveUnifiedOrder();
            StartRenameFolder(newName);
        }
        
        // Folder Renaming Helpers
        
        private string GetUniqueNewFolderName(string baseName = "New Folder")
        {
            if (!projectFolders.Contains(baseName)) return baseName;
            
            int i = 1;
            while (projectFolders.Contains($"{baseName} {i}"))
            {
                i++;
            }
            return $"{baseName} {i}";
        }
        
        private void StartRenameFolder(string folderName)
        {
            folderBeingRenamed = folderName;
            UpdateProfileList();
        }
        
        private void CancelRenameFolder()
        {
            folderBeingRenamed = null;
            UpdateProfileList();
        }
        
        private void EndRenameFolder(string oldName, string newName)
        {
            folderBeingRenamed = null;
            
            if (string.IsNullOrWhiteSpace(newName))
            {
                UpdateProfileList();
                return;
            }
            
            if (oldName == newName)
            {
                UpdateProfileList();
                return;
            }
            
            RenameFolder(oldName, newName);
            UpdateProfileList();
        }

        private VisualElement CreateProfileItem(ExportProfile profile, int index)
        {
            var item = new VisualElement();
            item.AddToClassList("yucp-profile-item");
            item.userData = index; // Store index for drag-and-drop
            
            bool isSelected = selectedProfileIndices.Contains(index);
            if (isSelected)
            {
                item.AddToClassList("yucp-profile-item-selected");
            }
            
            // Icon container
            var iconContainer = new VisualElement();
            iconContainer.AddToClassList("yucp-profile-item-icon-container");
            
            var iconImage = new Image();
            Texture2D displayIcon = profile.icon;
            if (displayIcon == null)
            {
                displayIcon = GetPlaceholderTexture();
            }
            iconImage.image = displayIcon;
            iconImage.AddToClassList("yucp-profile-item-icon");
            iconContainer.Add(iconImage);
            
            item.Add(iconContainer);
            
            // Content column
            var contentColumn = new VisualElement();
            contentColumn.AddToClassList("yucp-profile-item-content");
            contentColumn.style.flexGrow = 1;
            
            // Profile name
            var nameLabel = new Label(GetProfileDisplayName(profile));
            nameLabel.AddToClassList("yucp-profile-item-name");
            contentColumn.Add(nameLabel);
            
            // Profile info
            var infoText = $"v{profile.version}";
            if (profile.foldersToExport.Count > 0)
            {
                infoText += $" • {profile.foldersToExport.Count} folder(s)";
            }
            var infoLabel = new Label(infoText);
            infoLabel.AddToClassList("yucp-profile-item-info");
            contentColumn.Add(infoLabel);
            
            // Tags display - show as small chips
            var allTags = profile.GetAllTags();
            if (allTags.Count > 0)
            {
                var tagsContainer = new VisualElement();
                tagsContainer.style.flexDirection = FlexDirection.Row;
                tagsContainer.style.flexWrap = Wrap.Wrap;
                tagsContainer.style.marginTop = 4;
                tagsContainer.style.marginBottom = 2;
                
                // Show up to 3 tags, then "+X more" if there are more
                int maxVisibleTags = 3;
                var tagsToShow = allTags.Take(maxVisibleTags).ToList();
                
                foreach (var tag in tagsToShow)
                {
                    var tagChip = BuildChip(tag, null, false);
                    tagChip.AddToClassList("yucp-profile-tag-chip");
                    // Remove remove button for list display
                    var removeBtn = tagChip.Q<Button>(className: "yucp-chip-remove");
                    if (removeBtn != null)
                        removeBtn.RemoveFromHierarchy();
                    tagsContainer.Add(tagChip);
                }
                
                if (allTags.Count > maxVisibleTags)
                {
                    var moreLabel = new Label($"+{allTags.Count - maxVisibleTags} more");
                    moreLabel.style.fontSize = 9;
                    moreLabel.style.color = new Color(0.6f, 0.6f, 0.6f, 1f);
                    moreLabel.style.marginLeft = 4;
                    moreLabel.style.marginTop = 2;
                    tagsContainer.Add(moreLabel);
                }
                
                contentColumn.Add(tagsContainer);
            }
            
            item.Add(contentColumn);
            
            // Drag-and-drop handlers - entire item is draggable
            item.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button == 0) // Left click
                {
                    // Initialize drag state
                    draggingIndex = index;
                    draggingElement = item;
                    dragOffset = evt.localMousePosition;
                    dragStartPosition = evt.mousePosition;
                    hasDragged = false;
                    
                    // Clean state - no gaps, no transforms
                    var listContainer = item.parent;
                    if (listContainer != null)
                    {
                        // Clear any existing gaps
                        rowGaps.Clear();
                    }
                    
                    item.CaptureMouse();
                    evt.StopPropagation();
                }
                else if (evt.button == 1) // Right click
                {
                    ShowProfileContextMenu(profile, index, evt);
                    evt.StopPropagation();
                }
            });
            
            
            // Drag handlers on the item
            item.RegisterCallback<MouseMoveEvent>(evt =>
            {
                if (draggingIndex == index && item.HasMouseCapture())
                {
                    // Check if we've moved enough to consider it a drag
                    float dragDistance = Vector2.Distance(evt.mousePosition, dragStartPosition);
                    if (dragDistance > DRAG_THRESHOLD && !hasDragged)
                    {
                        // Start the drag - vFavorites approach: remove from layout, position absolutely
                        hasDragged = true;
                        item.AddToClassList("yucp-profile-item-dragging");
                        
                        var listContainer = item.parent;
                        if (listContainer != null)
                        {
                            // Store original position in world space
                            Rect originalRect = item.worldBound;
                            draggedItemY = originalRect.y;
                            
                            // Remove from hierarchy and create gap (vFavorites approach)
                            float itemHeight = item.resolvedStyle.height;
                            if (itemHeight <= 0) itemHeight = 60f;
                            float itemMargin = item.resolvedStyle.marginBottom;
                            if (itemMargin <= 0) itemMargin = 2f;
                            
                            // Store original index (vFavorites initFromPage approach)
                            draggingItemFromPageAtIndex = index;
                            
                            // Calculate draggedItemHoldOffset - no longer needed with element-based calculation
                            // But keeping for potential future use
                            // draggedItemHoldOffset = 0f;
                            
                            // Remove from layout (vFavorites approach)
                            item.RemoveFromHierarchy();
                            
                            // Determine visual index of the dragged item
                            var profileItems = listContainer.Query<VisualElement>(className: "yucp-profile-item").ToList()
                                .Where(el => el.userData is int)
                                .ToList();
                            draggingVisualIndex = profileItems.IndexOf(item);
                            if (draggingVisualIndex < 0) draggingVisualIndex = 0;
                            
                            // Set gap at original visual position
                            float gapSize = itemHeight + itemMargin;
                            rowGaps[draggingVisualIndex] = gapSize;
                            
                            // Initialize insert index to the original visual index
                            insertDraggedItemAtIndex = draggingVisualIndex;
                            
                            // Reset all other items' transforms before starting drag
                            foreach (var child in listContainer.Children())
                            {
                                if (motionHandles.ContainsKey(child))
                                {
                                    var handle = motionHandles[child];
                                    handle.Animate(new MotionTargets
                                    {
                                        HasY = true,
                                        Y = 0f
                                    }, new Transition(0f, EasingType.Linear)); // Instant reset
                                }
                            }
                            
                            // Create container for absolutely positioned dragged item
                            draggedItemContainer = new VisualElement();
                            draggedItemContainer.AddToClassList("yucp-profile-item-dragging-container");
                            draggedItemContainer.style.position = Position.Absolute;
                            draggedItemContainer.style.left = originalRect.x;
                            draggedItemContainer.style.top = originalRect.y;
                            draggedItemContainer.style.width = originalRect.width;
                            draggedItemContainer.style.height = originalRect.height;
                            draggedItemContainer.pickingMode = PickingMode.Ignore;
                            
                            // Add item to container
                            draggedItemContainer.Add(item);
                            
                            // Add container to root (overlay everything)
                            rootVisualElement.Add(draggedItemContainer);
                            
                            // Apply scale for visual feedback
                            item.style.scale = new Scale(new Vector2(0.95f, 0.95f));
                        }
                    }
                    
                    if (hasDragged)
                    {
                        // Move the dragged item absolutely (vFavorites approach)
                        if (draggedItemContainer != null)
                        {
                            // Calculate target position from mouse (screen space)
                            Vector2 targetPos = evt.mousePosition - dragOffset;
                            draggedItemY = targetPos.y;
                            
                            // Update container position (absolute positioning)
                            draggedItemContainer.style.top = draggedItemY;
                            draggedItemContainer.style.left = targetPos.x;
                            
                            Vector2 mousePos = evt.mousePosition;
                            
                            // Get list container
                            var listContainer = _profileListContainer;
                            if (listContainer == null)
                            {
                                // Try to find it from root
                                listContainer = rootVisualElement.Q<VisualElement>(className: "yucp-profile-list-container");
                            }
                            
                            if (listContainer != null)
                            {
                                // Calculate insertDraggedItemAtIndex using visual order (vFavorites-style)
                                // Get all visible root-level profile items (excluding dragged item and folder items) in visual order
                                var profileItems = new List<VisualElement>();
                                foreach (var child in listContainer.Children())
                                {
                                    // Skip folders and folder content
                                    if (child.ClassListContains("yucp-folder-header") || child.ClassListContains("yucp-folder-content"))
                                        continue;
                                    
                                    // Only include root-level profile items
                                    if (child.ClassListContains("yucp-profile-item") && child.userData is int && child != draggingElement)
                                    {
                                        profileItems.Add(child);
                                    }
                                }
                                
                                // Sort by visual Y position
                                profileItems = profileItems.OrderBy(el => el.worldBound.y).ToList();
                                
                                int newInsertIndex = profileItems.Count; // Default to end
                                
                                if (profileItems.Count > 0)
                                {
                                    // Check if mouse is above the first item's top edge
                                    var firstItem = profileItems[0];
                                    Rect firstWorld = firstItem.worldBound;
                                    
                                    if (mousePos.y < firstWorld.y)
                                    {
                                        // Mouse is above first item - insert at position 0
                                        newInsertIndex = 0;
                                    }
                                    else
                                    {
                                        // Find insertion point by comparing with each item's center
                                        for (int i = 0; i < profileItems.Count; i++)
                                        {
                                            var child = profileItems[i];
                                            Rect childWorld = child.worldBound;
                                            float childCenterY = childWorld.y + childWorld.height / 2f;
                                            
                                            // If mouse is above center of this child, insert before it
                                            if (mousePos.y < childCenterY)
                                            {
                                                newInsertIndex = i;
                                                break;
                                            }
                                        }
                                        
                                        // If we didn't find a position (mouse is below all items), insert at end
                                        // newInsertIndex already defaults to profileItems.Count
                                    }
                                }
                                else
                                {
                                    // No items, insert at 0
                                    newInsertIndex = 0;
                                }
                                
                                // Clamp to valid range (0 to profileItems.Count inclusive)
                                newInsertIndex = Mathf.Clamp(newInsertIndex, 0, profileItems.Count);
                                
                                if (newInsertIndex != insertDraggedItemAtIndex)
                                {
                                    insertDraggedItemAtIndex = newInsertIndex;
                                }
                                
                                // Find folder target if any
                                VisualElement folderTarget = null;
                                int newDropIndex = CalculateDropIndexWithFolders(listContainer, mousePos, index, out folderTarget);
                                
                                if (newDropIndex != potentialDropIndex)
                                {
                                    potentialDropIndex = newDropIndex;
                                }
                                
                                // Update visual feedback for drop targets
                                if (folderTarget != null)
                                {
                                    UpdateFolderDropTargets(listContainer, folderTarget);
                                    if (potentialDropIndex >= 0) ClearDropTargets(listContainer);
                                    ResetStackState();
                                }
                                else
                                {
                                    UpdateFolderDropTargets(listContainer, null);
                                    UpdateDropTargets(listContainer, potentialDropIndex, item);
                                    
                                    // Stack detection: find profile item under cursor
                                    VisualElement hitElement = listContainer.panel.Pick(mousePos);
                                    VisualElement targetItem = null;
                                    int targetIdx = -1;
                                    
                                    var current = hitElement;
                                    while (current != null && current != listContainer)
                                    {
                                        if (current.ClassListContains("yucp-profile-item") && current.userData is int idx && idx != index)
                                        {
                                            targetItem = current;
                                            targetIdx = idx;
                                            break;
                                        }
                                        current = current.parent;
                                    }
                                    
                                    if (targetItem != null && targetIdx >= 0)
                                    {
                                        if (stackTargetElement == targetItem)
                                        {
                                            float dist = Vector2.Distance(mousePos, stackHoverPosition);
                                            if (dist <= STACK_POSITION_TOLERANCE)
                                            {
                                                double elapsed = EditorApplication.timeSinceStartup - stackHoverStartTime;
                                                if (elapsed >= STACK_HOVER_THRESHOLD && !isStackReady)
                                                {
                                                    isStackReady = true;
                                                    targetItem.AddToClassList("yucp-profile-item-stack-target");
                                                }
                                            }
                                            else
                                            {
                                                stackHoverStartTime = EditorApplication.timeSinceStartup;
                                                stackHoverPosition = mousePos;
                                                isStackReady = false;
                                                targetItem.RemoveFromClassList("yucp-profile-item-stack-target");
                                            }
                                        }
                                        else
                                        {
                                            ResetStackState();
                                            stackTargetElement = targetItem;
                                            stackTargetIndex = targetIdx;
                                            stackHoverStartTime = EditorApplication.timeSinceStartup;
                                            stackHoverPosition = mousePos;
                                        }
                                    }
                                    else
                                    {
                                        ResetStackState();
                                    }
                                }
                            }
                        }
                    }
                    
                    evt.StopPropagation();
                }
            });
            
            item.RegisterCallback<MouseUpEvent>(evt =>
            {
                if (draggingIndex == index && item.HasMouseCapture())
                {
                    item.ReleaseMouse();
                    
                    if (hasDragged)
                    {
                        // We were dragging - handle drop (vFavorites approach)
                        item.RemoveFromClassList("yucp-profile-item-dragging");
                        
                        // Get list container
                        var listContainer = _profileListContainer;
                        if (listContainer == null)
                        {
                            listContainer = rootVisualElement.Q<VisualElement>(className: "yucp-profile-list-container");
                        }
                        
                        if (listContainer != null)
                        {
                            // Use insertDraggedItemAtIndex (vFavorites AcceptDragging approach)
                            int targetIndex = insertDraggedItemAtIndex >= 0 ? insertDraggedItemAtIndex : index;
                            
                            // Check for folder drops
                            VisualElement hitElement = listContainer.panel.Pick(evt.mousePosition);
                             // Traverse up to find folder header
                             VisualElement folderHeader = null;
                             var current = hitElement;
                             while(current != null && current != listContainer) {
                                 if (current.ClassListContains("yucp-folder-header")) {
                                     folderHeader = current;
                                     break;
                                 }
                                 current = current.parent;
                             }

                            if (folderHeader != null && folderHeader.userData is string fName && fName != profile.folderName)
                            {
                                 // Dropped onto a different folder
                                 MoveProfileToFolder(profile, fName);
                            }
                            else if (isStackReady && stackTargetIndex >= 0 && stackTargetIndex < allProfiles.Count)
                            {
                                // Stack-to-folder: create a new folder with both profiles
                                var targetProfile = allProfiles[stackTargetIndex];
                                CreateFolderWithProfiles(profile, targetProfile);
                            }
                            else
                            {
                                // Perform reorder on drop (vFavorites AcceptDragging: insert at insertDraggedItemAtIndex)
                                // insertDraggedItemAtIndex is the visual index (0-based position in visible list excluding dragged item)
                                // In vFavorites: data.curPage.items.AddAt(draggedItem, insertDraggedItemAtIndex)
                                // The items list already has the dragged item removed, so insertDraggedItemAtIndex is the position in that list
                                
                                // Get all visible root-level profile items (excluding dragged item) in visual order
                                var profileItems = new List<VisualElement>();
                                foreach (var child in listContainer.Children())
                                {
                                    // Skip folders and folder content
                                    if (child.ClassListContains("yucp-folder-header") || child.ClassListContains("yucp-folder-content"))
                                        continue;
                                    
                                    // Only include root-level profile items
                                    if (child.ClassListContains("yucp-profile-item") && child.userData is int && child != draggingElement)
                                    {
                                        profileItems.Add(child);
                                    }
                                }
                                
                                // Sort by visual Y position to match how insertDraggedItemAtIndex was calculated during drag
                                profileItems = profileItems.OrderBy(el => el.worldBound.y).ToList();
                                
                                // insertDraggedItemAtIndex is the VISUAL index where we want to insert
                                // ReorderProfiles expects: sourceProfileIndex (from allProfiles) and targetVisualIndex
                                // The CalculateUnifiedOrderPositionFromVisualIndex inside ReorderProfiles 
                                // interprets targetIndex as a visual position, so we pass insertDraggedItemAtIndex directly
                                
                                if (insertDraggedItemAtIndex >= 0 && insertDraggedItemAtIndex != draggingVisualIndex)
                                {
                                    ReorderProfiles(draggingItemFromPageAtIndex, insertDraggedItemAtIndex);
                                }
                            }
                            
                            // Adjust rowGaps (vFavorites: data.curPage.rowGaps[insertDraggedItemAtIndex] -= rowHeight; data.curPage.rowGaps.AddAt(0, insertDraggedItemAtIndex))
                            if (rowGaps.ContainsKey(targetIndex))
                            {
                                float rowHeight = draggingElement != null ? draggingElement.resolvedStyle.height : 60f;
                                if (rowHeight <= 0) rowHeight = 60f;
                                rowGaps[targetIndex] = Mathf.Max(0f, rowGaps[targetIndex] - rowHeight);
                            }
                            
                            // Reset stack state
                            ResetStackState();
                            
                            // Clear all visual feedback
                            ClearDropTargets(listContainer);
                        }
                        
                        // Clean up dragged item container (vFavorites approach)
                        if (draggedItemContainer != null)
                        {
                            // Remove item from container
                            item.RemoveFromHierarchy();
                            draggedItemContainer.RemoveFromHierarchy();
                            draggedItemContainer = null;
                            
                            // Reset scale
                            item.style.scale = new Scale(Vector2.one);
                            
                            // Clear gaps and reset all transforms
                            rowGaps.Clear();
                            draggingVisualIndex = -1;
                            draggingItemFromPageAtIndex = -1;
                            insertDraggedItemAtIndex = -1;
                            // draggedItemHoldOffset = 0f;
                            
                            // Reset all item transforms before refreshing
                            if (listContainer != null)
                            {
                                foreach (var child in listContainer.Children())
                                {
                                    if (motionHandles.ContainsKey(child))
                                    {
                                        var handle = motionHandles[child];
                                        handle.Animate(new MotionTargets
                                        {
                                            HasY = true,
                                            Y = 0f
                                        }, new Transition(0.2f, EasingType.EaseOut));
                                    }
                                }
                            }
                            
                            // Refresh list to show item in new position
                            UpdateProfileList();
                        }
                    }
                    else
                    {
                        // It was just a click, not a drag - handle selection
                        // Create a MouseDownEvent-like event for HandleProfileSelection
                        // We'll handle selection directly here since we know it's a click
                        if (evt.ctrlKey || evt.commandKey)
                        {
                            // Toggle selection
                            if (selectedProfileIndices.Contains(index))
                            {
                                selectedProfileIndices.Remove(index);
                                if (selectedProfile == profile)
                                {
                                    selectedProfile = null;
                                }
                            }
                            else
                            {
                                selectedProfileIndices.Add(index);
                                selectedProfile = profile;
                            }
                            lastClickedProfileIndex = index;
                        }
                        else if (evt.shiftKey)
                        {
                            // Range selection
                            if (lastClickedProfileIndex >= 0 && lastClickedProfileIndex < allProfiles.Count)
                            {
                                int start = Math.Min(lastClickedProfileIndex, index);
                                int end = Math.Max(lastClickedProfileIndex, index);
                                selectedProfileIndices.Clear();
                                for (int i = start; i <= end; i++)
                                {
                                    selectedProfileIndices.Add(i);
                                }
                                selectedProfile = profile;
                            }
                            else
                            {
                                selectedProfileIndices.Clear();
                                selectedProfileIndices.Add(index);
                                selectedProfile = profile;
                            }
                            lastClickedProfileIndex = index;
                        }
                        else
                        {
                            // Single selection
                            selectedProfileIndices.Clear();
                            selectedProfileIndices.Add(index);
                            selectedProfile = profile;
                            lastClickedProfileIndex = index;
                        }
                        
                        UpdateProfileList();
                        UpdateProfileDetails();
                        UpdateBottomBar();
                    }
                    
                    // Clean up drag state
                    if (draggedItemContainer != null)
                    {
                        draggedItemContainer.RemoveFromHierarchy();
                        draggedItemContainer = null;
                    }
                    
                            // Clear gaps and drag state (vFavorites CancelDragging approach)
                            rowGaps.Clear();
                            draggingItemFromPageAtIndex = -1;
                            insertDraggedItemAtIndex = -1;
                            // draggedItemHoldOffset = 0f;
                            draggingVisualIndex = -1;
                    
                    draggingIndex = -1;
                    draggingElement = null;
                    hasDragged = false;
                    potentialDropIndex = -1;
                    evt.StopPropagation();
                }
            });
            
            // Click handler with multi-selection support (only if not dragging)
            // We'll handle selection in MouseDownEvent, but only if we're not starting a drag
            // The drag logic will prevent selection when dragging starts
            
            return item;
        }
        
        // CreateDragGhost removed - we now move the actual element with Motion transforms
        
        /// <summary>
        /// Recursively clones a visual element and its children
        /// </summary>
        private VisualElement CloneVisualElement(VisualElement source)
        {
            var clone = new VisualElement();
            
            // Copy all classes
            foreach (var className in source.GetClasses())
            {
                clone.AddToClassList(className);
            }
            
            // Copy style properties
            clone.style.width = source.resolvedStyle.width;
            clone.style.height = source.resolvedStyle.height;
            clone.style.backgroundColor = source.resolvedStyle.backgroundColor;
            clone.style.marginLeft = source.resolvedStyle.marginLeft;
            clone.style.marginRight = source.resolvedStyle.marginRight;
            clone.style.marginTop = source.resolvedStyle.marginTop;
            clone.style.marginBottom = source.resolvedStyle.marginBottom;
            clone.style.paddingLeft = source.resolvedStyle.paddingLeft;
            clone.style.paddingRight = source.resolvedStyle.paddingRight;
            clone.style.paddingTop = source.resolvedStyle.paddingTop;
            clone.style.paddingBottom = source.resolvedStyle.paddingBottom;
            clone.style.flexGrow = source.resolvedStyle.flexGrow;
            clone.style.flexShrink = source.resolvedStyle.flexShrink;
            clone.style.flexDirection = source.resolvedStyle.flexDirection;
            clone.style.alignItems = source.resolvedStyle.alignItems;
            
            // Clone children
            foreach (var child in source.Children())
            {
                if (child is Label label)
                {
                    var labelClone = new Label(label.text);
                    foreach (var className in label.GetClasses())
                    {
                        labelClone.AddToClassList(className);
                    }
                    labelClone.style.fontSize = label.resolvedStyle.fontSize;
                    labelClone.style.color = label.resolvedStyle.color;
                    labelClone.style.unityFontStyleAndWeight = label.resolvedStyle.unityFontStyleAndWeight;
                    clone.Add(labelClone);
                }
                else if (child is Image img)
                {
                    var imgClone = new Image();
                    imgClone.image = img.image;
                    foreach (var className in img.GetClasses())
                    {
                        imgClone.AddToClassList(className);
                    }
                    imgClone.style.width = img.resolvedStyle.width;
                    imgClone.style.height = img.resolvedStyle.height;
                    clone.Add(imgClone);
                }
                else
                {
                    // Recursively clone containers
                    var containerClone = CloneVisualElement(child);
                    clone.Add(containerClone);
                }
            }
            
            return clone;
        }
        
        /// <summary>
        /// Updates visual feedback for drop targets
        /// </summary>
        private void UpdateDropTargets(VisualElement listContainer, int targetIndex, VisualElement draggingItem)
        {
            foreach (var child in listContainer.Children())
            {
                if (child == draggingItem) continue;
                
                if (child.userData is int idx)
                {
                    if (idx == targetIndex)
                    {
                        child.AddToClassList("yucp-profile-item-drop-target");
                    }
                    else
                    {
                        child.RemoveFromClassList("yucp-profile-item-drop-target");
                    }
                }
            }
        }
        
        /// <summary>
        /// Clears all drop target visual feedback
        /// </summary>
        private void ClearDropTargets(VisualElement listContainer)
        {
            foreach (var child in listContainer.Children())
            {
                child.RemoveFromClassList("yucp-profile-item-drop-target");
                child.style.borderTopWidth = 0;
            }
            potentialDropIndex = -1;
        }
        
        // UpdateGapAnimation removed - gaps are now animated in UpdateGapAnimations using Lerp (vFavorites approach)
        
        /// <summary>
        /// Updates gap animations smoothly using Lerp (vFavorites rowGaps animation approach)
        /// </summary>
        private void UpdateGapAnimations()
        {
            if (!hasDragged)
            {
                // Clear gaps when not dragging
                if (rowGaps.Count > 0)
                {
                    rowGaps.Clear();
                }
                return;
            }
            
            var listContainer = _profileListContainer;
            if (listContainer == null) return;
            
            // Calculate deltaTime (vFavorites approach)
            double currentTime = EditorApplication.timeSinceStartup;
            float deltaTime = (float)(currentTime - (lastGapUpdateTime > 0 ? lastGapUpdateTime : currentTime));
            if (deltaTime > 0.05f) deltaTime = 0.0166f;
            lastGapUpdateTime = currentTime;
            
            float lerpSpeed = 10f; // vFavorites uses lerpSpeed = 10
            float rowHeight = draggingElement != null ? draggingElement.resolvedStyle.height : 60f;
            if (rowHeight <= 0) rowHeight = 60f;
            
            // Get all items (profiles and folders) in visual order, excluding dragged element
            var allItems = new List<VisualElement>();
            foreach (var child in listContainer.Children())
            {
                if (child.ClassListContains("yucp-folder-content")) continue;
                if (child == draggingElement) continue;
                
                // Include both profile items and folder headers
                if (child.ClassListContains("yucp-profile-item") || child.ClassListContains("yucp-folder-header"))
                {
                    allItems.Add(child);
                }
            }
            
            // Sort by visual Y position
            allItems = allItems.OrderBy(el => el.worldBound.y).ToList();
            
            // Ensure rowGaps has entries for all visual indices
            for (int i = 0; i < allItems.Count; i++)
            {
                if (!rowGaps.ContainsKey(i))
                {
                    rowGaps[i] = 0f;
                }
            }
            
            // Animate gaps using Lerp (vFavorites: rowGaps[i] -> rowHeight when i == insertDraggedItemAtIndex)
            bool needsRepaint = false;
            var keysToUpdate = rowGaps.Keys.ToList();
            
            foreach (var idx in keysToUpdate)
            {
                float currentGap = rowGaps[idx];
                // Gap should be rowHeight at insertDraggedItemAtIndex, 0 everywhere else
                float targetGap = (hasDragged && idx == insertDraggedItemAtIndex) ? rowHeight : 0f;
                
                // Lerp towards target
                float newGap = Mathf.Lerp(currentGap, targetGap, lerpSpeed * deltaTime);
                
                // Apply gap using marginTop on the corresponding element by visual index
                if (idx >= 0 && idx < allItems.Count)
                {
                    var child = allItems[idx];
                    child.style.marginTop = newGap;
                    rowGaps[idx] = newGap;
                    
                    if (Mathf.Abs(currentGap - newGap) > 0.1f)
                    {
                        needsRepaint = true;
                    }
                }
            }
            
            if (needsRepaint)
            {
                Repaint();
            }
        }
        
        private double lastGapUpdateTime = 0;
        
        /// <summary>
        /// Calculates where the item should be dropped based on mouse position
        /// </summary>
        private int CalculateDropIndex(VisualElement listContainer, Vector2 mousePos, int draggingIdx)
        {
            int dropIndex = draggingIdx;
            var sortedItems = new List<(int index, VisualElement element, float y)>();
            Vector2 localMousePos = listContainer.WorldToLocal(mousePos);
            
            // Collect all items with their indices and Y positions
            // Account for gaps (vFavorites approach)
            float accumulatedGap = 0f;
            foreach (var child in listContainer.Children())
            {
                if (child == draggingElement) continue;
                
                if (child.userData is int idx)
                {
                    Rect layout = child.layout;
                    // Add accumulated gap offset
                    float visualY = layout.y + accumulatedGap;
                    if (rowGaps.ContainsKey(idx))
                    {
                        accumulatedGap += rowGaps[idx];
                    }
                    sortedItems.Add((idx, child, visualY));
                }
            }
            
            // Sort by Y position
            sortedItems.Sort((a, b) => a.y.CompareTo(b.y));
            
            // Find where the mouse is
            for (int i = 0; i < sortedItems.Count; i++)
            {
                var item = sortedItems[i];
                Rect layout = item.element.layout;
                float yMin = layout.y;
                float yMax = layout.y + layout.height;

                if (localMousePos.y >= yMin && localMousePos.y <= yMax)
                {
                    // Mouse is over this item - check if it's in upper or lower half
                    float relativeY = localMousePos.y - yMin;
                    if (relativeY < layout.height * 0.5f)
                    {
                        // Insert before this item
                        dropIndex = item.index;
                    }
                    else
                    {
                        // Insert after this item
                        dropIndex = item.index + 1;
                    }
                    break;
                }
                else if (localMousePos.y < yMin)
                {
                    // Mouse is above this item - insert before it
                    dropIndex = item.index;
                    break;
                }
            }
            
            // If we didn't find a position, drop at the end
            if (sortedItems.Count > 0)
            {
                var last = sortedItems[sortedItems.Count - 1].element.layout;
                float lastMaxY = last.y + last.height;
                if (localMousePos.y > lastMaxY)
                {
                    dropIndex = sortedItems[sortedItems.Count - 1].index + 1;
                }
            }
            
            // Clamp to valid range (accounting for the fact that draggingIdx will be removed)
            int maxIndex = allProfiles.Count - 1;
            dropIndex = Mathf.Clamp(dropIndex, 0, maxIndex);
            
            return dropIndex;
        }
        
        // AnimateItemsForDrop removed - following Motion approach: only move dragged item, reorder immediately when crossing
        
        /// <summary>
        /// Update visual feedback for folder drop targets
        /// </summary>
        private void UpdateFolderDropTargets(VisualElement listContainer, VisualElement dropTarget)
        {
            // Clear previous targets
             foreach (var child in listContainer.Children())
            {
                child.RemoveFromClassList("yucp-folder-header-active-target");
                
                if (child == dropTarget && child.ClassListContains("yucp-folder-header"))
                {
                    child.AddToClassList("yucp-folder-header-active-target");
                }
            }
        }
        
        private void ResetStackState()
        {
            if (stackTargetElement != null)
            {
                stackTargetElement.RemoveFromClassList("yucp-profile-item-stack-target");
            }
            stackTargetElement = null;
            stackTargetIndex = -1;
            stackHoverStartTime = 0;
            stackHoverPosition = Vector2.zero;
            isStackReady = false;
        }

        private int CalculateDropIndexWithFolders(VisualElement listContainer, Vector2 mousePosition, int draggingIdx, out VisualElement folderTarget)
        {
            folderTarget = null;
            
            // Convert mouse position to local coordinates of the list container
            Vector2 localMousePos = listContainer.WorldToLocal(mousePosition);
            
            // Iterate through all children to find the best drop position
            for (int i = 0; i < listContainer.childCount; i++)
            {
                var child = listContainer[i];
                if (child == draggingElement) continue;
                
                // Check if hovering over a folder header
                if (child.ClassListContains("yucp-folder-header"))
                {
                    Rect layout = child.layout;
                    float xMin = layout.x;
                    float xMax = layout.x + layout.width;
                    float yMin = layout.y;
                    float yMax = layout.y + layout.height;
                    if (localMousePos.x >= xMin && localMousePos.x <= xMax &&
                        localMousePos.y >= yMin && localMousePos.y <= yMax)
                    {
                        folderTarget = child;
                        // Return special index indicating folder drop
                        return -2;
                    }
                }
                
                // Standard reordering logic (only valid if we are not hovering a closed folder that creates a gap)
                 // ... (Simplified: stick to original CalcDropIndex logic, but we need to intercept folder drops)
            }
            
            // Use existing logic for reordering if not dropping into a folder
            return CalculateDropIndex(listContainer, mousePosition, draggingIdx);
        }
        
        /// <summary>
        /// Reorders profiles by moving source profile to target visual position in unified order
        /// </summary>
        /// <param name="sourceProfileIndex">Index of the profile in allProfiles to move</param>
        /// <param name="targetVisualIndex">Visual position (0-based) where the item should be inserted</param>
        private void ReorderProfiles(int sourceProfileIndex, int targetVisualIndex)
        {
            if (sourceProfileIndex < 0 || sourceProfileIndex >= allProfiles.Count ||
                targetVisualIndex < 0)
            {
                return;
            }
            
            // Get the profile to move
            var profileToMove = allProfiles[sourceProfileIndex];
            string profileGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profileToMove));
            
            // Skip if profile is in a folder (folders handle their own profiles)
            if (!string.IsNullOrEmpty(profileToMove.folderName) && projectFolders.Contains(profileToMove.folderName))
            {
                return;
            }
            
            // Find the profile in unified order
            int unifiedSourceIndex = -1;
            for (int i = 0; i < unifiedOrder.Count; i++)
            {
                if (!unifiedOrder[i].isFolder && unifiedOrder[i].identifier == profileGuid)
                {
                    unifiedSourceIndex = i;
                    break;
                }
            }
            
            if (unifiedSourceIndex < 0)
            {
                // Profile not in unified order, add it
                unifiedOrder.Add(new UnifiedOrderItem { isFolder = false, identifier = profileGuid });
                unifiedSourceIndex = unifiedOrder.Count - 1;
            }
            
            // Calculate target position in unified order based on visual position
            // We need to map the visual targetIndex to a unified order position
            int unifiedTargetIndex = CalculateUnifiedOrderPositionFromVisualIndex(targetVisualIndex, unifiedSourceIndex);
            
            if (unifiedTargetIndex >= 0 && unifiedTargetIndex != unifiedSourceIndex)
            {
                // Remove from source position
                var item = unifiedOrder[unifiedSourceIndex];
                unifiedOrder.RemoveAt(unifiedSourceIndex);
                
                // Adjust target index if source was before target
                int adjustedTargetIndex = unifiedSourceIndex < unifiedTargetIndex ? unifiedTargetIndex - 1 : unifiedTargetIndex;
                
                // Insert at target position
                unifiedOrder.Insert(adjustedTargetIndex, item);
                
                // Save the new order
                SaveCustomOrder();
            }
            
            // Update selection indices
            // Note: Selection indices update is based on old profile indices, skip for now
            // TODO: Consider if this needs updating for visual indices
            // UpdateSelectionIndicesAfterReorder(sourceProfileIndex, targetVisualIndex);
            
            // Refresh the UI
            UpdateProfileList();
        }
        
        /// <summary>
        /// Calculates unified order position from visual index
        /// </summary>
        private int CalculateUnifiedOrderPositionFromVisualIndex(int visualTargetIndex, int excludeUnifiedIndex)
        {
            // Build a map of visual positions to unified order indices
            var visualToUnified = new List<int>();
            var profileGuidToIndex = allProfiles
                .Select((p, idx) => new { Profile = p, Index = idx })
                .ToDictionary(x => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(x.Profile)), x => x.Index);
            
            for (int i = 0; i < unifiedOrder.Count; i++)
            {
                if (i == excludeUnifiedIndex)
                    continue;
                    
                if (unifiedOrder[i].isFolder)
                {
                    // Folders take one visual position
                    visualToUnified.Add(i);
                }
                else
                {
                    // Profiles take one visual position (only if not in a folder)
                    if (profileGuidToIndex.TryGetValue(unifiedOrder[i].identifier, out int profileIndex))
                    {
                        var profile = allProfiles[profileIndex];
                        if (string.IsNullOrEmpty(profile.folderName) || !projectFolders.Contains(profile.folderName))
                        {
                            visualToUnified.Add(i);
                        }
                    }
                }
            }
            
            // Find the unified order index for the target visual position
            if (visualTargetIndex >= 0 && visualTargetIndex < visualToUnified.Count)
            {
                return visualToUnified[visualTargetIndex];
            }
            
            // Default to end
            return unifiedOrder.Count;
        }
        
        /// <summary>
        /// Reorders a folder in unified order
        /// </summary>
        private void ReorderFolder(string folderName, int targetVisualIndex)
        {
            // Find the folder in unified order
            int unifiedSourceIndex = -1;
            for (int i = 0; i < unifiedOrder.Count; i++)
            {
                if (unifiedOrder[i].isFolder && unifiedOrder[i].identifier == folderName)
                {
                    unifiedSourceIndex = i;
                    break;
                }
            }
            
            if (unifiedSourceIndex < 0)
            {
                // Folder not in unified order, add it
                unifiedOrder.Add(new UnifiedOrderItem { isFolder = true, identifier = folderName });
                unifiedSourceIndex = unifiedOrder.Count - 1;
            }
            
            // Calculate target position in unified order
            int unifiedTargetIndex = CalculateUnifiedOrderPositionFromVisualIndex(targetVisualIndex, unifiedSourceIndex);
            
            if (unifiedTargetIndex >= 0 && unifiedTargetIndex != unifiedSourceIndex)
            {
                // Remove from source position
                var item = unifiedOrder[unifiedSourceIndex];
                unifiedOrder.RemoveAt(unifiedSourceIndex);
                
                // Adjust target index if source was before target
                int adjustedTargetIndex = unifiedSourceIndex < unifiedTargetIndex ? unifiedTargetIndex - 1 : unifiedTargetIndex;
                
                // Insert at target position
                unifiedOrder.Insert(adjustedTargetIndex, item);
                
                // Save the new order
                SaveCustomOrder();
                
                // Refresh the UI
                UpdateProfileList();
            }
        }
        
        /// <summary>
        /// Calculates drop index for folder reordering
        /// </summary>
        private int CalculateDropIndexForFolder(VisualElement listContainer, Vector2 mousePos, string draggingFolderName)
        {
            var sortedItems = new List<(int visualIndex, VisualElement element, float y, bool isFolder, string identifier)>();
            int visualIndex = 0;
            
            // Collect all visible items (folders and uncategorized profiles) with their positions
            foreach (var child in listContainer.Children())
            {
                if (child == draggingElement) continue;
                
                if (child.ClassListContains("yucp-folder-header"))
                {
                    if (child.userData is string folderName && folderName != draggingFolderName)
                    {
                        Rect worldBound = child.worldBound;
                        sortedItems.Add((visualIndex++, child, worldBound.y, true, folderName));
                    }
                }
                else if (child.userData is int profileIdx)
                {
                    // Only count uncategorized profiles (those not in folders)
                    var profile = allProfiles[profileIdx];
                    if (string.IsNullOrEmpty(profile.folderName) || !projectFolders.Contains(profile.folderName))
                    {
                        Rect worldBound = child.worldBound;
                        sortedItems.Add((visualIndex++, child, worldBound.y, false, profileIdx.ToString()));
                    }
                }
            }
            
            // Sort by Y position
            sortedItems.Sort((a, b) => a.y.CompareTo(b.y));
            
            // Find where the mouse is
            for (int i = 0; i < sortedItems.Count; i++)
            {
                var item = sortedItems[i];
                Rect worldBound = item.element.worldBound;
                
                if (worldBound.Contains(mousePos))
                {
                    float relativeY = mousePos.y - worldBound.y;
                    if (relativeY < worldBound.height * 0.5f)
                    {
                        return item.visualIndex;
                    }
                    else
                    {
                        return item.visualIndex + 1;
                    }
                }
                else if (mousePos.y < worldBound.y)
                {
                    return item.visualIndex;
                }
            }
            
            // If we didn't find a position, drop at the end
            if (sortedItems.Count > 0)
            {
                return sortedItems[sortedItems.Count - 1].visualIndex + 1;
            }
            
            return 0;
        }
        
        /// <summary>
        /// Updates selection indices after reordering
        /// </summary>
        private void UpdateSelectionIndicesAfterReorder(int oldIndex, int newIndex)
        {
            var newIndices = new HashSet<int>();
            
            foreach (int idx in selectedProfileIndices)
            {
                if (idx == oldIndex)
                {
                    // The moved item
                    newIndices.Add(newIndex);
                }
                else if (oldIndex < newIndex)
                {
                    // Source was before target - items between move down
                    if (idx > oldIndex && idx <= newIndex)
                    {
                        newIndices.Add(idx - 1);
                    }
                    else
                    {
                        newIndices.Add(idx);
                    }
                }
                else
                {
                    // Source was after target - items between move up
                    if (idx >= newIndex && idx < oldIndex)
                    {
                        newIndices.Add(idx + 1);
                    }
                    else
                    {
                        newIndices.Add(idx);
                    }
                }
            }
            
            selectedProfileIndices = newIndices;
            
            // Update selectedProfile if it was moved
            if (selectedProfile != null)
            {
                int currentIndex = allProfiles.IndexOf(selectedProfile);
                if (currentIndex >= 0)
                {
                    selectedProfileIndices.Clear();
                    selectedProfileIndices.Add(currentIndex);
                    lastClickedProfileIndex = currentIndex;
                }
            }
        }
        
        private void ShowProfileContextMenu(ExportProfile profile, int index, MouseDownEvent evt)
        {
            // Select the profile if not already selected
            if (!selectedProfileIndices.Contains(index))
            {
                selectedProfileIndices.Clear();
                selectedProfileIndices.Add(index);
                selectedProfile = profile;
                lastClickedProfileIndex = index;
                UpdateProfileList();
                UpdateProfileDetails();
                UpdateBottomBar();
            }
            
            var menu = new GenericMenu();
            
            // Multi-select: Group into Folder option
            if (selectedProfileIndices.Count >= 2)
            {
                menu.AddItem(new GUIContent("Group into Folder..."), false, () => 
                {
                    GroupSelectedProfilesIntoFolder();
                });
                menu.AddSeparator("");
            }
            
            // Export option
            menu.AddItem(new GUIContent("Export"), false, () => 
            {
                ExportSingleProfile(profile);
            });
            
            menu.AddSeparator("");
            
            // Clone option
            menu.AddItem(new GUIContent("Clone"), false, () => 
            {
                CloneProfile(profile);
            });
            
            // Duplicate option (same as clone)
            menu.AddItem(new GUIContent("Duplicate"), false, () => 
            {
                CloneProfile(profile);
            });
            
            menu.AddSeparator("");
            
            // Rename option
            menu.AddItem(new GUIContent("Rename"), false, () => 
            {
                StartRenameProfile(profile);
            });
            
            // Delete option
            menu.AddItem(new GUIContent("Delete"), false, () => 
            {
                DeleteProfile(profile);
            });
            
            menu.AddSeparator("");
            
            // Select in Project option
            menu.AddItem(new GUIContent("Select in Project"), false, () => 
            {
                Selection.activeObject = profile;
                EditorGUIUtility.PingObject(profile);
            });
            
            if (!string.IsNullOrEmpty(profile.profileSaveLocation) && System.IO.Directory.Exists(profile.profileSaveLocation))
            {
                menu.AddItem(new GUIContent("Show in Explorer"), false, () => 
                {
                    EditorUtility.RevealInFinder(profile.profileSaveLocation);
                });
            }

            menu.AddSeparator("");
            
            // Move to Folder option
            if (projectFolders.Count > 0)
            {
                // Root folder option (if currently in a folder)
                if (!string.IsNullOrEmpty(profile.folderName))
                {
                    menu.AddItem(new GUIContent("Move to Folder/_Root"), false, () => 
                    {
                        MoveProfileToFolder(profile, "");
                    });
                     menu.AddSeparator("Move to Folder/");
                }
                
                foreach (var folder in projectFolders)
                {
                    // Skip current folder
                    if (folder == profile.folderName) continue;
                    
                    menu.AddItem(new GUIContent($"Move to Folder/{folder}"), false, () => 
                    {
                        MoveProfileToFolder(profile, folder);
                    });
                }
            }
            else
            {
               menu.AddDisabledItem(new GUIContent("Move to Folder"));
            }
            
            menu.ShowAsContext();
        }
        
        private void StartRenameProfile(ExportProfile profile)
        {
            // Focus on the package name field in the details panel if visible
            if (selectedProfile == profile && _profileDetailsContainer.style.display == DisplayStyle.Flex)
            {
                // The package name field should get focus
                EditorUtility.DisplayDialog("Rename Profile", 
                    $"Edit the 'Package Name' field in the details panel to rename this profile.\n\nCurrent name: {profile.packageName}", 
                    "OK");
            }
        }
        
        private void ExportSingleProfile(ExportProfile profile)
        {
            ExportProfile(profile);
        }

        private void HandleProfileSelection(int index, MouseDownEvent evt)
        {
            if (evt.ctrlKey || evt.commandKey)
            {
                // Ctrl/Cmd+Click: Toggle individual selection
                if (selectedProfileIndices.Contains(index))
                {
                    selectedProfileIndices.Remove(index);
                }
                else
                {
                    selectedProfileIndices.Add(index);
                }
                lastClickedProfileIndex = index;
            }
            else if (evt.shiftKey && lastClickedProfileIndex >= 0)
            {
                // Shift+Click: Range selection
                int start = Mathf.Min(lastClickedProfileIndex, index);
                int end = Mathf.Max(lastClickedProfileIndex, index);
                
                for (int i = start; i <= end; i++)
                {
                    if (i < allProfiles.Count)
                    {
                        selectedProfileIndices.Add(i);
                    }
                }
            }
            else
            {
                // Normal click: Single selection
                selectedProfileIndices.Clear();
                selectedProfileIndices.Add(index);
                lastClickedProfileIndex = index;
            }
            
            // Update selected profile
            if (selectedProfileIndices.Count > 0)
            {
                int firstIndex = selectedProfileIndices.Min();
                selectedProfile = allProfiles[firstIndex];
            }
            else
            {
                selectedProfile = null;
            }
            
            // Refresh UI
            UpdateProfileList();
            UpdateProfileDetails();
            UpdateBottomBar();
            
            // Close overlay when profile is selected (for mobile)
            CloseOverlay();
        }

        public void UpdateProfileDetails()
        {
            if (selectedProfile == null)
            {
                _emptyState.style.display = DisplayStyle.Flex;
                _profileDetailsContainer.style.display = DisplayStyle.None;
                return;
            }
            
            // Save current inspector height to profile before switching
            if (selectedProfile != null && currentResizableContainer != null)
            {
                float currentHeight = currentResizableContainer.resolvedStyle.height;
                if (currentHeight <= 0)
                {
                    currentHeight = currentResizableContainer.layout.height;
                }
                if (currentHeight > 0)
                {
                    Undo.RecordObject(selectedProfile, "Save Inspector Height");
                    selectedProfile.InspectorHeight = currentHeight;
                    EditorUtility.SetDirty(selectedProfile);
                }
            }
            
            _emptyState.style.display = DisplayStyle.None;
            _profileDetailsContainer.style.display = DisplayStyle.Flex;
            
            // Reset scroll position when switching profiles to prevent scroll position bug
            var oldScrollView = _profileDetailsContainer.Q<ScrollView>(className: "yucp-inspector-list");
            if (oldScrollView != null)
            {
                oldScrollView.verticalScroller.value = 0;
            }
            
            _profileDetailsContainer.Clear();
            
            // Reset resize tracking
            currentResizableContainer = null;
            currentResizeRect = Rect.zero;
            _bannerImageContainer = null;
            _bannerGradientOverlay = null;
            _metadataSection = null;
            _bannerContainer = null;
            
            if (_rightPaneScrollView != null)
            {
                var existingButtons = _rightPaneScrollView.Query<Button>(className: "yucp-overlay-hover-button").ToList();
                var oldButtons = _rightPaneScrollView.Query<Button>(className: "yucp-banner-change-button").ToList();
                existingButtons.AddRange(oldButtons);
                foreach (var btn in existingButtons)
                {
                    btn.RemoveFromHierarchy();
                }
                _changeBannerButton = null;
            }
            
            // Check if multiple profiles are selected
            if (selectedProfileIndices.Count > 1)
            {
                // Show bulk editor for multiple profiles
                var bulkEditorSection = CreateBulkEditorSection();
                _profileDetailsContainer.Add(bulkEditorSection);
                
                // Show summary for selected profiles
                var summarySection = CreateMultiProfileSummarySection();
                _profileDetailsContainer.Add(summarySection);
            }
            else
            {
                // Single profile editor
                // Remove ScrollView padding so banner can span full width
                _rightPaneScrollView.style.paddingLeft = 0;
                _rightPaneScrollView.style.paddingRight = 0;
                _rightPaneScrollView.style.paddingTop = 0;
                _rightPaneScrollView.style.paddingBottom = 0;
                
                // Banner Section (inside ScrollView so it scrolls with content) - spans full width
                var bannerSection = CreateBannerSection(selectedProfile);
                _profileDetailsContainer.Add(bannerSection);
                
                // Setup parallax scrolling for banner
                SetupParallaxScrolling();
                
                // Wrap all other sections in a container with padding
                // Position it over the banner with negative margin
                var contentWrapper = new VisualElement();
                contentWrapper.style.position = Position.Relative;
                contentWrapper.style.paddingLeft = 20;
                contentWrapper.style.paddingRight = 24;
                contentWrapper.style.paddingTop = 0;
                contentWrapper.style.paddingBottom = 20;
                contentWrapper.style.marginTop = -400;
                contentWrapper.style.flexGrow = 0;
                contentWrapper.style.flexShrink = 1;
                contentWrapper.style.flexBasis = StyleKeyword.Auto;
                
                // Make contentWrapper ignore pointer events in the banner area so hover works
                // But we can't easily do this, so we'll handle hover on the banner section itself
                
                // Package Metadata Section
                _metadataSection = CreateMetadataSection(selectedProfile);
                contentWrapper.Add(_metadataSection);
                
                // Register callback to update button position when metadata section geometry changes
                _metadataSection.RegisterCallback<GeometryChangedEvent>(evt => UpdateBannerButtonPosition());
                
                // Quick Summary Section
                var summarySection = CreateSummarySection(selectedProfile);
                contentWrapper.Add(summarySection);
                
                // Validation Section
                var validationSection = CreateValidationSection(selectedProfile);
                contentWrapper.Add(validationSection);
                
                // Export Options Section
                var optionsSection = CreateExportOptionsSection(selectedProfile);
                contentWrapper.Add(optionsSection);
                
                var foldersSection = CreateFoldersSection(selectedProfile);
                contentWrapper.Add(foldersSection);
                
                // Bundled Profiles Section (for composite profiles)
                var bundledProfilesSection = BundledProfilesSection.CreateBundledProfilesSection(selectedProfile, () => UpdateProfileDetails());
                contentWrapper.Add(bundledProfilesSection);
                
                // Export Inspector Section
                var inspectorSection = CreateExportInspectorSection(selectedProfile);
                contentWrapper.Add(inspectorSection);
                
                // Exclusion Filters Section
                var exclusionSection = CreateExclusionFiltersSection(selectedProfile);
                contentWrapper.Add(exclusionSection);
                
                // Dependencies Section
                var dependenciesSection = CreateDependenciesSection(selectedProfile);
                contentWrapper.Add(dependenciesSection);
                
                // Obfuscation Section
                var obfuscationSection = CreateObfuscationSection(selectedProfile);
                contentWrapper.Add(obfuscationSection);
                
                // Quick Actions
                var actionsSection = CreateQuickActionsSection(selectedProfile);
                contentWrapper.Add(actionsSection);
                
                // Package Signing Section
                var signingSection = CreatePackageSigningSection(selectedProfile);
                contentWrapper.Add(signingSection);
                
                _profileDetailsContainer.Add(contentWrapper);
                
                // Add banner button directly to ScrollView so it's definitely on top and clickable
                _changeBannerButton = new Button(() => OnChangeBannerClicked(selectedProfile));
                _changeBannerButton.text = "Change";
                _changeBannerButton.AddToClassList("yucp-overlay-hover-button");
                _changeBannerButton.style.position = Position.Absolute;
                _changeBannerButton.style.bottom = StyleKeyword.Auto;
                _changeBannerButton.style.left = StyleKeyword.Auto;
                _changeBannerButton.style.right = StyleKeyword.Auto;
                _changeBannerButton.style.opacity = 0f;
                _changeBannerButton.pickingMode = PickingMode.Ignore;
                
                // Register hover events on banner section to show/hide button
                Action showButton = () =>
                {
                    if (_changeBannerButton != null)
                    {
                        _changeBannerButton.style.opacity = 1f;
                        _changeBannerButton.pickingMode = PickingMode.Position;
                    }
                };
                Action hideButton = () =>
                {
                    if (_changeBannerButton != null)
                    {
                        _changeBannerButton.style.opacity = 0f;
                        _changeBannerButton.pickingMode = PickingMode.Ignore;
                    }
                };
                
                // Track mouse position to detect when hovering between top bar bottom and metadata top
                _rightPaneScrollView.RegisterCallback<MouseMoveEvent>(evt =>
                {
                    if (_changeBannerButton == null || _metadataSection == null) return;
                    
                    // Find top bar element
                    var topBar = rootVisualElement.Q(className: "yucp-top-bar");
                    if (topBar == null) return;
                    
                    var topBarBounds = topBar.worldBound;
                    var metadataBounds = _metadataSection.worldBound;
                    var scrollViewBounds = _rightPaneScrollView.worldBound;
                    
                    // Convert mouse position to world coordinates
                    var mouseY = scrollViewBounds.y + evt.localMousePosition.y;
                    
                    // Detection window: from bottom of top bar to top of metadata section
                    var detectionTop = topBarBounds.y + topBarBounds.height;
                    var detectionBottom = metadataBounds.y;
                    
                    bool isInDetectionWindow = mouseY >= detectionTop && mouseY <= detectionBottom;
                    
                    if (isInDetectionWindow && _changeBannerButton.style.opacity.value < 0.5f)
                    {
                        showButton();
                    }
                    else if (!isInDetectionWindow && _changeBannerButton.style.opacity.value > 0.5f)
                    {
                        hideButton();
                    }
                });
                
                
                // Update button position when geometry changes
                _rightPaneScrollView.RegisterCallback<GeometryChangedEvent>(evt => UpdateBannerButtonPosition());
                _rightPaneScrollView.Add(_changeBannerButton);
                
                if (selectedProfile != null && selectedProfile.foldersToExport.Count > 0)
                {
                    if (!selectedProfile.HasScannedAssets)
                    {
                        EditorApplication.delayCall += () =>
                        {
                            if (selectedProfile != null)
                            {
                                ScanAssetsForInspector(selectedProfile, silent: true);
                            }
                        };
                    }
                }
                
                if (selectedProfile.dependencies.Count == 0 && selectedProfile.foldersToExport.Count > 0)
                {
                    EditorApplication.delayCall += () =>
                    {
                        if (selectedProfile != null && selectedProfile.dependencies.Count == 0)
                        {
                            ScanProfileDependencies(selectedProfile, silent: true);
                        }
                    };
                }
            }
        }

        private VisualElement CreateMetadataSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.AddToClassList("yucp-metadata-section");
            
            // Hero-style header with icon and name
            var headerRow = new VisualElement();
            headerRow.AddToClassList("yucp-metadata-header");
            headerRow.style.flexDirection = FlexDirection.Row;
            headerRow.style.alignItems = Align.Center;
            headerRow.style.marginBottom = 16;
            
            // Icon preview - clickable to change
            var iconContainer = new VisualElement();
            iconContainer.AddToClassList("yucp-metadata-icon-container");
            iconContainer.tooltip = "Click to change icon";
            
            var iconImageContainer = new VisualElement();
            iconImageContainer.AddToClassList("yucp-metadata-icon-image-container");
            
            var iconImage = new Image();
            Texture2D displayIcon = profile.icon;
            if (displayIcon == null)
            {
                displayIcon = GetPlaceholderTexture();
            }
            iconImage.image = displayIcon;
            iconImage.AddToClassList("yucp-metadata-icon-image");
            iconImageContainer.Add(iconImage);
            
            // Change icon button overlay
            iconContainer.Add(iconImageContainer);
            CreateHoverOverlayButton("Change", () => BrowseForIcon(profile), iconContainer);
            headerRow.Add(iconContainer);
            
            // Name and version in a column
            var nameVersionColumn = new VisualElement();
            nameVersionColumn.style.flexGrow = 1;
            nameVersionColumn.style.marginLeft = 16;
            
            // Package Name - large, prominent
            var nameField = new TextField { value = string.IsNullOrEmpty(profile.packageName) ? "Untitled Package" : profile.packageName };
            nameField.AddToClassList("yucp-metadata-name-field");
            nameField.tooltip = "Unique identifier for your package";
            nameField.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Package Name");
                    profile.packageName = evt.newValue;
                    profile.profileName = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    
                    // Schedule delayed rename
                    lastPackageNameChangeTime = EditorApplication.timeSinceStartup;
                    pendingRenameProfile = profile;
                    pendingRenamePackageName = evt.newValue;
                    
                    UpdateProfileList();
                }
            });
            nameVersionColumn.Add(nameField);
            
            // Version badge
            var versionRow = new VisualElement();
            versionRow.style.flexDirection = FlexDirection.Row;
            versionRow.style.alignItems = Align.Center;
            versionRow.style.marginTop = 6;
            
            var versionLabel = new Label("Version:");
            versionLabel.AddToClassList("yucp-label-small");
            versionLabel.style.marginRight = 6;
            versionRow.Add(versionLabel);
            
            var versionField = new TextField { value = profile.version };
            versionField.AddToClassList("yucp-input");
            versionField.AddToClassList("yucp-metadata-version-field");
            versionField.tooltip = "Package version (X.Y.Z)";
            versionField.style.width = 120;
            versionField.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Version");
                    profile.version = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    UpdateProfileList();
                    UpdateValidationDisplay(profile);
                }
            });
            versionRow.Add(versionField);
            nameVersionColumn.Add(versionRow);
            
            headerRow.Add(nameVersionColumn);
            section.Add(headerRow);
            
            // Description - prominent, multiline
            var descLabel = new Label("Description");
            descLabel.AddToClassList("yucp-label");
            descLabel.style.marginTop = 4;
            descLabel.style.marginBottom = 6;
            section.Add(descLabel);
            
            var descField = new TextField { value = profile.description, multiline = true };
            descField.AddToClassList("yucp-input");
            descField.AddToClassList("yucp-input-multiline");
            descField.AddToClassList("yucp-metadata-description-field");
            descField.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Description");
                    profile.description = evt.newValue;
                    EditorUtility.SetDirty(profile);
                }
            });
            section.Add(descField);
            
            // Author field - compact, single-line
            var authorLabel = new Label("Author");
            authorLabel.AddToClassList("yucp-label");
            authorLabel.style.marginTop = 4;
            authorLabel.style.marginBottom = 6;
            section.Add(authorLabel);
            
            var authorField = new TextField { value = profile.author };
            authorField.AddToClassList("yucp-input");
            authorField.AddToClassList("yucp-metadata-author-field");
            authorField.tooltip = "Author(s) - separate multiple authors with commas";
            authorField.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Author");
                    profile.author = evt.newValue;
                    EditorUtility.SetDirty(profile);
                }
            });
            section.Add(authorField);
            
            // Tags section - Modern design
            var tagsSection = new VisualElement();
            tagsSection.AddToClassList("yucp-tags-section");
            
            var tagsLabel = new Label("Tags");
            tagsLabel.AddToClassList("yucp-label");
            tagsLabel.style.marginTop = 16;
            tagsLabel.style.marginBottom = 8;
            tagsSection.Add(tagsLabel);
            
            // Tokenized Tag Input
            var tokenizedTags = new YUCP.DevTools.Editor.PackageExporter.UI.Components.TokenizedTagInput();
            
            // Collect available tags (Presets + Global Custom from EditorPrefs)
            var presetTagsType2 = typeof(YUCP.DevTools.Editor.PackageExporter.ExportProfile);
            var presetTagsField2 = presetTagsType2.GetField("AvailablePresetTags", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
            var availablePresets = presetTagsField2?.GetValue(null) as List<string> ?? new List<string>();
            
            string rawGlobalTags = EditorPrefs.GetString("YUCP_GlobalCustomTags", "");
            var globalTags = !string.IsNullOrEmpty(rawGlobalTags) 
                ? rawGlobalTags.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries).ToList() 
                : new List<string>();

            var allAvailable = availablePresets.Union(globalTags).Distinct().ToList();
            tokenizedTags.SetAvailableTags(allAvailable);
            
            tokenizedTags.SetSelectedTags(profile.GetAllTags());
            
            tokenizedTags.OnTagsChanged += (newTags) => {
                 if (profile != null) 
                 {
                    Undo.RecordObject(profile, "Change Tags");
                    
                    var newPresets = new List<string>();
                    var newCustoms = new List<string>();
                    var newlyCreated = new List<string>();
                    
                    foreach(var tag in newTags)
                    {
                        if (availablePresets.Contains(tag))
                        {
                            newPresets.Add(tag);
                        }
                        else
                        {
                            newCustoms.Add(tag);
                            if (!globalTags.Contains(tag))
                            {
                                newlyCreated.Add(tag);
                            }
                        }
                    }
                    
                    profile.presetTags = newPresets;
                    profile.customTags = newCustoms;
                    EditorUtility.SetDirty(profile);
                    
                    // Persist new tags globally
                    if (newlyCreated.Count > 0)
                    {
                        globalTags.AddRange(newlyCreated);
                        EditorPrefs.SetString("YUCP_GlobalCustomTags", string.Join("|", globalTags));
                        
                        // Update available options
                        allAvailable = availablePresets.Union(globalTags).Distinct().ToList();
                        tokenizedTags.SetAvailableTags(allAvailable);
                    }
                    
                    UpdateProfileList(); // Refresh sidebar filters
                 }
            };
            
            tagsSection.Add(tokenizedTags);
            
            // Allow layout pass then attach overlay
            tagsSection.schedule.Execute(() => tokenizedTags.AttachOverlayToRoot(rootVisualElement));
            section.Add(tagsSection);
            
            // Official Product Links section
            var linksLabel = new Label("Official Product Links");
            linksLabel.AddToClassList("yucp-label");
            linksLabel.style.marginTop = 16;
            linksLabel.style.marginBottom = 6;
            section.Add(linksLabel);
            
            var linksContainer = new VisualElement();
            linksContainer.AddToClassList("yucp-product-links-container");
            
            // Add existing links
            if (profile.productLinks != null)
            {
                foreach (var link in profile.productLinks)
                {
                    linksContainer.Add(CreateProductLinkCard(profile, link));
                }
            }
            
            // Add Link button
            var addLinkButton = new Button(() => AddProductLink(profile, linksContainer));
            addLinkButton.text = "+ Add Link";
            addLinkButton.AddToClassList("yucp-button");
            addLinkButton.AddToClassList("yucp-button-secondary");
            addLinkButton.style.marginTop = 8;
            addLinkButton.style.marginBottom = 4;
            linksContainer.Add(addLinkButton);
            
            section.Add(linksContainer);
            
            return section;
        }

        private VisualElement CreateProductLinkCard(ExportProfile profile, ProductLink link)
        {
            var card = new VisualElement();
            card.AddToClassList("yucp-product-link-card");
            
            var cardContent = new VisualElement();
            cardContent.AddToClassList("yucp-product-link-content");
            cardContent.style.flexDirection = FlexDirection.Row;
            cardContent.style.alignItems = Align.Center;
            
            // Icon container - clickable to set custom icon
            var iconContainer = new VisualElement();
            iconContainer.AddToClassList("yucp-product-link-icon");
            iconContainer.tooltip = "Click to set custom icon";
            var iconImage = new Image();
            
            Texture2D displayIcon = link.GetDisplayIcon();
            if (displayIcon != null)
            {
                iconImage.image = displayIcon;
            }
            else
            {
                iconImage.image = GetPlaceholderTexture();
                // Fetch favicon if URL is provided and no custom icon
                if (!string.IsNullOrEmpty(link.url))
                {
                    FetchFavicon(profile, link, iconImage);
                }
            }
            
            iconContainer.Add(iconImage);
            
            // Add hover overlay button to browse for custom icon
            CreateHoverOverlayButton("+", () => BrowseForProductLinkIcon(profile, link, iconImage), iconContainer);
            
            cardContent.Add(iconContainer);
            
            // Link info container
            var infoContainer = new VisualElement();
            infoContainer.style.flexGrow = 1;
            infoContainer.style.marginLeft = 12;
            
            // Label field (optional)
            var labelRow = new VisualElement();
            labelRow.style.position = Position.Relative;
            var labelField = new TextField { value = link.label };
            labelField.AddToClassList("yucp-input");
            labelField.AddToClassList("yucp-product-link-label");
            
            Label labelPlaceholder = null;
            if (string.IsNullOrEmpty(link.label))
            {
                labelPlaceholder = new Label("Enter link name here (optional)");
                labelPlaceholder.AddToClassList("yucp-label-secondary");
                labelPlaceholder.style.position = Position.Absolute;
                labelPlaceholder.style.left = 8;
                labelPlaceholder.style.top = 4;
                labelPlaceholder.pickingMode = PickingMode.Ignore;
                labelRow.Add(labelPlaceholder);
            }
            labelField.tooltip = "Enter a display name for this link (e.g., 'Gumroad', 'Itch.io')";
            
            labelField.RegisterValueChangedCallback(evt =>
            {
                if (labelPlaceholder != null)
                {
                    if (string.IsNullOrEmpty(evt.newValue))
                    {
                        labelPlaceholder.style.display = DisplayStyle.Flex;
                        labelField.style.opacity = 0.7f;
                    }
                    else
                    {
                        labelPlaceholder.style.display = DisplayStyle.None;
                        labelField.style.opacity = 1f;
                    }
                }
                
                if (profile != null && link != null)
                {
                    Undo.RecordObject(profile, "Change Link Label");
                    link.label = evt.newValue;
                    EditorUtility.SetDirty(profile);
                }
            });
            labelRow.Add(labelField);
            infoContainer.Add(labelRow);
            
            // URL field
            var urlRow = new VisualElement();
            urlRow.style.position = Position.Relative;
            urlRow.style.marginTop = 6;
            var urlField = new TextField { value = link.url };
            urlField.AddToClassList("yucp-input");
            urlField.AddToClassList("yucp-product-link-url");
            
            Label urlPlaceholder = null;
            if (string.IsNullOrEmpty(link.url))
            {
                urlPlaceholder = new Label("Enter link URL here (e.g., https://example.com)");
                urlPlaceholder.AddToClassList("yucp-label-secondary");
                urlPlaceholder.style.position = Position.Absolute;
                urlPlaceholder.style.left = 8;
                urlPlaceholder.style.top = 4;
                urlPlaceholder.pickingMode = PickingMode.Ignore;
                urlRow.Add(urlPlaceholder);
            }
            urlField.tooltip = "Enter the full URL to the product page (e.g., https://example.gumroad.com/l/product)";
            
            urlField.RegisterValueChangedCallback(evt =>
            {
                if (urlPlaceholder != null)
                {
                    if (string.IsNullOrEmpty(evt.newValue))
                    {
                        urlPlaceholder.style.display = DisplayStyle.Flex;
                        urlField.style.opacity = 0.7f;
                    }
                    else
                    {
                        urlPlaceholder.style.display = DisplayStyle.None;
                        urlField.style.opacity = 1f;
                    }
                }
                
                if (profile != null && link != null)
                {
                    Undo.RecordObject(profile, "Change Link URL");
                    link.url = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    
                    // Always fetch and save icon when URL is entered/changed
                    if (!string.IsNullOrEmpty(evt.newValue))
                    {
                        EditorApplication.delayCall += () =>
                        {
                            if (profile != null && link != null && !string.IsNullOrEmpty(link.url))
                            {
                                FetchFavicon(profile, link, iconImage);
                            }
                        };
                    }
                }
            });
            
            // Also fetch favicon when user finishes typing (on blur) as backup
            urlField.RegisterCallback<BlurEvent>(evt =>
            {
                Debug.Log($"[YUCP PackageExporter] URL field blur event triggered for URL: {link.url}");
                if (profile != null && link != null && !string.IsNullOrEmpty(link.url))
                {
                    Debug.Log($"[YUCP PackageExporter] Calling FetchFavicon from blur event");
                    FetchFavicon(profile, link, iconImage);
                }
                else
                {
                    Debug.LogWarning($"[YUCP PackageExporter] Blur event: profile or link is null, or URL is empty. Profile: {profile != null}, Link: {link != null}, URL: {link?.url ?? "null"}");
                }
            });
            urlRow.Add(urlField);
            infoContainer.Add(urlRow);
            
            cardContent.Add(infoContainer);
            
            // Action buttons
            var buttonContainer = new VisualElement();
            buttonContainer.style.flexDirection = FlexDirection.Row;
            buttonContainer.style.marginLeft = 8;
            
            // Clear custom icon button (only show if custom icon is set)
            if (link.customIcon != null)
            {
                var clearIconButton = new Button(() =>
                {
                    if (profile != null && link != null)
                    {
                        Undo.RecordObject(profile, "Clear Custom Link Icon");
                        link.customIcon = null;
                        Texture2D displayIcon = link.GetDisplayIcon();
                        iconImage.image = displayIcon != null ? displayIcon : GetPlaceholderTexture();
                        EditorUtility.SetDirty(profile);
                    }
                });
                clearIconButton.text = "↺";
                clearIconButton.tooltip = "Clear custom icon (use auto-fetched)";
                clearIconButton.AddToClassList("yucp-button");
                clearIconButton.AddToClassList("yucp-button-icon");
                clearIconButton.style.width = 32;
                clearIconButton.style.height = 32;
                buttonContainer.Add(clearIconButton);
            }
            
            // Open in browser button
            var openButton = new Button(() =>
            {
                if (!string.IsNullOrEmpty(link.url))
                {
                    Application.OpenURL(link.url);
                }
            });
            openButton.text = "→";
            openButton.tooltip = "Open in browser";
            openButton.AddToClassList("yucp-button");
            openButton.AddToClassList("yucp-button-icon");
            openButton.style.width = 32;
            openButton.style.height = 32;
            if (link.customIcon != null)
            {
                openButton.style.marginLeft = 4;
            }
            buttonContainer.Add(openButton);
            
            // Remove button
            var removeButton = new Button(() =>
            {
                if (profile != null && profile.productLinks != null)
                {
                    Undo.RecordObject(profile, "Remove Product Link");
                    profile.productLinks.Remove(link);
                    card.RemoveFromHierarchy();
                    EditorUtility.SetDirty(profile);
                }
            });
            removeButton.text = "×";
            removeButton.tooltip = "Remove link";
            removeButton.AddToClassList("yucp-button");
            removeButton.AddToClassList("yucp-button-icon");
            removeButton.style.width = 32;
            removeButton.style.height = 32;
            removeButton.style.marginLeft = 4;
            buttonContainer.Add(removeButton);
            
            cardContent.Add(buttonContainer);
            card.Add(cardContent);
            
            return card;
        }

        private void AddProductLink(ExportProfile profile, VisualElement container)
        {
            if (profile.productLinks == null)
            {
                profile.productLinks = new List<ProductLink>();
            }
            
            var newLink = new ProductLink();
            Undo.RecordObject(profile, "Add Product Link");
            profile.productLinks.Add(newLink);
            EditorUtility.SetDirty(profile);
            
            // Find the add button (last child)
            var addButton = container.Children().Last();
            var linkCard = CreateProductLinkCard(profile, newLink);
            container.Insert(container.childCount - 1, linkCard);
        }

        private void FetchFavicon(ExportProfile profile, ProductLink link, Image iconImage)
        {
            Debug.Log($"[YUCP PackageExporter] FetchFavicon called for URL: {link.url}");
            
            if (string.IsNullOrEmpty(link.url))
            {
                Debug.LogWarning("[YUCP PackageExporter] FetchFavicon: URL is empty, aborting");
                return;
            }
            
            // Show loading state
            iconImage.image = GetPlaceholderTexture();
            
            // Extract domain from URL
            string domain = ExtractDomain(link.url);
            Debug.Log($"[YUCP PackageExporter] Extracted domain: {domain}");
            
            // Reduce to base domain for Brandfetch and favicon (e.g. yeusepe.gumroad.com -> gumroad.com)
            string baseDomain = ExtractBaseDomain(domain);
            Debug.Log($"[YUCP PackageExporter] Base domain: {baseDomain}");
            
            if (string.IsNullOrEmpty(baseDomain))
            {
                Debug.LogWarning("[YUCP PackageExporter] FetchFavicon: Failed to extract domain, aborting");
                return;
            }
            
            // Start async fetch
            EditorApplication.update += CheckFaviconRequest;
            
            var requestData = new FaviconRequestData
            {
                profile = profile,
                link = link,
                iconImage = iconImage,
                domain = baseDomain,
                currentUrlIndex = 0,
                request = null,
                isBrandfetchSearch = false,
                brandId = null
            };
            
            faviconRequests.Add(requestData);
            Debug.Log($"[YUCP PackageExporter] Starting favicon request for domain: {domain}");
            StartFaviconRequest(requestData);
        }

        private class FaviconRequestData
        {
            public ExportProfile profile;
            public ProductLink link;
            public Image iconImage;
            public string domain;
            public int currentUrlIndex;
            public UnityWebRequest request;
            public bool isBrandfetchSearch; // True if this request is for Brandfetch search API
            public string brandId; // Brandfetch brandId after search
        }

        private List<FaviconRequestData> faviconRequests = new List<FaviconRequestData>();

        private void CheckFaviconRequest()
        {
            for (int i = faviconRequests.Count - 1; i >= 0; i--)
            {
                var requestData = faviconRequests[i];
                
                if (requestData.request == null)
                {
                    Debug.LogWarning($"[YUCP PackageExporter] CheckFaviconRequest: Request is null for domain {requestData.domain}");
                    continue;
                }
                
                if (requestData.request.isDone)
                {
                    Debug.Log($"[YUCP PackageExporter] Request completed for domain {requestData.domain}, result: {requestData.request.result}, URL index: {requestData.currentUrlIndex}");
                    bool success = false;
                    
                    if (requestData.request.result == UnityWebRequest.Result.Success)
                    {
                        // Handle Brandfetch search API response
                        if (requestData.isBrandfetchSearch)
                        {
                            string jsonResponse = requestData.request.downloadHandler.text;
                            Debug.Log($"[YUCP PackageExporter] Brandfetch search response: {jsonResponse}");
                            
                            // Parse JSON to extract brandId (simple string parsing)
                            string brandId = ExtractBrandIdFromJson(jsonResponse);
                            if (!string.IsNullOrEmpty(brandId))
                            {
                                Debug.Log($"[YUCP PackageExporter] Found Brandfetch brandId: {brandId}");
                                requestData.brandId = brandId;
                                requestData.isBrandfetchSearch = false;
                                // Now fetch the actual icon
                                StartFaviconRequest(requestData);
                                continue;
                            }
                            else
                            {
                                Debug.LogWarning("[YUCP PackageExporter] Failed to extract brandId from Brandfetch response");
                                // Fall through to try next URL
                            }
                        }
                        
                        byte[] imageData = requestData.request.downloadHandler.data;
                        if (imageData != null && imageData.Length > 0)
                        {
                            Debug.Log($"[YUCP PackageExporter] Downloaded {imageData.Length} bytes of image data");
                            
                            // Check if this is an ICO file (ICO files start with 00 00 01 00)
                            bool isIcoFile = imageData.Length >= 4 && 
                                           imageData[0] == 0x00 && imageData[1] == 0x00 && 
                                           imageData[2] == 0x01 && imageData[3] == 0x00;
                            
                            if (isIcoFile)
                            {
                                Debug.Log($"[YUCP PackageExporter] Detected ICO file format, extracting bitmap from ICO");
                                Texture2D texture = ExtractBitmapFromIco(imageData);
                                if (texture != null && texture.width > 0 && texture.height > 0)
                                {
                                    Debug.Log($"[YUCP PackageExporter] Successfully extracted bitmap from ICO: {texture.width}x{texture.height}");
                                    
                                    // Resize if needed
                                    if (texture.width != 32 || texture.height != 32)
                                    {
                                        texture = ResizeTexture(texture, 32, 32);
                                        Debug.Log("[YUCP PackageExporter] Resized favicon to 32x32");
                                    }
                                    
                                    // Save the icon as an asset so it persists across domain reloads
                                    string iconAssetPath = PackageBuilder.SaveTextureAsTemporaryAsset(texture, requestData.link.label ?? requestData.domain);
                                    if (!string.IsNullOrEmpty(iconAssetPath))
                                    {
                                        Texture2D savedIcon = AssetDatabase.LoadAssetAtPath<Texture2D>(iconAssetPath);
                                        if (savedIcon != null)
                                        {
                                            requestData.link.icon = savedIcon;
                                            Debug.Log($"[YUCP PackageExporter] Saved favicon as asset: {iconAssetPath}");
                                        }
                                        else
                                        {
                                            // Fallback to in-memory texture if asset loading fails
                                            requestData.link.icon = texture;
                                            Debug.LogWarning($"[YUCP PackageExporter] Failed to load saved icon asset, using in-memory texture");
                                        }
                                    }
                                    else
                                    {
                                        // Fallback to in-memory texture if saving fails
                                        requestData.link.icon = texture;
                                        Debug.LogWarning($"[YUCP PackageExporter] Failed to save favicon as asset, using in-memory texture");
                                    }
                                    
                                    // Only set fetched icon if no custom icon is set
                                    if (requestData.link.customIcon == null)
                                    {
                                        requestData.iconImage.image = requestData.link.icon;
                                        Debug.Log($"[YUCP PackageExporter] Favicon successfully set for {requestData.domain}");
                                    }
                                    else
                                    {
                                        Debug.Log($"[YUCP PackageExporter] Favicon fetched but custom icon is displayed for {requestData.domain}");
                                    }
                                    if (requestData.profile != null)
                                    {
                                        EditorUtility.SetDirty(requestData.profile);
                                    }
                                    success = true;
                                }
                                else
                                {
                                    Debug.LogWarning($"[YUCP PackageExporter] Failed to extract bitmap from ICO file");
                                }
                            }
                            else
                            {
                                // Try to load as texture from raw bytes (PNG, JPG, etc.)
                                Texture2D texture = new Texture2D(2, 2);
                                bool loaded = texture.LoadImage(imageData);
                                
                                if (loaded && texture.width > 2 && texture.height > 2)
                                {
                                    Debug.Log($"[YUCP PackageExporter] Successfully loaded favicon: {texture.width}x{texture.height}");
                                    
                                    // Resize if needed (favicons can be various sizes)
                                    if (texture.width != 32 || texture.height != 32)
                                    {
                                        texture = ResizeTexture(texture, 32, 32);
                                        Debug.Log("[YUCP PackageExporter] Resized favicon to 32x32");
                                    }
                                    
                                    // Save the icon as an asset so it persists across domain reloads
                                    string iconAssetPath = PackageBuilder.SaveTextureAsTemporaryAsset(texture, requestData.link.label ?? requestData.domain);
                                    if (!string.IsNullOrEmpty(iconAssetPath))
                                    {
                                        Texture2D savedIcon = AssetDatabase.LoadAssetAtPath<Texture2D>(iconAssetPath);
                                        if (savedIcon != null)
                                        {
                                            requestData.link.icon = savedIcon;
                                            Debug.Log($"[YUCP PackageExporter] Saved favicon as asset: {iconAssetPath}");
                                        }
                                        else
                                        {
                                            // Fallback to in-memory texture if asset loading fails
                                            requestData.link.icon = texture;
                                            Debug.LogWarning($"[YUCP PackageExporter] Failed to load saved icon asset, using in-memory texture");
                                        }
                                    }
                                    else
                                    {
                                        // Fallback to in-memory texture if saving fails
                                        requestData.link.icon = texture;
                                        Debug.LogWarning($"[YUCP PackageExporter] Failed to save favicon as asset, using in-memory texture");
                                    }
                                    
                                    // Only set fetched icon if no custom icon is set
                                    if (requestData.link.customIcon == null)
                                    {
                                        requestData.iconImage.image = requestData.link.icon;
                                        Debug.Log($"[YUCP PackageExporter] Favicon successfully set for {requestData.domain}");
                                    }
                                    else
                                    {
                                        Debug.Log($"[YUCP PackageExporter] Favicon fetched but custom icon is displayed for {requestData.domain}");
                                    }
                                    if (requestData.profile != null)
                                    {
                                        EditorUtility.SetDirty(requestData.profile);
                                    }
                                    success = true;
                                }
                                else
                                {
                                    Debug.LogWarning($"[YUCP PackageExporter] Failed to load image data as texture (width: {texture.width}, height: {texture.height}, loaded: {loaded})");
                                    UnityEngine.Object.DestroyImmediate(texture);
                                }
                            }
                        }
                        else
                        {
                            Debug.LogWarning($"[YUCP PackageExporter] Downloaded data is null or empty");
                        }
                    }
                    else
                    {
                        Debug.LogWarning($"[YUCP PackageExporter] Request failed: {requestData.request.error}");
                    }
                    
                    requestData.request.Dispose();
                    requestData.request = null;
                    
                    if (!success)
                    {
                        // Try next URL
                        requestData.currentUrlIndex++;
                        Debug.Log($"[YUCP PackageExporter] Trying next favicon URL (index {requestData.currentUrlIndex})");
                        if (requestData.currentUrlIndex < 3)
                        {
                            StartFaviconRequest(requestData);
                            continue;
                        }
                        else
                        {
                            Debug.LogWarning($"[YUCP PackageExporter] All favicon URLs failed for domain: {requestData.domain}");
                        }
                    }
                    
                    faviconRequests.RemoveAt(i);
                }
            }
            
            if (faviconRequests.Count == 0)
            {
                EditorApplication.update -= CheckFaviconRequest;
                Debug.Log("[YUCP PackageExporter] All favicon requests completed, removed update callback");
            }
        }

        private void StartFaviconRequest(FaviconRequestData requestData)
        {
            // Try Brandfetch Logo API first (using base domain), then direct favicon, then DuckDuckGo fallback
            string[] faviconUrls = new string[]
            {
                $"https://cdn.brandfetch.io/{requestData.domain}/w/128/h/128/theme/dark/icon.png?c={BrandfetchClientId}",
                $"https://{requestData.domain}/favicon.ico",
                $"https://icons.duckduckgo.com/ip3/{requestData.domain}.ico"
            };
            
            if (requestData.currentUrlIndex >= faviconUrls.Length)
            {
                Debug.LogWarning($"[YUCP PackageExporter] URL index {requestData.currentUrlIndex} is out of range");
                return;
            }
            
            string faviconUrl = faviconUrls[requestData.currentUrlIndex];
            Debug.Log($"[YUCP PackageExporter] Starting request for favicon URL: {faviconUrl}");
            
            // Use regular UnityWebRequest instead of UnityWebRequestTexture to handle various formats
            requestData.request = UnityWebRequest.Get(faviconUrl);
            requestData.request.timeout = 5;
            
            // Set User-Agent to avoid blocking by some services
            requestData.request.SetRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
            
            var operation = requestData.request.SendWebRequest();
            
            if (operation == null)
            {
                Debug.LogError("[YUCP PackageExporter] Failed to start web request");
            }
            else
            {
                Debug.Log($"[YUCP PackageExporter] Web request started successfully");
            }
        }

        private string ExtractDomain(string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                Debug.LogWarning("[YUCP PackageExporter] ExtractDomain: URL is empty");
                return "";
            }
            
            try
            {
                if (!url.StartsWith("http://") && !url.StartsWith("https://"))
                {
                    url = "https://" + url;
                    Debug.Log($"[YUCP PackageExporter] ExtractDomain: Added https:// prefix, new URL: {url}");
                }
                
                Uri uri = new Uri(url);
                string domain = uri.Host;
                Debug.Log($"[YUCP PackageExporter] ExtractDomain: Extracted domain '{domain}' from URL '{url}'");
                return domain;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[YUCP PackageExporter] ExtractDomain failed for URL '{url}': {ex.Message}");
                return "";
            }
        }

        private string ExtractBrandIdFromJson(string json)
        {
            try
            {
                // Simple JSON parsing: look for "brandId":"value"
                int brandIdIndex = json.IndexOf("\"brandId\"");
                if (brandIdIndex < 0)
                    return null;
                
                int colonIndex = json.IndexOf(':', brandIdIndex);
                if (colonIndex < 0)
                    return null;
                
                int quoteStart = json.IndexOf('"', colonIndex);
                if (quoteStart < 0)
                    return null;
                
                int quoteEnd = json.IndexOf('"', quoteStart + 1);
                if (quoteEnd < 0)
                    return null;
                
                return json.Substring(quoteStart + 1, quoteEnd - quoteStart - 1);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[YUCP PackageExporter] Error parsing Brandfetch JSON: {ex.Message}");
                return null;
            }
        }

        private string ExtractBaseDomain(string host)
        {
            if (string.IsNullOrEmpty(host))
                return host;
            
            var parts = host.Split('.');
            if (parts.Length <= 2)
                return host;
            
            // Join last two labels (e.g., yeusepe.gumroad.com -> gumroad.com)
            string baseDomain = parts[parts.Length - 2] + "." + parts[parts.Length - 1];
            Debug.Log($"[YUCP PackageExporter] ExtractBaseDomain: host='{host}' -> baseDomain='{baseDomain}'");
            return baseDomain;
        }

        private Texture2D ResizeTexture(Texture2D source, int width, int height)
        {
            RenderTexture rt = RenderTexture.GetTemporary(width, height);
            Graphics.Blit(source, rt);
            RenderTexture previous = RenderTexture.active;
            RenderTexture.active = rt;
            Texture2D resized = new Texture2D(width, height);
            resized.ReadPixels(new Rect(0, 0, width, height), 0, 0);
            resized.Apply();
            RenderTexture.active = previous;
            RenderTexture.ReleaseTemporary(rt);
            return resized;
        }

        private Texture2D ExtractBitmapFromIco(byte[] icoData)
        {
            try
            {
                using (var ms = new MemoryStream(icoData))
                using (var reader = new BinaryReader(ms))
                {
                    // ICO header: 6 bytes
                    short reserved = reader.ReadInt16(); // Should be 0
                    short type = reader.ReadInt16();     // Should be 1 (icon)
                    short count = reader.ReadInt16();    // Number of images
                    
                    if (reserved != 0 || type != 1 || count <= 0)
                    {
                        Debug.LogWarning($"[YUCP PackageExporter] Invalid ICO header: reserved={reserved}, type={type}, count={count}");
                        return null;
                    }
                    
                    if (count > 20)
                    {
                        Debug.LogWarning($"[YUCP PackageExporter] ICO contains too many images: {count}");
                        return null;
                    }
                    
                    Debug.Log($"[YUCP PackageExporter] ICO file contains {count} images");
                    
                    // Read first directory entry (16 bytes)
                    byte width = reader.ReadByte();
                    byte height = reader.ReadByte();
                    reader.ReadByte(); // color count
                    reader.ReadByte(); // reserved
                    short planes = reader.ReadInt16();
                    short bitCount = reader.ReadInt16();
                    int imageSize = reader.ReadInt32();
                    int imageOffset = reader.ReadInt32();
                    
                    Debug.Log($"[YUCP PackageExporter] ICO entry: {Math.Max((int)width, 1)}x{Math.Max((int)height, 1)}, planes={planes}, bpp={bitCount}, size={imageSize}, offset={imageOffset}");
                    
                    if (imageOffset >= icoData.Length || imageOffset + imageSize > icoData.Length)
                    {
                        Debug.LogWarning($"[YUCP PackageExporter] Invalid ICO image offset or size");
                        return null;
                    }
                    
                    // Seek to image data
                    ms.Seek(imageOffset, SeekOrigin.Begin);
                    
                    // Check if it's PNG (PNG files start with 89 50 4E 47)
                    byte[] header = reader.ReadBytes(4);
                    ms.Seek(imageOffset, SeekOrigin.Begin); // Reset
                    
                    bool isPng = header.Length >= 4 && 
                                header[0] == 0x89 && header[1] == 0x50 && 
                                header[2] == 0x4E && header[3] == 0x47;
                    
                    if (isPng)
                    {
                        Debug.Log("[YUCP PackageExporter] ICO contains PNG data, loading directly");
                        byte[] pngData = reader.ReadBytes(imageSize);
                        Texture2D texture = new Texture2D(2, 2);
                        if (texture.LoadImage(pngData))
                        {
                            return texture;
                        }
                    }
                    else
                    {
                        // Read BITMAPINFOHEADER (DIB header)
                        int headerSize = reader.ReadInt32();     // Usually 40
                        int bmpWidth = reader.ReadInt32();
                        int bmpHeight = reader.ReadInt32();       // This is total height (image + mask)
                        reader.ReadInt16();                      // planes
                        int bpp = reader.ReadInt16();
                        int compression = reader.ReadInt32();
                        int imageSizeBytes = reader.ReadInt32();
                        reader.ReadInt32();                      // xPelsPerMeter
                        reader.ReadInt32();                      // yPelsPerMeter
                        int clrUsed = reader.ReadInt32();        // clrUsed
                        reader.ReadInt32();                      // clrImportant
                        
                        // Support palette-based bitmaps (1, 4, 8 bpp) and direct color (24, 32 bpp)
                        if (bpp != 1 && bpp != 4 && bpp != 8 && bpp != 24 && bpp != 32)
                        {
                            Debug.LogWarning($"[YUCP PackageExporter] Unsupported ICO bitmap bpp: {bpp}");
                            return null;
                        }
                        
                        bool isPaletteBased = (bpp == 1 || bpp == 4 || bpp == 8);
                        
                        int realHeight = bmpHeight / 2; // ICO stores height as image+mask
                        if (realHeight <= 0 || bmpWidth <= 0)
                        {
                            Debug.LogWarning($"[YUCP PackageExporter] Invalid ICO bitmap dimensions: {bmpWidth}x{realHeight}");
                            return null;
                        }
                        
                        if (bmpWidth > 512 || realHeight > 512)
                        {
                            Debug.LogWarning($"[YUCP PackageExporter] ICO bitmap too large: {bmpWidth}x{realHeight}");
                            return null;
                        }
                        
                        // Read color palette if palette-based
                        Color32[] palette = null;
                        int paletteSize = 0;
                        if (isPaletteBased)
                        {
                            paletteSize = (bpp == 1) ? 2 : ((bpp == 4) ? 16 : 256);
                            palette = new Color32[paletteSize];
                            
                            // Palette entries are BGR (3 bytes) or BGRA (4 bytes if clrUsed > 0)
                            int paletteBytes = (clrUsed > 0 && clrUsed <= paletteSize) ? 4 : 3;
                            for (int i = 0; i < paletteSize; i++)
                            {
                                byte b = reader.ReadByte();
                                byte g = reader.ReadByte();
                                byte r = reader.ReadByte();
                                byte a = (paletteBytes == 4) ? reader.ReadByte() : (byte)255;
                                palette[i] = new Color32(r, g, b, a);
                            }
                            Debug.Log($"[YUCP PackageExporter] Read {paletteSize}-color palette for {bpp}-bit bitmap");
                        }
                        
                        // Read the pixel data (DIB, bottom-up, BGR(A) or palette indices)
                        int bytesPerPixel = isPaletteBased ? 1 : (bpp / 8);
                        int bitsPerRow = bmpWidth * bpp;
                        int rowSize = ((bitsPerRow + 31) / 32) * 4; // Row size padded to 4-byte boundary
                        int dibSize = rowSize * realHeight;
                        
                        if (dibSize > imageSize - headerSize - (isPaletteBased ? (paletteSize * (clrUsed > 0 && clrUsed <= paletteSize ? 4 : 3)) : 0))
                        {
                            int available = imageSize - headerSize - (isPaletteBased ? (paletteSize * (clrUsed > 0 && clrUsed <= paletteSize ? 4 : 3)) : 0);
                            Debug.LogWarning($"[YUCP PackageExporter] DIB size calculation: calculated={dibSize}, available={available}");
                            dibSize = available;
                        }
                        
                        byte[] dib = reader.ReadBytes(dibSize);
                        if (dib.Length < dibSize)
                        {
                            Debug.LogWarning("[YUCP PackageExporter] DIB data truncated");
                            return null;
                        }
                        
                        // Create texture and convert BGR to RGB or palette indices to colors
                        Texture2D texture = new Texture2D(bmpWidth, realHeight, TextureFormat.RGBA32, false);
                        Color32[] pixels = new Color32[bmpWidth * realHeight];
                        
                        for (int y = 0; y < realHeight; y++)
                        {
                            int srcRow = realHeight - 1 - y; // Bottom-up
                            int rowOffset = srcRow * rowSize;
                            
                            for (int x = 0; x < bmpWidth; x++)
                            {
                                Color32 color;
                                
                                if (isPaletteBased)
                                {
                                    // Read palette index based on bit depth
                                    int bitOffset = x * bpp;
                                    int byteIndex = rowOffset + (bitOffset / 8);
                                    int bitIndex = bitOffset % 8;
                                    
                                    if (byteIndex >= dib.Length)
                                        break;
                                    
                                    int paletteIndex = 0;
                                    if (bpp == 1)
                                    {
                                        // 1-bit: each bit is a palette index
                                        paletteIndex = (dib[byteIndex] >> (7 - bitIndex)) & 0x01;
                                    }
                                    else if (bpp == 4)
                                    {
                                        // 4-bit: two palette indices per byte
                                        // For 4-bit, bitIndex will be 0, 4, 8, 12, etc.
                                        // If bitIndex is 0 or 4 mod 8, it's the first pixel in that byte
                                        if ((x % 2) == 0)
                                        {
                                            // First pixel in byte (high 4 bits)
                                            paletteIndex = (dib[byteIndex] >> 4) & 0x0F;
                                        }
                                        else
                                        {
                                            // Second pixel in byte (low 4 bits)
                                            paletteIndex = dib[byteIndex] & 0x0F;
                                        }
                                    }
                                    else // bpp == 8
                                    {
                                        // 8-bit: one byte per pixel
                                        paletteIndex = dib[byteIndex];
                                    }
                                    
                                    if (paletteIndex >= paletteSize || paletteIndex < 0)
                                        paletteIndex = 0;
                                    
                                    color = palette[paletteIndex];
                                }
                                else
                                {
                                    // Direct color (24 or 32 bpp)
                                    int srcIndex = rowOffset + x * bytesPerPixel;
                                    if (srcIndex + bytesPerPixel > dib.Length)
                                        break;
                                    
                                    byte b = dib[srcIndex + 0];
                                    byte g = dib[srcIndex + 1];
                                    byte r = dib[srcIndex + 2];
                                    byte a = (bytesPerPixel == 4) ? dib[srcIndex + 3] : (byte)255;
                                    
                                    color = new Color32(r, g, b, a);
                                }
                                
                                pixels[y * bmpWidth + x] = color;
                            }
                        }
                        
                        texture.SetPixels32(pixels);
                        texture.Apply();
                        Debug.Log($"[YUCP PackageExporter] ICO bitmap extracted as texture: {bmpWidth}x{realHeight}, bpp={bpp}");
                        return texture;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[YUCP PackageExporter] ExtractBitmapFromIco failed: {ex.Message}\n{ex.StackTrace}");
            }
            
            return null;
        }

        private VisualElement CreateSummarySection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var title = new Label("Quick Summary");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var statsContainer = new VisualElement();
            statsContainer.AddToClassList("yucp-stats-container");
            
            AddStatItem(statsContainer, "Folders to Export", profile.foldersToExport.Count.ToString());
            
            // Bundled Profiles
            if (profile.HasIncludedProfiles())
            {
                var bundledProfiles = profile.GetIncludedProfiles();
                AddStatItem(statsContainer, "Bundled Profiles", bundledProfiles.Count.ToString());
                
                // Show breakdown if we have discovered assets with source info
                if (profile.discoveredAssets != null && profile.discoveredAssets.Count > 0)
                {
                    var sourceBreakdown = profile.discoveredAssets
                        .Where(a => !string.IsNullOrEmpty(a.sourceProfileName))
                        .GroupBy(a => a.sourceProfileName)
                        .Select(g => $"{g.Key}: {g.Count()}")
                        .ToList();
                    
                    if (sourceBreakdown.Count > 0)
                    {
                        // Add parent assets count
                        int parentAssets = profile.discoveredAssets.Count(a => 
                            string.IsNullOrEmpty(a.sourceProfileName) || a.sourceProfileName == profile.packageName);
                        if (parentAssets > 0)
                        {
                            sourceBreakdown.Insert(0, $"{profile.packageName}: {parentAssets}");
                        }
                        
                        string breakdownText = string.Join(", ", sourceBreakdown);
                        if (breakdownText.Length > 60)
                        {
                            breakdownText = breakdownText.Substring(0, 57) + "...";
                        }
                        AddStatItem(statsContainer, "Assets by Source", breakdownText);
                    }
                }
            }
            
            // Dependencies
            if (profile.dependencies.Count > 0)
            {
                int bundled = profile.dependencies.Count(d => d.enabled && d.exportMode == DependencyExportMode.Bundle);
                int referenced = profile.dependencies.Count(d => d.enabled && d.exportMode == DependencyExportMode.Dependency);
                AddStatItem(statsContainer, "Dependencies", $"{bundled} bundled, {referenced} referenced");
            }
            
            // Obfuscation
            string obfuscationText = profile.enableObfuscation 
                ? $"Enabled ({profile.assembliesToObfuscate.Count(a => a.enabled)} assemblies)" 
                : "Disabled";
            AddStatItem(statsContainer, "Obfuscation", obfuscationText);
            
            // Output path
            string outputText = string.IsNullOrEmpty(profile.exportPath) ? "Desktop" : profile.exportPath;
            AddStatItem(statsContainer, "Output", outputText);
            
            // Last export
            if (!string.IsNullOrEmpty(profile.LastExportTime))
            {
                AddStatItem(statsContainer, "Last Export", profile.LastExportTime);
            }
            
            section.Add(statsContainer);
            return section;
        }

        private void AddStatItem(VisualElement container, string label, string value)
        {
            var item = new VisualElement();
            item.AddToClassList("yucp-stat-item");
            
            var labelElement = new Label(label);
            labelElement.AddToClassList("yucp-stat-label");
            item.Add(labelElement);
            
            var valueElement = new Label(value);
            valueElement.AddToClassList("yucp-stat-value");
            item.Add(valueElement);
            
            container.Add(item);
        }

        private VisualElement CreateValidationSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.name = "validation-section";
            
            if (!profile.Validate(out string errorMessage))
            {
                var errorContainer = new VisualElement();
                errorContainer.AddToClassList("yucp-validation-error");
                
                var errorText = new Label($"Validation Error: {errorMessage}");
                errorText.AddToClassList("yucp-validation-error-text");
                errorContainer.Add(errorText);
                
                section.Add(errorContainer);
            }
            else
            {
                var successContainer = new VisualElement();
                successContainer.AddToClassList("yucp-validation-success");
                
                var successText = new Label("Profile is valid and ready to export");
                successText.AddToClassList("yucp-validation-success-text");
                successContainer.Add(successText);
                
                section.Add(successContainer);
            }
            
            // Add warnings section (non-critical issues)
            var warnings = CollectWarnings(profile);
            if (warnings.Count > 0)
            {
                var warningsContainer = new VisualElement();
                warningsContainer.AddToClassList("yucp-help-box");
                warningsContainer.style.backgroundColor = new Color(0.7f, 0.65f, 0.1f, 0.3f); // Yellow warning color
                warningsContainer.style.marginTop = 8;
                warningsContainer.style.borderLeftWidth = 3;
                warningsContainer.style.borderLeftColor = new Color(0.9f, 0.85f, 0.2f, 1f); // Yellow border
                
                var warningsLabel = new Label("Warnings:");
                warningsLabel.AddToClassList("yucp-label");
                warningsLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
                warningsLabel.style.marginBottom = 4;
                warningsContainer.Add(warningsLabel);
                
                foreach (var warning in warnings)
                {
                    var warningText = new Label($"• {warning}");
                    warningText.AddToClassList("yucp-help-box-text");
                    warningText.style.color = new StyleColor(new Color(0.9f, 0.9f, 0.9f, 1f));
                    warningsContainer.Add(warningText);
                }
                
                section.Add(warningsContainer);
            }
            
            return section;
        }
        
        private List<string> CollectWarnings(ExportProfile profile)
        {
            var warnings = new List<string>();
            
            // Check for derived patches with missing origin files
            if (profile.discoveredAssets != null)
            {
                foreach (var asset in profile.discoveredAssets)
                {
                    if (IsDerivedFbx(asset.assetPath, out DerivedSettings settings, out string basePath))
                    {
                        if (string.IsNullOrEmpty(basePath))
                        {
                            string assetName = Path.GetFileName(asset.assetPath);
                            warnings.Add($"Derived patch '{assetName}' is missing its origin file");
                        }
                        else
                        {
                            // Check if the base file exists (basePath from AssetDatabase is relative)
                            string baseAssetPath = basePath;
                            if (!Path.IsPathRooted(baseAssetPath))
                            {
                                string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                                baseAssetPath = Path.GetFullPath(Path.Combine(projectPath, baseAssetPath));
                            }
                            
                            if (!File.Exists(baseAssetPath))
                            {
                                string assetName = Path.GetFileName(asset.assetPath);
                                warnings.Add($"Derived patch '{assetName}' origin file not found: {basePath}");
                            }
                        }
                    }
                }
            }
            
            // Check for problematic dependencies
            if (profile.dependencies != null)
            {
                foreach (var dep in profile.dependencies)
                {
                    if (dep.enabled)
                    {
                        string packageName = dep.packageName ?? "";
                        string displayName = dep.displayName ?? "";
                        string combinedName = (packageName + " " + displayName).ToLower();
                        
                        // Check for Temp/Temporary (but not template)
                        bool hasTemp = (combinedName.Contains(" temp ") || combinedName.StartsWith("temp ") || 
                                       combinedName.EndsWith(" temp") || combinedName == "temp" || 
                                       combinedName.Contains("temporary")) && !combinedName.Contains("template");
                        
                        // Check for YUCP Dev tools
                        bool hasDevTools = combinedName.Contains("yucp dev tools") || combinedName.Contains("yucp.devtools");
                        
                        if (hasTemp)
                        {
                            string depName = string.IsNullOrEmpty(displayName) ? packageName : displayName;
                            warnings.Add($"Dependency '{depName}' contains 'Temp' or 'Temporary' - not recommended for general distribution");
                        }
                        
                        if (hasDevTools)
                        {
                            string depName = string.IsNullOrEmpty(displayName) ? packageName : displayName;
                            warnings.Add($"Dependency '{depName}' contains 'YUCP Dev tools' - not recommended for general distribution");
                        }
                    }
                }
            }
            
            // Check for composite profile issues
            if (profile.HasIncludedProfiles())
            {
                List<ExportProfile> resolved;
                List<string> cycles;
                CompositeProfileResolver.ResolveIncludedProfiles(profile, out resolved, out cycles);
                
                // Cycle warnings
                if (cycles.Count > 0)
                {
                    foreach (string cycle in cycles)
                    {
                        warnings.Add($"Cycle detected in bundled profiles: {cycle}");
                    }
                }
                
                // Missing profile warnings
                var bundledProfiles = profile.GetIncludedProfiles();
                var allGuids = new List<string>();
                var profileType = typeof(ExportProfile);
                var guidField = profileType.GetField("includedProfileGuids", 
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                
                if (guidField != null)
                {
                    var guids = guidField.GetValue(profile) as List<string>;
                    if (guids != null)
                    {
                        allGuids = guids;
                    }
                }
                
                var resolvedGuids = new HashSet<string>();
                foreach (var resolvedProfile in resolved)
                {
                    if (resolvedProfile != null)
                    {
                        string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(resolvedProfile));
                        if (!string.IsNullOrEmpty(guid))
                        {
                            resolvedGuids.Add(guid);
                        }
                    }
                }
                
                int missingCount = 0;
                foreach (string guid in allGuids)
                {
                    if (!string.IsNullOrEmpty(guid) && !resolvedGuids.Contains(guid))
                    {
                        missingCount++;
                    }
                }
                
                if (missingCount > 0)
                {
                    warnings.Add($"{missingCount} bundled profile(s) are missing or deleted");
                }
                
                // Bundled profile validation errors
                foreach (var bundledProfile in bundledProfiles)
                {
                    if (bundledProfile != null)
                    {
                        if (!bundledProfile.Validate(out string validationError))
                        {
                            warnings.Add($"Bundled profile '{bundledProfile.packageName}' has errors: {validationError}");
                        }
                    }
                }
                
                // Asset conflict warnings (if we have discovered assets)
                if (profile.discoveredAssets != null && profile.discoveredAssets.Count > 0)
                {
                    var assetSourceMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    var assetCounts = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
                    
                    foreach (var asset in profile.discoveredAssets)
                    {
                        if (!string.IsNullOrEmpty(asset.sourceProfileName))
                        {
                            string normalizedPath = asset.assetPath.Replace('\\', '/');
                            if (!assetCounts.ContainsKey(normalizedPath))
                            {
                                assetCounts[normalizedPath] = new List<string>();
                            }
                            assetCounts[normalizedPath].Add(asset.sourceProfileName);
                        }
                    }
                    
                    foreach (var kvp in assetCounts)
                    {
                        if (kvp.Value.Count > 1)
                        {
                            var uniqueSources = kvp.Value.Distinct().ToList();
                            if (uniqueSources.Count > 1)
                            {
                                string assetName = Path.GetFileName(kvp.Key);
                                warnings.Add($"Asset '{assetName}' appears in multiple bundled profiles: {string.Join(", ", uniqueSources)}");
                            }
                        }
                    }
                }
            }
            
            return warnings;
        }

        private void UpdateValidationDisplay(ExportProfile profile)
        {
            var validationSection = _profileDetailsContainer?.Q("validation-section");
            if (validationSection != null && profile != null)
            {
                var parent = validationSection.parent;
                var index = parent.IndexOf(validationSection);
                parent.Remove(validationSection);
                parent.Insert(index, CreateValidationSection(profile));
            }
        }

        private VisualElement CreateExportOptionsSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var header = CreateCollapsibleHeader("Export Options", 
                () => showExportOptions, 
                (value) => { showExportOptions = value; }, 
                () => UpdateProfileDetails());
            section.Add(header);
            
            if (!showExportOptions)
            {
                return section;
            }
            
            // Toggles container
            var togglesContainer = new VisualElement();
            togglesContainer.style.flexDirection = FlexDirection.Column;
            togglesContainer.style.marginBottom = 8;
            
            // Include Dependencies
            var includeDepsToggle = new Toggle("Include Dependencies") { value = profile.includeDependencies };
            includeDepsToggle.AddToClassList("yucp-toggle");
            includeDepsToggle.tooltip = "Include all dependency files directly in the exported package";
            includeDepsToggle.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Include Dependencies");
                    profile.includeDependencies = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    // Update the asset list to reflect the toggle change
                    UpdateProfileDetails();
                }
            });
            togglesContainer.Add(includeDepsToggle);
            
            var recurseFoldersToggle = new Toggle("Recurse Folders") { value = profile.recurseFolders };
            recurseFoldersToggle.AddToClassList("yucp-toggle");
            recurseFoldersToggle.tooltip = "Search subfolders when collecting assets to export";
            recurseFoldersToggle.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Recurse Folders");
                    profile.recurseFolders = evt.newValue;
                    EditorUtility.SetDirty(profile);
                }
            });
            togglesContainer.Add(recurseFoldersToggle);
            
            // Generate package.json
            var generateJsonToggle = new Toggle("Generate package.json") { value = profile.generatePackageJson };
            generateJsonToggle.AddToClassList("yucp-toggle");
            generateJsonToggle.tooltip = "Create a package.json file with dependency information for VPM compatibility";
            generateJsonToggle.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Generate Package Json");
                    profile.generatePackageJson = evt.newValue;
                    EditorUtility.SetDirty(profile);
                }
            });
            togglesContainer.Add(generateJsonToggle);
            
            // Auto-Increment Version
            var autoIncrementToggle = new Toggle("Auto-Increment Version") { value = profile.autoIncrementVersion };
            autoIncrementToggle.AddToClassList("yucp-toggle");
            autoIncrementToggle.tooltip = "Automatically increment the version number on each export";
            autoIncrementToggle.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Auto Increment Version");
                    profile.autoIncrementVersion = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    UpdateProfileDetails(); // Refresh to show/hide increment strategy
                }
            });
            togglesContainer.Add(autoIncrementToggle);
            
            section.Add(togglesContainer);
            
            // Increment Strategy (only if auto-increment is enabled)
            if (profile.autoIncrementVersion)
            {
                var strategyRow = CreateFormRow("What to Bump", tooltip: "Choose which number to increment");
                var strategyField = new EnumField(profile.incrementStrategy);
                strategyField.AddToClassList("yucp-form-field");
                strategyField.RegisterValueChangedCallback(evt =>
                {
                    if (profile != null)
                    {
                        Undo.RecordObject(profile, "Change Increment Strategy");
                        profile.incrementStrategy = (VersionIncrementStrategy)evt.newValue;
                        EditorUtility.SetDirty(profile);
                        UpdateProfileDetails(); // Refresh to show help
                    }
                });
                strategyRow.Add(strategyField);
                section.Add(strategyRow);
                
                // Show what each strategy does
                var strategyHelp = new Label(GetStrategyExplanation(profile.incrementStrategy));
                strategyHelp.style.fontSize = 11;
                strategyHelp.style.color = new UnityEngine.UIElements.StyleColor(new Color(0.6f, 0.8f, 1.0f));
                strategyHelp.style.marginLeft = 4;
                strategyHelp.style.marginTop = 2;
                strategyHelp.style.marginBottom = 8;
                strategyHelp.style.unityFontStyleAndWeight = FontStyle.Italic;
                section.Add(strategyHelp);
                
                // Custom Version Rule (optional)
                var customRuleRow = CreateFormRow("Custom Rule (Optional)", tooltip: "Use a custom version rule for special formats. Leave empty for standard semver.");
                var customRuleField = new ObjectField { objectType = typeof(CustomVersionRule), value = profile.customVersionRule };
                customRuleField.AddToClassList("yucp-form-field");
                customRuleField.RegisterValueChangedCallback(evt =>
                {
                    if (profile != null)
                    {
                        Undo.RecordObject(profile, "Change Custom Rule");
                        profile.customVersionRule = evt.newValue as CustomVersionRule;
                        if (profile.customVersionRule != null)
                        {
                            profile.customVersionRule.RegisterRule();
                        }
                        EditorUtility.SetDirty(profile);
                        UpdateProfileDetails(); // Refresh UI
                    }
                });
                customRuleRow.Add(customRuleField);
                
                var createRuleBtn = new Button(() => CreateCustomRule(profile)) { text = "New" };
                createRuleBtn.AddToClassList("yucp-button");
                createRuleBtn.AddToClassList("yucp-button-small");
                createRuleBtn.tooltip = "Create a new custom version rule";
                customRuleRow.Add(createRuleBtn);
                
                section.Add(customRuleRow);
                
                // Custom Rule Editor (show when a rule is assigned)
                if (profile.customVersionRule != null)
                {
                    section.Add(CreateCustomRuleEditor(profile));
                }
                
                // Bump Directives in Files toggle
                var bumpDirectivesToggle = new Toggle("Auto-bump @directives in Files") { value = profile.bumpDirectivesInFiles };
                bumpDirectivesToggle.AddToClassList("yucp-toggle");
                bumpDirectivesToggle.tooltip = "Automatically update versions in source files that have @bump directives";
                bumpDirectivesToggle.RegisterValueChangedCallback(evt =>
                {
                    if (profile != null)
                    {
                        Undo.RecordObject(profile, "Change Bump Directives");
                        profile.bumpDirectivesInFiles = evt.newValue;
                        EditorUtility.SetDirty(profile);
                        UpdateProfileDetails(); // Refresh to show/hide help text
                    }
                });
                section.Add(bumpDirectivesToggle);
                
                // Help text for smart version bumping
                if (profile.bumpDirectivesInFiles)
                {
                    var helpBox = new VisualElement();
                    helpBox.style.backgroundColor = new UnityEngine.UIElements.StyleColor(new Color(0.2f, 0.2f, 0.2f, 0.3f));
                    helpBox.style.borderTopWidth = 1;
                    helpBox.style.borderBottomWidth = 1;
                    helpBox.style.borderLeftWidth = 1;
                    helpBox.style.borderRightWidth = 1;
                    helpBox.style.borderTopColor = new UnityEngine.UIElements.StyleColor(new Color(0.1f, 0.1f, 0.1f));
                    helpBox.style.borderBottomColor = new UnityEngine.UIElements.StyleColor(new Color(0.1f, 0.1f, 0.1f));
                    helpBox.style.borderLeftColor = new UnityEngine.UIElements.StyleColor(new Color(0.1f, 0.1f, 0.1f));
                    helpBox.style.borderRightColor = new UnityEngine.UIElements.StyleColor(new Color(0.1f, 0.1f, 0.1f));
                    helpBox.style.borderTopLeftRadius = 4;
                    helpBox.style.borderTopRightRadius = 4;
                    helpBox.style.borderBottomLeftRadius = 4;
                    helpBox.style.borderBottomRightRadius = 4;
                    helpBox.style.paddingTop = 8;
                    helpBox.style.paddingBottom = 8;
                    helpBox.style.paddingLeft = 8;
                    helpBox.style.paddingRight = 8;
                    helpBox.style.marginTop = 8;
                    helpBox.style.marginBottom = 8;
                    
                    var helpTitle = new Label("How to use:");
                    helpTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
                    helpTitle.style.fontSize = 11;
                    helpTitle.style.marginBottom = 4;
                    helpBox.Add(helpTitle);
                    
                    string exampleRule = profile.customVersionRule != null 
                        ? profile.customVersionRule.ruleName 
                        : "semver";
                    
                    var helpText = new Label(
                        $"Add comment directives to your source files:\n" +
                        $"  public const string Version = \"1.0.0\"; // @bump {exampleRule}\n\n" +
                        "When you export, these versions will auto-update according to your Increment Strategy.");
                    helpText.style.fontSize = 11;
                    helpText.style.color = new UnityEngine.UIElements.StyleColor(new Color(0.7f, 0.7f, 0.7f));
                    helpText.style.whiteSpace = UnityEngine.UIElements.WhiteSpace.Normal;
                    helpBox.Add(helpText);
                    
                    section.Add(helpBox);
                }
            }
            
            // Export Path
            var pathRow = CreateFormRow("Export Path", tooltip: "Folder where the exported .unitypackage file will be saved");
            var pathField = new TextField { value = profile.exportPath };
            pathField.AddToClassList("yucp-input");
            pathField.AddToClassList("yucp-form-field");
            pathField.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Export Path");
                    profile.exportPath = evt.newValue;
                    EditorUtility.SetDirty(profile);
                }
            });
            pathRow.Add(pathField);
            var browsePathButton = new Button(() => BrowseForPath(profile)) { text = "Browse" };
            browsePathButton.AddToClassList("yucp-button");
            browsePathButton.AddToClassList("yucp-button-small");
            pathRow.Add(browsePathButton);
            section.Add(pathRow);
            
            if (string.IsNullOrEmpty(profile.exportPath))
            {
                var hintBox = new VisualElement();
                hintBox.AddToClassList("yucp-help-box");
                var hintText = new Label("Empty path = Desktop");
                hintText.AddToClassList("yucp-help-box-text");
                hintBox.Add(hintText);
                section.Add(hintBox);
            }
            
            return section;
        }

        private VisualElement CreateFoldersSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var header = CreateCollapsibleHeader("Export Folders", 
                () => showFolders, 
                (value) => { showFolders = value; }, 
                () => UpdateProfileDetails());
            section.Add(header);
            
            if (!showFolders)
            {
                return section;
            }
            
            if (profile.foldersToExport.Count == 0)
            {
                var warning = new VisualElement();
                warning.AddToClassList("yucp-validation-error");
                var warningText = new Label("No folders added. Add folders to export.");
                warningText.AddToClassList("yucp-validation-error-text");
                warning.Add(warningText);
                section.Add(warning);
            }
            else
            {
                var folderList = new VisualElement();
                folderList.AddToClassList("yucp-folder-list");
                
                for (int i = 0; i < profile.foldersToExport.Count; i++)
                {
                    int index = i; // Capture for closure
                    var folderItem = new VisualElement();
                    folderItem.AddToClassList("yucp-folder-item");
                    
                    var pathLabel = new Label(profile.foldersToExport[i]);
                    pathLabel.AddToClassList("yucp-folder-item-path");
                    folderItem.Add(pathLabel);
                    
                    var removeButton = new Button(() => RemoveFolder(profile, index)) { text = "×" };
                    removeButton.AddToClassList("yucp-button");
                    removeButton.AddToClassList("yucp-folder-item-remove");
                    folderItem.Add(removeButton);
                    
                    folderList.Add(folderItem);
                }
                
                section.Add(folderList);
            }
            
            var addButton = new Button(() => AddFolder(profile)) { text = "+ Add Folder" };
            addButton.AddToClassList("yucp-button");
            addButton.AddToClassList("yucp-button-action");
            addButton.style.marginTop = 8;
            section.Add(addButton);
            
            return section;
        }

        private VisualElement CreateExclusionFiltersSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var header = CreateCollapsibleHeader("Exclusion Filters", 
                () => showExclusionFilters, 
                (value) => { showExclusionFilters = value; }, 
                () => UpdateProfileDetails());
            section.Add(header);
            
            if (!showExclusionFilters)
            {
                return section;
            }
            
            var helpBox = new VisualElement();
            helpBox.AddToClassList("yucp-help-box");
            helpBox.style.marginTop = 8;
            var helpText = new Label("Exclude files and folders from export using patterns");
            helpText.AddToClassList("yucp-help-box-text");
            helpBox.Add(helpText);
            section.Add(helpBox);
            
            // File Patterns
            var filePatternsLabel = new Label("File Patterns");
            filePatternsLabel.AddToClassList("yucp-label");
            filePatternsLabel.style.marginTop = 8;
            filePatternsLabel.style.marginBottom = 4;
            filePatternsLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            section.Add(filePatternsLabel);
            
            var filePatternsContainer = new VisualElement();
            filePatternsContainer.style.marginBottom = 8;
            
            for (int i = 0; i < profile.excludeFilePatterns.Count; i++)
            {
                int index = i;
                string originalValue = profile.excludeFilePatterns[i];
                var patternItem = CreateEditableStringListItem(
                    originalValue,
                    (newValue) =>
                    {
                        if (index < profile.excludeFilePatterns.Count)
                        {
                            Undo.RecordObject(profile, "Change Exclusion Pattern");
                            profile.excludeFilePatterns[index] = newValue;
                            EditorUtility.SetDirty(profile);
                        }
                    },
                    () =>
                    {
                        if (index < profile.excludeFilePatterns.Count)
                        {
                            Undo.RecordObject(profile, "Remove Exclusion Pattern");
                            profile.excludeFilePatterns.RemoveAt(index);
                            EditorUtility.SetDirty(profile);
                            AssetDatabase.SaveAssets();
                            UpdateProfileDetails();
                        }
                    });
                filePatternsContainer.Add(patternItem);
            }
            section.Add(filePatternsContainer);
            
            var addFilePatternButton = new Button(() =>
            {
                profile.excludeFilePatterns.Add("*.tmp");
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                UpdateProfileDetails();
            }) { text = "+ Add Pattern (e.g., *.tmp)" };
            addFilePatternButton.AddToClassList("yucp-button");
            addFilePatternButton.style.marginBottom = 12;
            section.Add(addFilePatternButton);
            
            // Folder Names
            var folderNamesLabel = new Label("Folder Names");
            folderNamesLabel.AddToClassList("yucp-label");
            folderNamesLabel.style.marginTop = 8;
            folderNamesLabel.style.marginBottom = 4;
            folderNamesLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            section.Add(folderNamesLabel);
            
            var folderNamesContainer = new VisualElement();
            
            for (int i = 0; i < profile.excludeFolderNames.Count; i++)
            {
                int index = i;
                string originalValue = profile.excludeFolderNames[i];
                var folderItem = CreateEditableStringListItem(
                    originalValue,
                    (newValue) =>
                    {
                        if (index < profile.excludeFolderNames.Count)
                        {
                            Undo.RecordObject(profile, "Change Exclusion Folder");
                            profile.excludeFolderNames[index] = newValue;
                            EditorUtility.SetDirty(profile);
                        }
                    },
                    () =>
                    {
                        if (index < profile.excludeFolderNames.Count)
                        {
                            Undo.RecordObject(profile, "Remove Exclusion Folder");
                            profile.excludeFolderNames.RemoveAt(index);
                            EditorUtility.SetDirty(profile);
                            AssetDatabase.SaveAssets();
                            UpdateProfileDetails();
                        }
                    });
                folderNamesContainer.Add(folderItem);
            }
            section.Add(folderNamesContainer);
            
            var addFolderNameButton = new Button(() =>
            {
                profile.excludeFolderNames.Add(".git");
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                UpdateProfileDetails();
            }) { text = "+ Add Folder Name (e.g., .git)" };
            addFolderNameButton.AddToClassList("yucp-button");
            section.Add(addFolderNameButton);
            
            return section;
        }

        private VisualElement CreateStringListItem(string value, Action onRemove)
        {
            var item = new VisualElement();
            item.AddToClassList("yucp-folder-item");
            
            var textField = new TextField { value = value };
            textField.AddToClassList("yucp-input");
            textField.style.flexGrow = 1;
            textField.isReadOnly = true;
            item.Add(textField);
            
            var removeButton = new Button(onRemove) { text = "×" };
            removeButton.AddToClassList("yucp-button");
            removeButton.AddToClassList("yucp-folder-item-remove");
            item.Add(removeButton);
            
            return item;
        }

        private VisualElement CreateEditableStringListItem(string value, Action<string> onValueChanged, Action onRemove)
        {
            var item = new VisualElement();
            item.AddToClassList("yucp-folder-item");
            
            var textField = new TextField { value = value };
            textField.AddToClassList("yucp-input");
            textField.style.flexGrow = 1;
            textField.isReadOnly = false;
            textField.RegisterValueChangedCallback(evt =>
            {
                onValueChanged?.Invoke(evt.newValue);
            });
            item.Add(textField);
            
            var removeButton = new Button(onRemove) { text = "×" };
            removeButton.AddToClassList("yucp-button");
            removeButton.AddToClassList("yucp-folder-item-remove");
            item.Add(removeButton);
            
            return item;
        }

        private VisualElement CreateExportInspectorSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.style.flexGrow = 0;
            section.style.flexShrink = 1;
            section.style.minWidth = 0;
            section.style.maxWidth = Length.Percent(100);
            section.style.width = Length.Percent(100);
            section.style.overflow = Overflow.Hidden;
            
            var header = new VisualElement();
            header.AddToClassList("yucp-inspector-header");
            
            var title = new Label($"Export Inspector ({profile.discoveredAssets.Count} assets)");
            title.AddToClassList("yucp-section-title");
            title.style.flexGrow = 1;
            header.Add(title);
            
            var rescanButton = new Button(() => 
            {
                Undo.RecordObject(profile, "Rescan Assets");
                ScanAssetsForInspector(profile, silent: true);
            });
            rescanButton.tooltip = "Rescan Assets";
            rescanButton.AddToClassList("yucp-button");
            rescanButton.AddToClassList("yucp-button-small");
            
            var refreshIcon = EditorGUIUtility.IconContent("Refresh");
            if (refreshIcon != null && refreshIcon.image != null)
            {
                rescanButton.text = "";
                var iconImage = new Image();
                iconImage.image = refreshIcon.image as Texture2D;
                iconImage.style.width = 16;
                iconImage.style.height = 16;
                iconImage.style.alignSelf = Align.Center;
                iconImage.style.marginLeft = Length.Auto();
                iconImage.style.marginRight = Length.Auto();
                iconImage.style.marginTop = Length.Auto();
                iconImage.style.marginBottom = Length.Auto();
                rescanButton.Add(iconImage);
            }
            else
            {
                rescanButton.text = "⟳";
            }
            
            rescanButton.style.justifyContent = Justify.Center;
            rescanButton.style.alignItems = Align.Center;
            rescanButton.style.marginRight = 4;
            rescanButton.SetEnabled(profile.foldersToExport.Count > 0);
            header.Add(rescanButton);
            
            var toggleButton = new Button(() => 
            {
                bool wasOpen = showExportInspector;
                showExportInspector = !showExportInspector;
                UpdateProfileDetails();
                
                // Scan when section is opened
                if (showExportInspector && !wasOpen && profile != null && profile.foldersToExport.Count > 0)
                {
                    EditorApplication.delayCall += () =>
                    {
                        if (profile != null)
                        {
                            ScanAssetsForInspector(profile, silent: true);
                        }
                    };
                }
            }) 
            { text = showExportInspector ? "▼" : "▶" };
            toggleButton.AddToClassList("yucp-button");
            toggleButton.AddToClassList("yucp-button-small");
            header.Add(toggleButton);
            
            section.Add(header);
            
            // Auto-scan when section is visible and needs scanning
            if (showExportInspector && profile != null && profile.foldersToExport.Count > 0)
            {
                if (!profile.HasScannedAssets)
                {
                    // Scan immediately if not scanned yet
                    EditorApplication.delayCall += () =>
                    {
                        if (profile != null)
                        {
                            ScanAssetsForInspector(profile, silent: true);
                        }
                    };
                }
            }
            
            if (showExportInspector)
            {
                // Help box
                var helpBox = new VisualElement();
                helpBox.AddToClassList("yucp-help-box");
                var helpText = new Label("The Export Inspector shows all assets discovered from your export folders. Scan to discover assets, then deselect unwanted items or add folders to the permanent ignore list.");
                helpText.AddToClassList("yucp-help-box-text");
                helpBox.Add(helpText);
                section.Add(helpBox);
                
                // Action buttons
                var actionButtons = new VisualElement();
                actionButtons.AddToClassList("yucp-inspector-action-buttons");
                actionButtons.style.flexDirection = FlexDirection.Row;
                actionButtons.style.marginTop = 8;
                actionButtons.style.marginBottom = 8;
                
                // Show scan in progress message
                if (!profile.HasScannedAssets)
                {
                    var infoBox = new VisualElement();
                    infoBox.AddToClassList("yucp-help-box");
                    var infoText = new Label("Scanning assets... This will complete automatically.");
                    infoText.AddToClassList("yucp-help-box-text");
                    infoBox.Add(infoText);
                    section.Add(infoBox);
                }
                else
                {
                    // Statistics
                    var statsLabel = new Label("Asset Statistics");
                    statsLabel.AddToClassList("yucp-label");
                    statsLabel.style.marginTop = 8;
                    statsLabel.style.marginBottom = 4;
                    section.Add(statsLabel);
                    
					var summaryBox = new VisualElement();
                    summaryBox.AddToClassList("yucp-help-box");
                    var summaryText = new Label(AssetCollector.GetAssetSummary(profile.discoveredAssets));
                    summaryText.AddToClassList("yucp-help-box-text");
                    summaryBox.Add(summaryText);
                    section.Add(summaryBox);
					
					// Derived patch summary
					int derivedCount = profile.discoveredAssets.Count(a => IsDerivedFbx(a.assetPath, out _, out _));
					if (derivedCount > 0)
					{
						var derivedBox = new VisualElement();
						derivedBox.AddToClassList("yucp-help-box");
						var derivedText = new Label($"{derivedCount} FBX asset(s) are marked to export as Derived Patch packages.");
						derivedText.AddToClassList("yucp-help-box-text");
						derivedBox.Add(derivedText);
						section.Add(derivedBox);
					}
                    
                    // Filter controls
                    var filtersLabel = new Label("Filters");
                    filtersLabel.AddToClassList("yucp-label");
                    filtersLabel.style.marginTop = 8;
                    filtersLabel.style.marginBottom = 4;
                    section.Add(filtersLabel);
                    
                    var searchRow = new VisualElement();
                    searchRow.AddToClassList("yucp-inspector-search-row");
                    searchRow.style.marginBottom = 4;
                    
                    var searchField = new TextField { value = inspectorSearchFilter };
                    searchField.AddToClassList("yucp-input");
                    searchField.style.flexGrow = 1;
                    searchField.style.marginRight = 4;
                    searchField.name = "inspector-search-field";
                    searchField.RegisterValueChangedCallback(evt =>
                    {
                        inspectorSearchFilter = evt.newValue;
                        var assetListContainer = section.Q<VisualElement>("asset-list-container");
                        if (assetListContainer != null)
                        {
                            assetListContainer.Clear();
                            RebuildAssetList(profile, assetListContainer);
                        }
                    });
                    searchRow.Add(searchField);
                    
                    var clearSearchButton = new Button(() => 
                    {
                        inspectorSearchFilter = "";
                        var searchField = section.Q<TextField>("inspector-search-field");
                        if (searchField != null)
                        {
                            searchField.value = "";
                        }
                        var assetListContainer = section.Q<VisualElement>("asset-list-container");
                        if (assetListContainer != null)
                        {
                            assetListContainer.Clear();
                            RebuildAssetList(profile, assetListContainer);
                        }
                    }) { text = "Clear" };
                    clearSearchButton.AddToClassList("yucp-button");
                    clearSearchButton.AddToClassList("yucp-button-small");
                    searchRow.Add(clearSearchButton);
                    
                    section.Add(searchRow);
                    
                    // Source profile filter (for composite profiles)
                    if (profile.HasIncludedProfiles())
                    {
                        var sourceFilterRow = new VisualElement();
                        sourceFilterRow.style.flexDirection = FlexDirection.Row;
                        sourceFilterRow.style.alignItems = Align.Center;
                        sourceFilterRow.style.marginBottom = 8;
                        
                        var sourceFilterLabel = new Label("Source:");
                        sourceFilterLabel.AddToClassList("yucp-label");
                        sourceFilterLabel.style.marginRight = 8;
                        sourceFilterRow.Add(sourceFilterLabel);
                        
                        // Get unique source profiles
                        var sourceProfiles = new List<string> { "All" };
                        sourceProfiles.Add(profile.packageName); // Parent
                        var includedProfiles = profile.GetIncludedProfiles();
                        foreach (var included in includedProfiles)
                        {
                            if (included != null && !sourceProfiles.Contains(included.packageName))
                            {
                                sourceProfiles.Add(included.packageName);
                            }
                        }
                        
                        var sourceFilterDropdown = new DropdownField(sourceProfiles, 0);
                        sourceFilterDropdown.AddToClassList("yucp-input");
                        sourceFilterDropdown.style.flexGrow = 1;
                        sourceFilterDropdown.name = "source-filter-dropdown";
                        sourceFilterDropdown.SetValueWithoutNotify(sourceProfileFilter);
                        sourceFilterDropdown.RegisterValueChangedCallback(evt =>
                        {
                            sourceProfileFilter = evt.newValue;
                            var assetListContainer = section.Q<VisualElement>("asset-list-container");
                            if (assetListContainer != null)
                            {
                                assetListContainer.Clear();
                                RebuildAssetList(profile, assetListContainer);
                            }
                        });
                        sourceFilterRow.Add(sourceFilterDropdown);
                        section.Add(sourceFilterRow);
                    }
                    
                    var filterToggles = new VisualElement();
                    filterToggles.AddToClassList("yucp-inspector-filter-toggles");
                    filterToggles.style.marginBottom = 8;
                    
                    var includedToggle = new Toggle("Show Only Included") { value = showOnlyIncluded };
                    includedToggle.AddToClassList("yucp-toggle");
                    includedToggle.RegisterValueChangedCallback(evt =>
                    {
                        showOnlyIncluded = evt.newValue;
                        if (evt.newValue) showOnlyExcluded = false;
                        var assetListContainer = section.Q<VisualElement>("asset-list-container");
                        if (assetListContainer != null)
                        {
                            assetListContainer.Clear();
                            RebuildAssetList(profile, assetListContainer);
                        }
                    });
                    filterToggles.Add(includedToggle);
                    
                    var excludedToggle = new Toggle("Show Only Excluded") { value = showOnlyExcluded };
                    excludedToggle.AddToClassList("yucp-toggle");
                    excludedToggle.RegisterValueChangedCallback(evt =>
                    {
                        showOnlyExcluded = evt.newValue;
                        if (evt.newValue) showOnlyIncluded = false;
                        var assetListContainer = section.Q<VisualElement>("asset-list-container");
                        if (assetListContainer != null)
                        {
                            assetListContainer.Clear();
                            RebuildAssetList(profile, assetListContainer);
                        }
                    });
                    filterToggles.Add(excludedToggle);
                    
					// Show Only Derived toggle
					var derivedToggle = new Toggle("Show Only Derived") { value = showOnlyDerived };
					derivedToggle.AddToClassList("yucp-toggle");
					derivedToggle.RegisterValueChangedCallback(evt =>
					{
						showOnlyDerived = evt.newValue;
						var assetListContainer = section.Q<VisualElement>("asset-list-container");
						if (assetListContainer != null)
						{
							assetListContainer.Clear();
							RebuildAssetList(profile, assetListContainer);
						}
					});
					filterToggles.Add(derivedToggle);
					
					section.Add(filterToggles);
                    
                    // Asset list header with actions
                    var listHeader = new VisualElement();
                    listHeader.AddToClassList("yucp-inspector-list-header");
                    listHeader.style.marginBottom = 4;
                    
                    var listTitle = new Label("Discovered Assets");
                    listTitle.AddToClassList("yucp-label");
                    listHeader.Add(listTitle);
                    
                    var listActions = new VisualElement();
                    listActions.AddToClassList("yucp-inspector-list-actions");
                    
                    var includeAllButton = new Button(() => 
                    {
                        Undo.RecordObject(profile, "Include All Assets");
                        foreach (var asset in profile.discoveredAssets)
                            asset.included = true;
                        EditorUtility.SetDirty(profile);
                        AssetDatabase.SaveAssets();
                        UpdateProfileDetails();
                    }) { text = "Include All" };
                    includeAllButton.AddToClassList("yucp-button");
                    includeAllButton.AddToClassList("yucp-button-action");
                    includeAllButton.AddToClassList("yucp-button-small");
                    listActions.Add(includeAllButton);
                    
                    var excludeAllButton = new Button(() => 
                    {
                        Undo.RecordObject(profile, "Exclude All Assets");
                        foreach (var asset in profile.discoveredAssets)
                            asset.included = false;
                        EditorUtility.SetDirty(profile);
                        AssetDatabase.SaveAssets();
                        UpdateProfileDetails();
                    }) { text = "Exclude All" };
                    excludeAllButton.AddToClassList("yucp-button");
                    excludeAllButton.AddToClassList("yucp-button-action");
                    excludeAllButton.AddToClassList("yucp-button-small");
                    listActions.Add(excludeAllButton);
                    
                    listHeader.Add(listActions);
                    section.Add(listHeader);
                    
                    // Filter assets
                    var filteredAssets = profile.discoveredAssets.AsEnumerable();
                    
                    if (!string.IsNullOrWhiteSpace(inspectorSearchFilter))
                    {
                        filteredAssets = filteredAssets.Where(a => 
                            a.assetPath.IndexOf(inspectorSearchFilter, StringComparison.OrdinalIgnoreCase) >= 0);
                    }
                    
                    if (showOnlyIncluded)
                        filteredAssets = filteredAssets.Where(a => a.included);
                    
                    if (showOnlyExcluded)
                        filteredAssets = filteredAssets.Where(a => !a.included);
                    
                    // Filter by source profile (for composite profiles)
                    if (!string.IsNullOrEmpty(sourceProfileFilter) && sourceProfileFilter != "All")
                    {
                        filteredAssets = filteredAssets.Where(a =>
                        {
                            // If asset has source profile, match it
                            if (!string.IsNullOrEmpty(a.sourceProfileName))
                            {
                                return a.sourceProfileName == sourceProfileFilter;
                            }
                            // If no source profile, it's from parent
                            return sourceProfileFilter == profile.packageName;
                        });
                    }
                    
                    var filteredList = filteredAssets.ToList();
                    
                    // Removed top resize handle - only using bottom edge resizing
                    
                    // Asset list container (wraps the scrollview for easy rebuilding)
                    var assetListContainer = new VisualElement();
                    assetListContainer.name = "asset-list-container";
                    // Load inspector height from profile, or use default
                    float profileHeight = profile != null ? profile.InspectorHeight : 500f;
                    assetListContainer.style.height = new Length(profileHeight, LengthUnit.Pixel);
                    assetListContainer.style.minHeight = 200;
                    // Don't set maxHeight - let it grow unlimited
                    assetListContainer.style.flexDirection = FlexDirection.Column; // Ensure children stack vertically
                    assetListContainer.style.overflow = Overflow.Visible; // Allow content to extend
                    assetListContainer.style.position = Position.Relative; // Ensure proper positioning
                    assetListContainer.pickingMode = PickingMode.Position;
                    
                    // Helper method for updating inspector resize height - similar to left pane resize
                    System.Action<Vector2> updateInspectorResizeHeight = (mousePosition) =>
                    {
                        if (!isResizingInspector || !assetListContainer.HasMouseCapture()) return;
                        
                        // Dragging down (mousePosition.y increases) should increase height
                        float deltaY = mousePosition.y - resizeStartY;
                        float newHeight = resizeStartHeight + deltaY;
                        // Allow very large sizes - no upper limit, only enforce minimum
                        newHeight = Mathf.Max(newHeight, 200f);
                        
                        // Update height immediately
                        assetListContainer.style.height = new Length(newHeight, LengthUnit.Pixel);
                        assetListContainer.style.maxHeight = new StyleLength(StyleKeyword.None);
                        assetListContainer.style.flexGrow = 0;
                        assetListContainer.style.flexShrink = 0;
                        assetListContainer.style.overflow = Overflow.Visible;
                        
                        // Force immediate repaint updates
                        assetListContainer.MarkDirtyRepaint();
                        
                        // Update resize rect for cursor
                        var worldBounds = assetListContainer.worldBound;
                        if (!worldBounds.Equals(Rect.zero))
                        {
                            currentResizeRect = new Rect(worldBounds.x, worldBounds.yMax - 10, worldBounds.width, 10);
                        }
                        
                        // Force immediate repaint of the window
                        Repaint();
                    };
                    
                    // Make the bottom edge of the container resizable
                    assetListContainer.RegisterCallback<MouseMoveEvent>(evt =>
                    {
                        if (!isResizingInspector)
                        {
                            // Check if mouse is near the bottom edge (within 10 pixels)
                            var localPos = evt.localMousePosition;
                            float containerHeight = assetListContainer.resolvedStyle.height;
                            if (containerHeight <= 0)
                            {
                                containerHeight = assetListContainer.layout.height;
                            }
                            if (localPos.y >= containerHeight - 10 && localPos.y <= containerHeight + 5)
                            {
                                assetListContainer.style.borderBottomWidth = 2;
                                assetListContainer.style.borderBottomColor = new Color(0.5f, 0.5f, 0.5f, 0.8f);
                                currentResizableContainer = assetListContainer;
                                
                                // Calculate the resize rect in window coordinates for cursor
                                var worldBounds = assetListContainer.worldBound;
                                if (!worldBounds.Equals(Rect.zero))
                                {
                                    currentResizeRect = new Rect(worldBounds.x, worldBounds.yMax - 10, worldBounds.width, 10);
                                }
                            }
                            else
                            {
                                assetListContainer.style.borderBottomWidth = 0;
                                if (currentResizableContainer == assetListContainer)
                                {
                                    currentResizableContainer = null;
                                    currentResizeRect = Rect.zero;
                                }
                            }
                        }
                    });
                    
                    assetListContainer.RegisterCallback<MouseLeaveEvent>(evt =>
                    {
                        if (!isResizingInspector)
                        {
                            assetListContainer.style.borderBottomWidth = 0;
                        }
                    });
                    
                    // Allow resizing from the bottom edge of the container
                    assetListContainer.RegisterCallback<MouseDownEvent>(evt =>
                    {
                        if (evt.button == 0)
                        {
                            var localPos = evt.localMousePosition;
                            float containerHeight = assetListContainer.resolvedStyle.height;
                            if (containerHeight <= 0)
                            {
                                containerHeight = assetListContainer.layout.height;
                            }
                            // Check if click is near bottom edge (within 10 pixels)
                            if (localPos.y >= containerHeight - 10 && localPos.y <= containerHeight + 5)
                            {
                                isResizingInspector = true;
                                resizeStartY = evt.mousePosition.y;
                                float currentHeight = assetListContainer.resolvedStyle.height;
                                if (currentHeight <= 0)
                                {
                                    currentHeight = assetListContainer.layout.height;
                                }
                                resizeStartHeight = currentHeight;
                                assetListContainer.CaptureMouse();
                                evt.StopPropagation();
                            }
                        }
                    });
                    
                    // Handle mouse move during resize
                    assetListContainer.RegisterCallback<MouseMoveEvent>(evt =>
                    {
                        if (isResizingInspector && assetListContainer.HasMouseCapture())
                        {
                            updateInspectorResizeHeight(evt.mousePosition);
                            evt.StopPropagation();
                        }
                    });
                    
                    // Also register on root for better tracking when mouse leaves the container
                    if (rootVisualElement != null)
                    {
                        rootVisualElement.RegisterCallback<MouseMoveEvent>(evt =>
                        {
                            if (isResizingInspector && assetListContainer.HasMouseCapture())
                            {
                                updateInspectorResizeHeight(evt.mousePosition);
                                evt.StopPropagation();
                            }
                        }, TrickleDown.TrickleDown);
                    }
                    
                    assetListContainer.RegisterCallback<MouseUpEvent>(evt =>
                    {
                        if (evt.button == 0 && isResizingInspector)
                        {
                            isResizingInspector = false;
                            assetListContainer.ReleaseMouse();
                            assetListContainer.style.borderBottomWidth = 0;
                            
                            // Save the new height to the profile
                            if (profile != null)
                            {
                                float finalHeight = assetListContainer.resolvedStyle.height;
                                if (finalHeight <= 0)
                                {
                                    finalHeight = assetListContainer.layout.height;
                                }
                                if (finalHeight > 0)
                                {
                                    Undo.RecordObject(profile, "Resize Inspector");
                                    profile.InspectorHeight = finalHeight;
                                    EditorUtility.SetDirty(profile);
                                }
                            }
                            
                            currentResizeRect = Rect.zero;
                            evt.StopPropagation();
                        }
                    });
                    
                    // Also handle mouse up on root to ensure we release mouse capture
                    if (rootVisualElement != null)
                    {
                        rootVisualElement.RegisterCallback<MouseUpEvent>(evt =>
                        {
                            if (evt.button == 0 && isResizingInspector)
                            {
                                isResizingInspector = false;
                                if (assetListContainer.HasMouseCapture())
                                {
                                    assetListContainer.ReleaseMouse();
                                }
                                assetListContainer.style.borderBottomWidth = 0;
                                
                                // Save the new height to the profile
                                if (profile != null)
                                {
                                    float finalHeight = assetListContainer.resolvedStyle.height;
                                    if (finalHeight <= 0)
                                    {
                                        finalHeight = assetListContainer.layout.height;
                                    }
                                    if (finalHeight > 0)
                                    {
                                        Undo.RecordObject(profile, "Resize Inspector");
                                        profile.InspectorHeight = finalHeight;
                                        EditorUtility.SetDirty(profile);
                                    }
                                }
                                
                                currentResizeRect = Rect.zero;
                            }
                        });
                    }
                    
                    RebuildAssetList(profile, assetListContainer);
                    
                    // Store reference to container for resize updates
                    assetListContainer.userData = "asset-list-container-ref";
                    
                    section.Add(assetListContainer);
                    
                    // After adding to section, ensure ScrollView max-height is overridden
                    EditorApplication.delayCall += () =>
                    {
                        var scrollView = assetListContainer.Q<ScrollView>(className: "yucp-inspector-list");
                        if (scrollView != null)
                        {
                            scrollView.style.maxHeight = new StyleLength(StyleKeyword.None);
                        }
                    };
                    
                    // Permanent ignore list
                    var ignoreLabel = new Label("Permanent Ignore List");
                    ignoreLabel.AddToClassList("yucp-label");
                    ignoreLabel.style.marginTop = 12;
                    ignoreLabel.style.marginBottom = 4;
                    section.Add(ignoreLabel);
                    
                    var ignoreHelpBox = new VisualElement();
                    ignoreHelpBox.AddToClassList("yucp-help-box");
                    var ignoreHelpText = new Label("Folders in this list will be permanently ignored from all exports (like .gitignore).");
                    ignoreHelpText.AddToClassList("yucp-help-box-text");
                    ignoreHelpBox.Add(ignoreHelpText);
                    section.Add(ignoreHelpBox);
                    
                    if (profile.PermanentIgnoreFolders == null || profile.PermanentIgnoreFolders.Count == 0)
                    {
                        var noIgnoresLabel = new Label("No folders in ignore list.");
                        noIgnoresLabel.AddToClassList("yucp-label-secondary");
                        noIgnoresLabel.style.paddingTop = 8;
                        noIgnoresLabel.style.paddingBottom = 8;
                        section.Add(noIgnoresLabel);
                    }
                    else
                    {
                        foreach (var ignoreFolder in profile.PermanentIgnoreFolders.ToList())
                        {
                            var ignoreItem = new VisualElement();
                            ignoreItem.AddToClassList("yucp-folder-item");
                            
                            var ignorePathLabel = new Label(ignoreFolder);
                            ignorePathLabel.AddToClassList("yucp-folder-item-path");
                            ignoreItem.Add(ignorePathLabel);
                            
                            var removeIgnoreButton = new Button(() => RemoveFromIgnoreList(profile, ignoreFolder)) { text = "×" };
                            removeIgnoreButton.AddToClassList("yucp-button");
                            removeIgnoreButton.AddToClassList("yucp-folder-item-remove");
                            removeIgnoreButton.tooltip = "Remove from ignore list";
                            ignoreItem.Add(removeIgnoreButton);
                            
                            section.Add(ignoreItem);
                        }
                    }
                    
                    var addIgnoreButton = new Button(() => 
                    {
                        string selectedFolder = EditorUtility.OpenFolderPanel("Select Folder to Ignore", Application.dataPath, "");
                        if (!string.IsNullOrEmpty(selectedFolder))
                        {
                            // Use full absolute path instead of relative path
                            AddFolderToIgnoreList(profile, selectedFolder);
                        }
                    }) { text = "+ Add Folder to Ignore List" };
                    addIgnoreButton.AddToClassList("yucp-button");
                    addIgnoreButton.style.marginTop = 8;
                    section.Add(addIgnoreButton);
                }
            }
            
            return section;
        }

        private void RebuildAssetList(ExportProfile profile, VisualElement container)
        {
            // Filter assets
            var filteredAssets = profile.discoveredAssets.AsEnumerable();
            
            // Respect the Include Dependencies toggle - filter out dependencies if toggle is off
            if (!profile.includeDependencies)
            {
                filteredAssets = filteredAssets.Where(a => !a.isDependency);
            }
            
            if (!string.IsNullOrWhiteSpace(inspectorSearchFilter))
            {
                filteredAssets = filteredAssets.Where(a => 
                    a.assetPath.IndexOf(inspectorSearchFilter, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            
            if (showOnlyIncluded)
                filteredAssets = filteredAssets.Where(a => a.included);
            
            if (showOnlyExcluded)
                filteredAssets = filteredAssets.Where(a => !a.included);
			
			if (showOnlyDerived)
				filteredAssets = filteredAssets.Where(a => IsDerivedFbx(a.assetPath, out _, out _));
            
            // Filter by source profile (for composite profiles)
            if (!string.IsNullOrEmpty(sourceProfileFilter) && sourceProfileFilter != "All")
            {
                filteredAssets = filteredAssets.Where(a =>
                {
                    // If asset has source profile, match it
                    if (!string.IsNullOrEmpty(a.sourceProfileName))
                    {
                        return a.sourceProfileName == sourceProfileFilter;
                    }
                    // If no source profile, it's from parent
                    return sourceProfileFilter == profile.packageName;
                });
            }
            
            var filteredList = filteredAssets.ToList();
            
            // Asset list scrollview - make it fill the container
            var assetListScroll = new ScrollView();
            assetListScroll.AddToClassList("yucp-inspector-list");
            assetListScroll.style.flexGrow = 1; // Fill available space
            assetListScroll.style.flexShrink = 1; // Allow shrinking
            assetListScroll.style.width = Length.Percent(100); // Full width
            assetListScroll.style.height = Length.Percent(100); // Full height of container
            assetListScroll.style.overflow = Overflow.Hidden; // Prevent horizontal scrolling
            assetListScroll.horizontalScrollerVisibility = ScrollerVisibility.Hidden; // Hide horizontal scrollbar
            // Override CSS max-height constraint to allow unlimited resizing
            assetListScroll.style.maxHeight = new StyleLength(StyleKeyword.None);
            
            if (filteredList.Count == 0)
            {
                var emptyLabel = new Label("No assets match the current filters.");
                emptyLabel.AddToClassList("yucp-label-secondary");
                emptyLabel.style.paddingTop = 20;
                emptyLabel.style.paddingBottom = 20;
                emptyLabel.style.unityTextAlign = TextAnchor.MiddleCenter;
                assetListScroll.Add(emptyLabel);
            }
            else
            {
                // Build hierarchical folder tree
                var rootNode = BuildFolderTree(filteredList.Where(a => !a.isFolder).ToList());
                
                // Render the tree
                RenderFolderTree(rootNode, assetListScroll, profile, 0);
            }
            
            container.Add(assetListScroll);
        }
        
        private FolderTreeNode BuildFolderTree(List<DiscoveredAsset> assets)
        {
            var root = new FolderTreeNode("Assets", "Assets");
            root.IsExpanded = true;
            
            foreach (var asset in assets)
            {
                string folderPath = asset.GetFolderPath();
                if (string.IsNullOrEmpty(folderPath) || folderPath == "Assets")
                {
                    root.Assets.Add(asset);
                    continue;
                }
                
                // Split path into segments
                string[] segments = folderPath.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
                if (segments[0] == "Assets")
                {
                    segments = segments.Skip(1).ToArray();
                }
                
                FolderTreeNode current = root;
                string currentPath = "Assets";
                
                foreach (string segment in segments)
                {
                    currentPath = currentPath == "Assets" ? $"Assets/{segment}" : $"{currentPath}/{segment}";
                    
                    var child = current.Children.FirstOrDefault(c => c.Name == segment);
                    if (child == null)
                    {
                        child = new FolderTreeNode(segment, currentPath);
                        // Default to expanded for better navigation, unless user has collapsed it
                        child.IsExpanded = folderExpandedStates.ContainsKey(currentPath) 
                            ? folderExpandedStates[currentPath] 
                            : true;
                        current.Children.Add(child);
                    }
                    else
                    {
                        // Ensure existing nodes respect saved state
                        if (folderExpandedStates.ContainsKey(currentPath))
                        {
                            child.IsExpanded = folderExpandedStates[currentPath];
                        }
                    }
                    
                    current = child;
                }
                
                current.Assets.Add(asset);
            }
            
            // Sort children and assets
            SortFolderTree(root);
            
            return root;
        }
        
        private void SortFolderTree(FolderTreeNode node)
        {
            node.Children = node.Children.OrderBy(c => c.Name).ToList();
            node.Assets = node.Assets.OrderBy(a => a.GetDisplayName()).ToList();
            
            foreach (var child in node.Children)
            {
                SortFolderTree(child);
            }
        }
        
        private void RenderFolderTree(FolderTreeNode node, VisualElement container, ExportProfile profile, int depth)
        {
            // Only render if node has assets or children
            if (node.Assets.Count == 0 && node.Children.Count == 0 && depth > 0)
                return;
            
            if (depth > 0 || (depth == 0 && node.Assets.Count > 0))
            {
                if (depth > 0)
                {
                    var folderHeader = CreateFolderHeader(node, profile, depth);
                    container.Add(folderHeader);
                }
            }
            
            if (node.Assets.Count > 0 && (depth == 0 || node.IsExpanded))
            {
                foreach (var asset in node.Assets)
                {
                    var assetItem = CreateAssetItem(asset, profile, depth == 0 ? 0 : depth + 1);
                    container.Add(assetItem);
                }
            }
            
            if (node.Children.Count > 0 && (depth == 0 || node.IsExpanded))
            {
                foreach (var child in node.Children)
                {
                    RenderFolderTree(child, container, profile, depth + 1);
                }
            }
        }
        
        private VisualElement CreateFolderHeader(FolderTreeNode node, ExportProfile profile, int depth)
        {
            var folderHeader = new VisualElement();
            folderHeader.AddToClassList("yucp-inspector-folder-header");
            folderHeader.style.paddingLeft = 12 + (depth * 24);
            
            var folderHeaderContent = new VisualElement();
            folderHeaderContent.AddToClassList("yucp-inspector-folder-content");
            
            // Expand/collapse button
            var expandButton = new Button(() =>
            {
                node.IsExpanded = !node.IsExpanded;
                folderExpandedStates[node.FullPath] = node.IsExpanded;
                
                VisualElement scrollView = folderHeader.parent;
                if (scrollView != null && scrollView is ScrollView)
                {
                    // Store current scroll position
                    float scrollValue = (scrollView as ScrollView).verticalScroller.value;
                    
                    VisualElement container = scrollView.parent;
                    if (container != null && container.name == "asset-list-container")
                    {
                        container.Clear();
                        RebuildAssetList(profile, container);
                        
                        // Restore scroll position after layout update
                        EditorApplication.delayCall += () =>
                        {
                            var newScrollView = container.Q<ScrollView>();
                            if (newScrollView != null)
                            {
                                newScrollView.verticalScroller.value = scrollValue;
                            }
                        };
                    }
                }
            });
            expandButton.AddToClassList("yucp-folder-expand-button");
            expandButton.text = node.IsExpanded ? "▼" : "▶";
            folderHeaderContent.Add(expandButton);
            
            var folderLabel = new Label(node.Name);
            folderLabel.AddToClassList("yucp-inspector-folder-label");
            folderLabel.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button == 0) // Left click
                {
                    PingAsset(node.FullPath);
                }
            });
            folderHeaderContent.Add(folderLabel);
            
            // Asset count badge
            int totalAssets = CountTotalAssets(node);
            if (totalAssets > 0)
            {
                var countBadge = new Label($"({totalAssets})");
                countBadge.AddToClassList("yucp-folder-count-badge");
                folderHeaderContent.Add(countBadge);
            }
            
            // Actions toolbar
            var folderActions = new VisualElement();
            folderActions.AddToClassList("yucp-inspector-folder-actions");
            
            // .yucpignore Create/Edit button
            // Convert relative path (e.g., "Assets/Folder") to absolute path
            // node.FullPath should be relative like "Assets/Folder/Subfolder"
            string folderFullPath;
            
            // Get project root (parent of Assets folder)
            string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            
            // Normalize node.FullPath - ensure it uses forward slashes
            string pathToProcess = node.FullPath.Replace('\\', '/');
            
            // Extract the relative part starting from "Assets/"
            // This handles cases where the path might already be absolute or have duplicates
            string relativePath = pathToProcess;
            
            // Find the last occurrence of "Assets/" in the path (in case of duplicates)
            int lastAssetsIndex = pathToProcess.LastIndexOf("Assets/", StringComparison.OrdinalIgnoreCase);
            if (lastAssetsIndex >= 0)
            {
                // Extract everything from "Assets/" onwards
                relativePath = pathToProcess.Substring(lastAssetsIndex);
            }
            else
            {
                // No "Assets/" found - check if it starts with "Assets" (without slash)
                int assetsIndex = pathToProcess.LastIndexOf("Assets", StringComparison.OrdinalIgnoreCase);
                if (assetsIndex >= 0)
                {
                    // Extract from "Assets" and ensure it has a slash
                    relativePath = pathToProcess.Substring(assetsIndex);
                    if (!relativePath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
                    {
                        relativePath = "Assets/" + relativePath.Substring(6).TrimStart('/');
                    }
                }
                else
                {
                    // Doesn't contain "Assets" at all - prepend it
                    relativePath = "Assets/" + pathToProcess.TrimStart('/');
                }
            }
            
            // Final safety check: if relativePath still contains a drive letter, extract just the Assets part
            if (relativePath.Contains(":"))
            {
                int assetsIndex = relativePath.LastIndexOf("Assets/", StringComparison.OrdinalIgnoreCase);
                if (assetsIndex >= 0)
                {
                    relativePath = relativePath.Substring(assetsIndex);
                }
            }
            
            // Combine with project root to get absolute path
            // Use Path.Combine which will handle the case where relativePath is already absolute
            folderFullPath = Path.GetFullPath(Path.Combine(projectRoot, relativePath));
            
            // Final validation: if the result still contains duplicates, fix it
            string expectedAssetsPath = Path.Combine(projectRoot, "Assets");
            if (folderFullPath.Contains(expectedAssetsPath + Path.DirectorySeparatorChar + expectedAssetsPath))
            {
                // Remove the duplicate
                int dupIndex = folderFullPath.IndexOf(expectedAssetsPath + Path.DirectorySeparatorChar + expectedAssetsPath);
                folderFullPath = folderFullPath.Substring(0, dupIndex + expectedAssetsPath.Length) + 
                               folderFullPath.Substring(dupIndex + expectedAssetsPath.Length + expectedAssetsPath.Length);
            }
            
            bool hasIgnoreFile = YucpIgnoreHandler.HasIgnoreFile(folderFullPath);
            
            if (hasIgnoreFile)
            {
                var editIgnoreButton = new Button(() => OpenYucpIgnoreFile(folderFullPath)) { text = "Edit .yucpignore" };
                editIgnoreButton.AddToClassList("yucp-button");
                editIgnoreButton.AddToClassList("yucp-button-small");
                folderActions.Add(editIgnoreButton);
            }
            
            var ignoreButton = new Button(() => AddFolderToIgnoreList(profile, node.FullPath)) { text = "Add to Ignore" };
            ignoreButton.AddToClassList("yucp-button");
            ignoreButton.AddToClassList("yucp-button-small");
            folderActions.Add(ignoreButton);
            
            folderHeaderContent.Add(folderActions);
            folderHeader.Add(folderHeaderContent);
            
            return folderHeader;
        }
        
        private int CountTotalAssets(FolderTreeNode node)
        {
            int count = node.Assets.Count;
            foreach (var child in node.Children)
            {
                count += CountTotalAssets(child);
            }
            return count;
        }
        
        /// <summary>
        /// Ping an asset in the Project window by its path
        /// </summary>
        private void PingAsset(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return;
            
            // Normalize the path - ensure it's relative to Assets
            string relativePath = assetPath;
            if (Path.IsPathRooted(relativePath))
            {
                // Extract relative part if absolute
                int assetsIndex = relativePath.LastIndexOf("Assets/", StringComparison.OrdinalIgnoreCase);
                if (assetsIndex >= 0)
                {
                    relativePath = relativePath.Substring(assetsIndex);
                }
                else
                {
                    // Try to convert absolute path to relative
                    string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                    if (relativePath.StartsWith(projectRoot, StringComparison.OrdinalIgnoreCase))
                    {
                        relativePath = relativePath.Substring(projectRoot.Length).Replace('\\', '/').TrimStart('/');
                    }
                }
            }
            
            // Ensure it starts with Assets/
            if (!relativePath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
            {
                if (relativePath.StartsWith("Assets", StringComparison.OrdinalIgnoreCase))
                {
                    relativePath = "Assets/" + relativePath.Substring(6).TrimStart('/');
                }
                else
                {
                    relativePath = "Assets/" + relativePath.TrimStart('/');
                }
            }
            
            // Load and ping the asset
            var obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(relativePath);
            if (obj != null)
            {
                Selection.activeObject = obj;
                EditorGUIUtility.PingObject(obj);
            }
        }
        
        private VisualElement CreateAssetItem(DiscoveredAsset asset, ExportProfile profile, int depth)
        {
            var assetItem = new VisualElement();
            assetItem.AddToClassList("yucp-asset-item");
            assetItem.style.paddingLeft = 12 + (depth * 24);
            
            // Checkbox
            var checkbox = new Toggle { value = asset.included };
            checkbox.AddToClassList("yucp-asset-item-checkbox");
            checkbox.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(profile, "Toggle Asset Inclusion");
                asset.included = evt.newValue;
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
            });
            assetItem.Add(checkbox);
            
            // Icon
            var icon = new Label(GetAssetTypeIcon(asset.assetType));
            icon.AddToClassList("yucp-asset-item-icon");
            assetItem.Add(icon);
            
            // Name - make it clickable to navigate to asset
            var nameLabel = new Label(asset.GetDisplayName());
            nameLabel.AddToClassList("yucp-asset-item-name");
            // Compute derived flag once for this row
            DerivedSettings derivedSettings;
            string derivedBasePath;
            bool isDerivedFbx = IsDerivedFbx(asset.assetPath, out derivedSettings, out derivedBasePath);
            if (asset.isDependency)
            {
                nameLabel.text += " [Dep]";
            }
            if (isDerivedFbx)
            {
                nameLabel.text += string.IsNullOrEmpty(derivedBasePath) ? " [Derived: Base Missing]" : " [Derived]";
            }
            
            // Add click handler to navigate to asset
            nameLabel.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button == 0) // Left click
                {
                    PingAsset(asset.assetPath);
                }
            });
            assetItem.Add(nameLabel);
            
            // Type
            string typeText = asset.assetType;
            if (isDerivedFbx && typeText.Equals("Model", StringComparison.OrdinalIgnoreCase))
            {
                typeText = "Model (Derived)";
            }
            var typeLabel = new Label(typeText);
            typeLabel.AddToClassList("yucp-asset-item-type");
            assetItem.Add(typeLabel);
            
            // Size
            if (!asset.isFolder && asset.fileSize > 0)
            {
                var sizeLabel = new Label(FormatBytes(asset.fileSize));
                sizeLabel.AddToClassList("yucp-asset-item-size");
                assetItem.Add(sizeLabel);
            }
            
            // Source profile badge (for composite profiles)
            if (!string.IsNullOrEmpty(asset.sourceProfileName))
            {
                var sourceBadge = new Label($"[{asset.sourceProfileName}]");
                sourceBadge.AddToClassList("yucp-label-secondary");
                sourceBadge.style.marginLeft = 6;
                sourceBadge.style.fontSize = 10;
                sourceBadge.style.color = new Color(0.6f, 0.8f, 0.9f);
                assetItem.Add(sourceBadge);
            }
            
            // Derived patch badge and quick actions for FBX
            if (isDerivedFbx)
            {
                var badge = new Label(string.IsNullOrEmpty(derivedBasePath) ? "[Derived Patch: Base Missing]" : "[Derived Patch]");
                badge.AddToClassList("yucp-label-secondary");
                badge.style.marginLeft = 6;
                badge.style.color = string.IsNullOrEmpty(derivedBasePath) ? new Color(0.95f, 0.75f, 0.2f) : new Color(0.2f, 0.8f, 0.8f);
                assetItem.Add(badge);
                
                var actionsRow = new VisualElement();
                actionsRow.style.flexDirection = FlexDirection.Row;
                actionsRow.style.marginLeft = 6;
                
                var optionsButton = new Button(() =>
                {
                    string relativePath = asset.assetPath;
                    if (Path.IsPathRooted(relativePath))
                    {
                        string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                        if (relativePath.StartsWith(projectPath, StringComparison.OrdinalIgnoreCase))
                        {
                            relativePath = relativePath.Substring(projectPath.Length).Replace('\\', '/').TrimStart('/');
                        }
                    }
                    var obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(relativePath);
                    Selection.activeObject = obj;
                    EditorGUIUtility.PingObject(obj);
                }) { text = "Options" };
                optionsButton.AddToClassList("yucp-button");
                optionsButton.AddToClassList("yucp-button-small");
                actionsRow.Add(optionsButton);
                
                var clearButton = new Button(() =>
                {
                    string relativePath = asset.assetPath;
                    if (Path.IsPathRooted(relativePath))
                    {
                        string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                        if (relativePath.StartsWith(projectPath, StringComparison.OrdinalIgnoreCase))
                        {
                            relativePath = relativePath.Substring(projectPath.Length).Replace('\\', '/').TrimStart('/');
                        }
                    }
                    var importer = AssetImporter.GetAtPath(relativePath) as ModelImporter;
                    if (importer != null)
                    {
                        try
                        {
                            var s = string.IsNullOrEmpty(importer.userData) ? new DerivedSettings() : JsonUtility.FromJson<DerivedSettings>(importer.userData) ?? new DerivedSettings();
                            s.isDerived = false;
                            importer.userData = JsonUtility.ToJson(s);
                            importer.SaveAndReimport();
                            UpdateProfileDetails();
                        }
                        catch { /* ignore */ }
                    }
                }) { text = "Clear" };
                clearButton.AddToClassList("yucp-button");
                clearButton.AddToClassList("yucp-button-small");
                actionsRow.Add(clearButton);
                
                assetItem.Add(actionsRow);
            }
            
            return assetItem;
        }
		
		[System.Serializable]
		private class DerivedSettings
		{
			public bool isDerived;
			public string baseGuid;
			public string friendlyName;
			public string category;
		}
		
		private bool IsDerivedFbx(string assetPath, out DerivedSettings settings, out string basePath)
		{
			settings = null;
			basePath = null;
			if (string.IsNullOrEmpty(assetPath)) return false;
			if (!assetPath.EndsWith(".fbx", StringComparison.OrdinalIgnoreCase)) return false;
			
			// Convert to relative path if needed (for AssetDatabase/AssetImporter APIs)
			string relativePath = assetPath;
			if (Path.IsPathRooted(relativePath))
			{
				string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
				if (relativePath.StartsWith(projectPath, StringComparison.OrdinalIgnoreCase))
				{
					relativePath = relativePath.Substring(projectPath.Length).Replace('\\', '/').TrimStart('/');
				}
			}
			
			// Try reading from importer first
			var importer = AssetImporter.GetAtPath(relativePath) as ModelImporter;
			if (importer != null)
			{
				try
				{
					string userDataJson = importer.userData;
					if (!string.IsNullOrEmpty(userDataJson))
					{
						settings = JsonUtility.FromJson<DerivedSettings>(userDataJson);
						if (settings != null && settings.isDerived)
						{
							basePath = string.IsNullOrEmpty(settings.baseGuid) ? null : AssetDatabase.GUIDToAssetPath(settings.baseGuid);
							return true;
						}
					}
				}
				catch (Exception ex)
				{
					Debug.LogWarning($"[YUCP PackageExporter] Failed to parse importer userData for {assetPath}: {ex.Message}\nuserData was: '{importer.userData}'");
				}
			}
			
			// Fallback: read directly from .meta file
			try
			{
				// Use original assetPath for file system operations (can be absolute or relative)
				string metaPath = assetPath + ".meta";
				// If relative path, convert to absolute for File operations
				if (!Path.IsPathRooted(metaPath))
				{
					string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
					metaPath = Path.GetFullPath(Path.Combine(projectPath, metaPath));
				}
				if (File.Exists(metaPath))
				{
					string metaContent = File.ReadAllText(metaPath);
					// Look for userData in the meta file
					// Unity stores it as: userData: <json string>
					// But it might be on multiple lines or have special formatting
					
					// Try regex to find userData line
					// Match: userData: <value> where value can be quoted JSON or empty
					var userDataMatch = System.Text.RegularExpressions.Regex.Match(metaContent, @"userData:\s*([^\r\n]*)", System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Multiline);
					if (userDataMatch.Success)
					{
						string userDataJson = userDataMatch.Groups[1].Value.Trim();
						// Skip if empty or matches Unity's default format
						if (string.IsNullOrEmpty(userDataJson) || userDataJson == "assetBundleName:")
						{
							// Not our custom userData, skip
						}
						else
						{
							// Unity stores userData as a quoted string in YAML, so strip surrounding quotes first
							if ((userDataJson.StartsWith("'") && userDataJson.EndsWith("'")) || 
							    (userDataJson.StartsWith("\"") && userDataJson.EndsWith("\"")))
							{
								userDataJson = userDataJson.Substring(1, userDataJson.Length - 2);
							}
							
							// Now check if it's our JSON format
							if (!string.IsNullOrEmpty(userDataJson) && userDataJson.StartsWith("{"))
							{
								try
								{
									settings = JsonUtility.FromJson<DerivedSettings>(userDataJson);
									if (settings != null && settings.isDerived)
									{
										basePath = string.IsNullOrEmpty(settings.baseGuid) ? null : AssetDatabase.GUIDToAssetPath(settings.baseGuid);
										return true;
									}
								}
								catch (Exception jsonEx)
								{
									Debug.LogWarning($"[YUCP PackageExporter] Failed to parse userData JSON from .meta for {Path.GetFileName(assetPath)}: {jsonEx.Message}\nExtracted value: '{userDataJson}'");
								}
							}
						}
					}
					else
					{
						// No userData found - check if the CustomEditor is even saving
						// This is normal if the FBX hasn't been marked as derived
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning($"[YUCP PackageExporter] Failed to read .meta file for {assetPath}: {ex.Message}\n{ex.StackTrace}");
			}
			
			return false;
		}

        private void RebuildDependencyList(ExportProfile profile, VisualElement section, VisualElement container)
        {
            var scrollView = container.GetFirstAncestorOfType<ScrollView>();
            float? sectionTopRelativeToViewport = null;
            
            if (scrollView != null && section != null)
            {
                var sectionWorldBounds = section.worldBound;
                var scrollViewWorldBounds = scrollView.worldBound;
                
                if (sectionWorldBounds.height > 0 && scrollViewWorldBounds.height > 0)
                {
                    float sectionTopInViewport = sectionWorldBounds.y - scrollViewWorldBounds.y;
                    sectionTopRelativeToViewport = sectionTopInViewport;
                }
            }
            
            var filteredDependencies = profile.dependencies.AsEnumerable();
            
            if (!string.IsNullOrWhiteSpace(dependenciesSearchFilter))
            {
                filteredDependencies = filteredDependencies.Where(d =>
                    d.packageName.IndexOf(dependenciesSearchFilter, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    (!string.IsNullOrEmpty(d.displayName) && d.displayName.IndexOf(dependenciesSearchFilter, StringComparison.OrdinalIgnoreCase) >= 0));
            }
            
            // Apply toggle filters if they exist
            var enabledFilter = section.Q<Toggle>("enabled-filter");
            var vpmFilter = section.Q<Toggle>("vpm-filter");
            
            if (enabledFilter?.value == true)
            {
                filteredDependencies = filteredDependencies.Where(d => d.enabled);
            }
            
            if (vpmFilter?.value == true)
            {
                filteredDependencies = filteredDependencies.Where(d => d.isVpmDependency);
            }
            
            var filteredList = filteredDependencies.ToList();
            
            // Dependencies list
            if (filteredList.Count == 0 && profile.dependencies.Count > 0)
            {
                var emptyLabel = new Label("No dependencies match the current filter.");
                emptyLabel.AddToClassList("yucp-label-secondary");
                emptyLabel.style.paddingTop = 10;
                emptyLabel.style.paddingBottom = 10;
                container.Add(emptyLabel);
            }
            else if (profile.dependencies.Count == 0)
            {
                var emptyLabel = new Label("No dependencies configured. Add manually or scan.");
                emptyLabel.AddToClassList("yucp-label-secondary");
                emptyLabel.style.paddingTop = 10;
                emptyLabel.style.paddingBottom = 10;
                container.Add(emptyLabel);
            }
            else
            {
                for (int i = 0; i < filteredList.Count; i++)
                {
                    var dep = filteredList[i];
                    var originalIndex = profile.dependencies.IndexOf(dep);
                    var depCard = CreateDependencyCard(dep, originalIndex, profile);
                    container.Add(depCard);
                }
                
                // Select all/none buttons
                var selectButtons = new VisualElement();
                selectButtons.style.flexDirection = FlexDirection.Row;
                selectButtons.style.marginTop = 8;
                selectButtons.style.marginBottom = 8;
                
                var selectAllButton = new Button(() => 
                {
                    foreach (var dep in profile.dependencies)
                    {
                        dep.enabled = true;
                    }
                    EditorUtility.SetDirty(profile);
                    container.Clear();
                    RebuildDependencyList(profile, section, container);
                }) { text = "Select All" };
                selectAllButton.AddToClassList("yucp-button");
                selectAllButton.AddToClassList("yucp-button-action");
                selectAllButton.style.flexGrow = 1;
                selectAllButton.style.marginRight = 4;
                selectButtons.Add(selectAllButton);
                
                var deselectAllButton = new Button(() => 
                {
                    foreach (var dep in profile.dependencies)
                    {
                        dep.enabled = false;
                    }
                    EditorUtility.SetDirty(profile);
                    container.Clear();
                    RebuildDependencyList(profile, section, container);
                }) { text = "Deselect All" };
                deselectAllButton.AddToClassList("yucp-button");
                deselectAllButton.AddToClassList("yucp-button-action");
                deselectAllButton.style.flexGrow = 1;
                deselectAllButton.style.marginLeft = 4;
                selectButtons.Add(deselectAllButton);
                
                container.Add(selectButtons);
            }
            
            if (scrollView != null && sectionTopRelativeToViewport.HasValue)
            {
                scrollView.schedule.Execute(() =>
                {
                    if (scrollView != null && section != null)
                    {
                        var sectionWorldBounds = section.worldBound;
                        var scrollViewWorldBounds = scrollView.worldBound;
                        
                        if (sectionWorldBounds.height > 0)
                        {
                            float currentSectionTop = sectionWorldBounds.y - scrollViewWorldBounds.y;
                            float targetSectionTop = sectionTopRelativeToViewport.Value;
                            float scrollAdjustment = currentSectionTop - targetSectionTop;
                            
                            if (Mathf.Abs(scrollAdjustment) > 1f)
                            {
                                float newScrollValue = Mathf.Max(0, scrollView.verticalScroller.value + scrollAdjustment);
                                scrollView.verticalScroller.value = newScrollValue;
                            }
                        }
                    }
                });
            }
        }

        private VisualElement CreateDependenciesSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var header = CreateCollapsibleHeader("Package Dependencies", 
                () => showDependencies, 
                (value) => { showDependencies = value; }, 
                () => UpdateProfileDetails());
            section.Add(header);
            
            if (!showDependencies)
            {
                return section;
            }
            
            var helpBox = new VisualElement();
            helpBox.AddToClassList("yucp-help-box");
            var helpText = new Label("Bundle: Include dependency files directly in the exported package\nDependency: Add to package.json for automatic download when package is installed");
            helpText.AddToClassList("yucp-help-box-text");
            helpBox.Add(helpText);
            section.Add(helpBox);
            
            // Disclaimer about automatic installation
            var disclaimerBox = new VisualElement();
            disclaimerBox.AddToClassList("yucp-help-box");
            disclaimerBox.style.marginTop = 8;
            disclaimerBox.style.backgroundColor = new Color(0.2f, 0.4f, 0.6f, 0.2f);
            var disclaimerText = new Label("Everything you select here will be asked for the user to install when importing the package, and will be installed automatically if clicked \"Install\" on their end");
            disclaimerText.AddToClassList("yucp-help-box-text");
            disclaimerText.style.unityFontStyleAndWeight = FontStyle.Bold;
            disclaimerBox.Add(disclaimerText);
            section.Add(disclaimerBox);
            
            // Search/Filter for dependencies
            if (profile.dependencies.Count > 0)
            {
                var searchRow = new VisualElement();
                searchRow.style.flexDirection = FlexDirection.Row;
                searchRow.style.marginTop = 8;
                searchRow.style.marginBottom = 8;
                
                var searchField = new TextField { value = dependenciesSearchFilter };
                searchField.AddToClassList("yucp-input");
                searchField.style.flexGrow = 1;
                searchField.style.marginRight = 4;
                searchField.name = "dependencies-search-field";
                searchField.RegisterValueChangedCallback(evt =>
                {
                    dependenciesSearchFilter = evt.newValue;
                    // Update dependency list without rebuilding entire UI
                    var depListContainer = section.Q<VisualElement>("dep-list-container");
                    if (depListContainer != null)
                    {
                        depListContainer.Clear();
                        RebuildDependencyList(profile, section, depListContainer);
                    }
                });
                searchRow.Add(searchField);
                
                var clearSearchButton = new Button(() => 
                {
                    dependenciesSearchFilter = "";
                    var searchField = section.Q<TextField>("dependencies-search-field");
                    if (searchField != null)
                    {
                        searchField.value = "";
                    }
                    var depListContainer = section.Q<VisualElement>("dep-list-container");
                    if (depListContainer != null)
                    {
                        depListContainer.Clear();
                        RebuildDependencyList(profile, section, depListContainer);
                    }
                }) { text = "Clear" };
                clearSearchButton.AddToClassList("yucp-button");
                clearSearchButton.AddToClassList("yucp-button-small");
                searchRow.Add(clearSearchButton);
                
                section.Add(searchRow);
                
                // Filter toggles
                var filterRow = new VisualElement();
                filterRow.style.flexDirection = FlexDirection.Row;
                filterRow.style.marginBottom = 8;
                
                var enabledToggle = new Toggle("Enabled Only") { value = false };
                enabledToggle.name = "enabled-filter";
                enabledToggle.AddToClassList("yucp-toggle");
                enabledToggle.RegisterValueChangedCallback(evt =>
                {
                    var depListContainer = section.Q<VisualElement>("dep-list-container");
                    if (depListContainer != null)
                    {
                        depListContainer.Clear();
                        RebuildDependencyList(profile, section, depListContainer);
                    }
                });
                filterRow.Add(enabledToggle);
                
                var vpmToggle = new Toggle("VPM Only") { value = false };
                vpmToggle.name = "vpm-filter";
                vpmToggle.AddToClassList("yucp-toggle");
                vpmToggle.RegisterValueChangedCallback(evt =>
                {
                    var depListContainer = section.Q<VisualElement>("dep-list-container");
                    if (depListContainer != null)
                    {
                        depListContainer.Clear();
                        RebuildDependencyList(profile, section, depListContainer);
                    }
                });
                filterRow.Add(vpmToggle);
                
                section.Add(filterRow);
            }
            
            // Dependency list container (wraps the list for easy rebuilding)
            var depListContainer = new VisualElement();
            depListContainer.name = "dep-list-container";
            depListContainer.AddToClassList("yucp-dependency-list-container");
            depListContainer.style.width = Length.Percent(100);
            depListContainer.style.maxWidth = Length.Percent(100);
            depListContainer.style.minWidth = 0;
            depListContainer.style.overflow = Overflow.Hidden;
            RebuildDependencyList(profile, section, depListContainer);
            section.Add(depListContainer);
            
            // Action buttons
            var addButton = new Button(() => AddDependency(profile)) { text = "Add dependency manually" };
            addButton.AddToClassList("yucp-button");
            addButton.AddToClassList("yucp-button-action");
            addButton.style.flexGrow = 1;
            addButton.style.marginTop = 8;
            section.Add(addButton);
            
            // Action buttons - row 2 (Auto-Detect)
            if (profile.dependencies.Count > 0 && profile.foldersToExport.Count > 0)
            {
                var autoDetectButton = new Button(() => AutoDetectUsedDependencies(profile)) { text = "Auto-Detect Used" };
                autoDetectButton.AddToClassList("yucp-button");
                autoDetectButton.AddToClassList("yucp-button-action");
                autoDetectButton.style.marginTop = 8;
                section.Add(autoDetectButton);
            }
            else if (profile.foldersToExport.Count == 0)
            {
                var hintBox = new VisualElement();
                hintBox.AddToClassList("yucp-help-box");
                hintBox.style.marginTop = 8;
                var hintText = new Label("Add export folders first, then use 'Auto-Detect Used' to find dependencies");
                hintText.AddToClassList("yucp-help-box-text");
                hintBox.Add(hintText);
                section.Add(hintBox);
            }
            
            return section;
        }

        private VisualElement CreateDependencyCard(PackageDependency dep, int index, ExportProfile profile)
        {
            var card = new VisualElement();
            card.AddToClassList("yucp-dependency-card");
            card.style.backgroundColor = new Color(0.1f, 0.1f, 0.1f, 1f);
            card.style.marginBottom = 8;
            card.style.paddingTop = 8;
            card.style.paddingBottom = 8;
            card.style.paddingLeft = 12;
            card.style.paddingRight = 12;
            card.style.borderLeftWidth = 3;
            card.style.borderLeftColor = dep.enabled ? new Color(0.21f, 0.75f, 0.73f, 1f) : new Color(0.3f, 0.3f, 0.3f, 1f);
            card.style.width = Length.Percent(100);
            card.style.maxWidth = Length.Percent(100);
            card.style.minWidth = 0;
            
            // Header row
            var headerRow = new VisualElement();
            headerRow.AddToClassList("yucp-dependency-card-header");
            headerRow.style.flexDirection = FlexDirection.Row;
            headerRow.style.alignItems = Align.Center;
            headerRow.style.marginBottom = dep.enabled ? 8 : 0;
            headerRow.style.width = Length.Percent(100);
            headerRow.style.maxWidth = Length.Percent(100);
            headerRow.style.minWidth = 0;
            
            // Enable checkbox
            var enableToggle = new Toggle { value = dep.enabled };
            enableToggle.AddToClassList("yucp-toggle");
            enableToggle.style.marginRight = 8;
            enableToggle.style.flexShrink = 0;
            enableToggle.RegisterValueChangedCallback(evt =>
            {
                dep.enabled = evt.newValue;
                EditorUtility.SetDirty(profile);
                UpdateProfileDetails();
            });
            headerRow.Add(enableToggle);
            
            // Package name label
            string label = dep.isVpmDependency ? "[VPM] " : "";
            label += string.IsNullOrEmpty(dep.displayName) ? dep.packageName : dep.displayName;
            
            var nameLabel = new Label(label);
            nameLabel.AddToClassList("yucp-label");
            nameLabel.AddToClassList("yucp-dependency-card-name");
            nameLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            nameLabel.style.flexGrow = 1;
            nameLabel.style.minWidth = 0;
            headerRow.Add(nameLabel);
            
            // Remove button
            var removeButton = new Button(() => 
            {
                profile.dependencies.RemoveAt(index);
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                UpdateProfileDetails();
            }) { text = "×" };
            removeButton.AddToClassList("yucp-button");
            removeButton.AddToClassList("yucp-button-danger");
            removeButton.AddToClassList("yucp-button-small");
            removeButton.style.width = 25;
            removeButton.style.flexShrink = 0;
            headerRow.Add(removeButton);
            
            card.Add(headerRow);
            
            // Warning box for problematic dependencies
            string packageName = dep.packageName ?? "";
            string displayName = dep.displayName ?? "";
            string combinedName = (packageName + " " + displayName).ToLower();
            
            // Check for "temp" or "temporary" but NOT "template"
            bool hasTempWarning = (combinedName.Contains(" temp ") || combinedName.StartsWith("temp ") || combinedName.EndsWith(" temp") || 
                                   combinedName == "temp" || combinedName.Contains("temporary")) && 
                                   !combinedName.Contains("template");
            bool hasDevToolsWarning = combinedName.Contains("yucp dev tools") || combinedName.Contains("yucp.devtools");
            
            if (hasTempWarning || hasDevToolsWarning)
            {
                string warningMessage = "";
                if (hasTempWarning && hasDevToolsWarning)
                {
                    warningMessage = "'Temp' or 'Temporary' folders are usually unique to your project and are not recommended to be included for the general public.\n\n" +
                                   "'YUCP Dev tools' is for creators and is not recommended to be included for the general public.";
                }
                else if (hasTempWarning)
                {
                    warningMessage = "'Temp' or 'Temporary' folders are usually unique to your project and are not recommended to be included for the general public.";
                }
                else if (hasDevToolsWarning)
                {
                    warningMessage = "'YUCP Dev tools' is for creators and is not recommended to be included for the general public.";
                }
                
                var warningBox = new VisualElement();
                warningBox.name = "dependency-warning-box";
                warningBox.AddToClassList("yucp-help-box");
                warningBox.style.marginTop = 8;
                warningBox.style.marginBottom = 8;
                warningBox.style.backgroundColor = new Color(0.7f, 0.65f, 0.1f, 0.3f); // Yellow warning color (more yellow, less green)
                warningBox.style.borderLeftWidth = 3;
                warningBox.style.borderLeftColor = new Color(0.9f, 0.85f, 0.2f, 1f); // Yellow border
                
                var warningText = new Label(warningMessage);
                warningText.AddToClassList("yucp-help-box-text");
                warningText.style.color = new StyleColor(new Color(0.9f, 0.9f, 0.9f, 1f)); // Light gray/white text to match design
                warningBox.Add(warningText);
                
                card.Add(warningBox);
            }
            
            // Content area - only show if enabled
            if (dep.enabled)
            {
                // Package Name field
                var packageNameRow = CreateFormRow("Package Name", tooltip: "Unique identifier for the package");
                var packageNameField = new TextField { value = dep.packageName };
                packageNameField.AddToClassList("yucp-input");
                packageNameField.AddToClassList("yucp-form-field");
                packageNameField.RegisterValueChangedCallback(evt =>
                {
                    dep.packageName = evt.newValue;
                    EditorUtility.SetDirty(profile);
                });
                packageNameRow.Add(packageNameField);
                card.Add(packageNameRow);
                
                // Version field
                var versionRow = CreateFormRow("Version", tooltip: "Package version");
                var versionField = new TextField { value = dep.packageVersion };
                versionField.AddToClassList("yucp-input");
                versionField.AddToClassList("yucp-form-field");
                versionField.RegisterValueChangedCallback(evt =>
                {
                    dep.packageVersion = evt.newValue;
                    EditorUtility.SetDirty(profile);
                });
                versionRow.Add(versionField);
                card.Add(versionRow);
                
                // Display Name field
                var displayNameRow = CreateFormRow("Display Name", tooltip: "Human-readable name");
                var displayNameField = new TextField { value = dep.displayName };
                displayNameField.AddToClassList("yucp-input");
                displayNameField.AddToClassList("yucp-form-field");
                displayNameField.RegisterValueChangedCallback(evt =>
                {
                    dep.displayName = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    UpdateProfileDetails(); // Refresh to update card title
                });
                displayNameRow.Add(displayNameField);
                card.Add(displayNameRow);
                
                // Export Mode dropdown
                var exportModeRow = CreateFormRow("Export Mode", tooltip: "How this dependency should be handled");
                var exportModeField = new EnumField(dep.exportMode);
                exportModeField.AddToClassList("yucp-form-field");
                exportModeField.RegisterValueChangedCallback(evt =>
                {
                    dep.exportMode = (DependencyExportMode)evt.newValue;
                    EditorUtility.SetDirty(profile);
                });
                exportModeRow.Add(exportModeField);
                card.Add(exportModeRow);
                
                // VPM Package toggle
                var vpmToggle = new Toggle("VPM Package") { value = dep.isVpmDependency };
                vpmToggle.AddToClassList("yucp-toggle");
                vpmToggle.tooltip = "Is this a VRChat Package Manager dependency?";
                vpmToggle.RegisterValueChangedCallback(evt =>
                {
                    dep.isVpmDependency = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    UpdateProfileDetails(); // Refresh to update card title
                });
                card.Add(vpmToggle);
            }
            
            return card;
        }

        private VisualElement CreateObfuscationSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var title = new Label("Assembly Obfuscation");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var enableToggle = new Toggle("Enable Obfuscation") { value = profile.enableObfuscation };
            enableToggle.AddToClassList("yucp-toggle");
            enableToggle.tooltip = "Protect compiled assemblies using ConfuserEx";
            enableToggle.RegisterValueChangedCallback(evt =>
            {
                if (profile != null)
                {
                    Undo.RecordObject(profile, "Change Enable Obfuscation");
                    profile.enableObfuscation = evt.newValue;
                    EditorUtility.SetDirty(profile);
                    UpdateProfileDetails(); // Refresh to show/hide obfuscation options
                }
            });
            section.Add(enableToggle);
            
            if (profile.enableObfuscation)
            {
                // Protection Level
                var presetRow = CreateFormRow("Protection Level", tooltip: "Choose how aggressively to obfuscate");
                var presetField = new EnumField(profile.obfuscationPreset);
                presetField.AddToClassList("yucp-form-field");
                presetField.RegisterValueChangedCallback(evt =>
                {
                    if (profile != null)
                    {
                        Undo.RecordObject(profile, "Change Obfuscation Preset");
                        profile.obfuscationPreset = (ConfuserExPreset)evt.newValue;
                        EditorUtility.SetDirty(profile);
                    }
                });
                presetRow.Add(presetField);
                section.Add(presetRow);
                
                // Strip Debug Symbols
                var stripToggle = new Toggle("Strip Debug Symbols") { value = profile.stripDebugSymbols };
                stripToggle.AddToClassList("yucp-toggle");
                stripToggle.RegisterValueChangedCallback(evt =>
                {
                    if (profile != null)
                    {
                        Undo.RecordObject(profile, "Change Strip Debug Symbols");
                        profile.stripDebugSymbols = evt.newValue;
                        EditorUtility.SetDirty(profile);
                    }
                });
                section.Add(stripToggle);
                
                // Scan Assemblies button
                var scanButton = new Button(() => ScanAllAssemblies(profile)) { text = "Scan Assemblies" };
                scanButton.AddToClassList("yucp-button");
                scanButton.AddToClassList("yucp-button-action");
                scanButton.style.marginTop = 8;
                section.Add(scanButton);
                
                // Assembly selection list
                if (profile.assembliesToObfuscate.Count > 0)
                {
                    int enabledCount = profile.assembliesToObfuscate.Count(a => a.enabled);
                    var countLabel = new Label($"Found {profile.assembliesToObfuscate.Count} assemblies ({enabledCount} selected)");
                    countLabel.AddToClassList("yucp-label-secondary");
                    countLabel.style.marginTop = 8;
                    section.Add(countLabel);
                    
                    var scrollView = new ScrollView();
                    scrollView.style.maxHeight = 200;
                    scrollView.style.marginTop = 8;
                    
                    for (int i = 0; i < profile.assembliesToObfuscate.Count; i++)
                    {
                        int index = i;
                        var assembly = profile.assembliesToObfuscate[i];
                        
                        var assemblyItem = new VisualElement();
                        assemblyItem.AddToClassList("yucp-folder-item");
                        
                        var checkbox = new Toggle { value = assembly.enabled };
                        checkbox.AddToClassList("yucp-toggle");
                        checkbox.RegisterValueChangedCallback(evt =>
                        {
                            if (profile != null && index < profile.assembliesToObfuscate.Count)
                            {
                                Undo.RecordObject(profile, "Change Assembly Obfuscation");
                                profile.assembliesToObfuscate[index].enabled = evt.newValue;
                                EditorUtility.SetDirty(profile);
                                UpdateProfileDetails();
                            }
                        });
                        assemblyItem.Add(checkbox);
                        
                        var assemblyLabel = new Label(assembly.assemblyName);
                        assemblyLabel.AddToClassList("yucp-folder-item-path");
                        assemblyLabel.style.marginLeft = 8;
                        assemblyItem.Add(assemblyLabel);
                        
                        scrollView.Add(assemblyItem);
                    }
                    
                    section.Add(scrollView);
                }
            }
            
            return section;
        }

        private VisualElement _signingSectionElement;

        private VisualElement CreatePackageSigningSection(ExportProfile profile)
        {
            var signingTab = new YUCP.DevTools.Editor.PackageSigning.UI.PackageSigningTab(profile);
            _signingSectionElement = signingTab.CreateUI();
            return _signingSectionElement;
        }

        /// <summary>
        /// Refresh the signing section when certificate changes
        /// </summary>
        public void RefreshSigningSection()
        {
            // If a profile is selected, refresh the entire details view to ensure signing section updates
            if (selectedProfile != null)
            {
                UpdateProfileDetails();
            }
            // If no profile selected but signing section exists, just refresh it
            else if (_signingSectionElement != null)
            {
                var parent = _signingSectionElement.parent;
                if (parent != null)
                {
                    var index = parent.IndexOf(_signingSectionElement);
                    _signingSectionElement.RemoveFromHierarchy();
                    
                    var newSigningSection = CreatePackageSigningSection(selectedProfile);
                    parent.Insert(index, newSigningSection);
                }
            }
        }
        
        private VisualElement CreateQuickActionsSection(ExportProfile profile)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var header = CreateCollapsibleHeader("Quick Actions", 
                () => showQuickActions, 
                (value) => { showQuickActions = value; }, 
                () => UpdateProfileDetails());
            section.Add(header);
            
            if (!showQuickActions)
            {
                return section;
            }
            
            var actionsContainer = new VisualElement();
            actionsContainer.style.flexDirection = FlexDirection.Row;
            actionsContainer.style.marginTop = 8;
            
            var inspectorButton = new Button(() => 
            {
                Selection.activeObject = profile;
                EditorGUIUtility.PingObject(profile);
            }) 
            { text = "Open in Inspector" };
            inspectorButton.AddToClassList("yucp-button");
            inspectorButton.AddToClassList("yucp-button-action");
            inspectorButton.style.flexGrow = 1;
            actionsContainer.Add(inspectorButton);
            
            var saveButton = new Button(() => 
            {
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
            }) 
            { text = "Save Changes" };
            saveButton.AddToClassList("yucp-button");
            saveButton.AddToClassList("yucp-button-action");
            saveButton.style.flexGrow = 1;
            actionsContainer.Add(saveButton);
            
            section.Add(actionsContainer);
            
            return section;
        }

        private VisualElement CreateFormRow(string labelText, string tooltip = "")
        {
            var row = new VisualElement();
            row.AddToClassList("yucp-form-row");
            
            var label = new Label(labelText);
            label.AddToClassList("yucp-form-label");
            if (!string.IsNullOrEmpty(tooltip))
            {
                label.tooltip = tooltip;
            }
            row.Add(label);
            
            return row;
        }

        private VisualElement CreateCollapsibleHeader(string title, Func<bool> getExpanded, Action<bool> setExpanded, Action onToggle)
        {
            var header = new VisualElement();
            header.AddToClassList("yucp-inspector-header");
            
            var titleLabel = new Label(title);
            titleLabel.AddToClassList("yucp-section-title");
            header.Add(titleLabel);
            
            var toggleButton = new Button();
            
            void UpdateButtonText()
            {
                toggleButton.text = getExpanded() ? "▼" : "▶";
            }
            
            toggleButton.clicked += () =>
            {
                bool current = getExpanded();
                setExpanded(!current);
                UpdateButtonText();
                onToggle?.Invoke();
            };
            
            UpdateButtonText();
            toggleButton.AddToClassList("yucp-button");
            toggleButton.AddToClassList("yucp-button-small");
            header.Add(toggleButton);
            
            return header;
        }

        private void UpdateBottomBar()
        {
            // Update multi-select info
            if (selectedProfileIndices.Count > 1)
            {
                _multiSelectInfo.style.display = DisplayStyle.Flex;
                var textLabel = _multiSelectInfo.Q<Label>("multiSelectText");
                if (textLabel != null)
                {
                    textLabel.text = $"{selectedProfileIndices.Count} profiles selected";
                }
            }
            else
            {
                _multiSelectInfo.style.display = DisplayStyle.None;
            }
            
            // Update export selected button
            _exportSelectedButton.SetEnabled(selectedProfileIndices.Count > 0 && !isExporting);
            if (selectedProfileIndices.Count == 1)
            {
                _exportSelectedButton.text = "Export Selected Profile";
            }
            else if (selectedProfileIndices.Count > 1)
            {
                _exportSelectedButton.text = $"Export Selected Profiles ({selectedProfileIndices.Count})";
            }
            else
            {
                _exportSelectedButton.text = "Export Selected";
            }
            
            // Update export all button
            _exportAllButton.SetEnabled(allProfiles.Count > 0 && !isExporting);
        }

        private void UpdateProgress(float progress, string status)
        {
            currentProgress = progress;
            currentStatus = status;
            
            _progressFill.style.width = Length.Percent(progress * 100);
            _progressText.text = $"{(progress * 100):F0}% - {status}";
        }

        // Helper methods
        private string GetProfileDisplayName(ExportProfile profile)
        {
            return string.IsNullOrEmpty(profile.packageName) ? profile.name : profile.packageName;
        }

        private void CheckDelayedRename()
        {
            if (pendingRenameProfile != null && !string.IsNullOrEmpty(pendingRenamePackageName))
            {
                double timeSinceChange = EditorApplication.timeSinceStartup - lastPackageNameChangeTime;
                
                if (timeSinceChange >= RENAME_DELAY_SECONDS)
                {
                    PerformDelayedRename(pendingRenameProfile, pendingRenamePackageName);
                    pendingRenameProfile = null;
                    pendingRenamePackageName = "";
                }
            }
        }

        private void PerformDelayedRename(ExportProfile profile, string newPackageName)
        {
            if (profile == null) return;
            
            string currentPath = AssetDatabase.GetAssetPath(profile);
            if (string.IsNullOrEmpty(currentPath)) return;
            
            string directory = Path.GetDirectoryName(currentPath);
            string extension = Path.GetExtension(currentPath);
            string newFileName = SanitizeFileName(newPackageName) + extension;
            string newPath = Path.Combine(directory, newFileName).Replace('\\', '/');
            
            if (newPath != currentPath)
            {
                string result = AssetDatabase.MoveAsset(currentPath, newPath);
                if (string.IsNullOrEmpty(result))
                {
                    profile.profileName = profile.packageName;
                    EditorUtility.SetDirty(profile);
                    AssetDatabase.SaveAssets();
                    
                    LoadProfiles();
                    
                    var updatedProfile = AssetDatabase.LoadAssetAtPath<ExportProfile>(newPath);
                    if (updatedProfile != null)
                    {
                        selectedProfile = updatedProfile;
                        UpdateProfileList();
                        UpdateProfileDetails();
                    }
                }
                else
                {
                    Debug.LogWarning($"[Package Exporter] Failed to rename asset: {result}");
                }
            }
        }

        private string SanitizeFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return "NewPackage";
            
            char[] invalidChars = Path.GetInvalidFileNameChars();
            foreach (char c in invalidChars)
            {
                fileName = fileName.Replace(c, '_');
            }
            
            return fileName;
        }

        private void BrowseForIcon(ExportProfile profile)
        {
            string iconPath = EditorUtility.OpenFilePanel("Select Package Icon", "", "png,jpg,jpeg,gif");
            if (!string.IsNullOrEmpty(iconPath))
            {
                string projectPath = "Assets/YUCP/ExportProfiles/Icons/";
                if (!AssetDatabase.IsValidFolder("Assets/YUCP/ExportProfiles/Icons"))
                {
                    if (!AssetDatabase.IsValidFolder("Assets/YUCP"))
                        AssetDatabase.CreateFolder("Assets", "YUCP");
                    if (!AssetDatabase.IsValidFolder("Assets/YUCP/ExportProfiles"))
                        AssetDatabase.CreateFolder("Assets/YUCP", "ExportProfiles");
                    AssetDatabase.CreateFolder("Assets/YUCP/ExportProfiles", "Icons");
                }
                
                string fileName = Path.GetFileName(iconPath);
                string targetPath = projectPath + fileName;
                
                File.Copy(iconPath, targetPath, true);
                AssetDatabase.ImportAsset(targetPath);
                AssetDatabase.Refresh();
                
                profile.icon = AssetDatabase.LoadAssetAtPath<Texture2D>(targetPath);
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                
                UpdateProfileDetails();
            }
        }

        private void BrowseForProductLinkIcon(ExportProfile profile, ProductLink link, Image iconImage)
        {
            string iconPath = EditorUtility.OpenFilePanel("Select Custom Icon for Link", "", "png,jpg,jpeg,gif");
            if (!string.IsNullOrEmpty(iconPath))
            {
                string projectPath = "Assets/YUCP/ExportProfiles/LinkIcons/";
                if (!AssetDatabase.IsValidFolder("Assets/YUCP/ExportProfiles/LinkIcons"))
                {
                    if (!AssetDatabase.IsValidFolder("Assets/YUCP"))
                        AssetDatabase.CreateFolder("Assets", "YUCP");
                    if (!AssetDatabase.IsValidFolder("Assets/YUCP/ExportProfiles"))
                        AssetDatabase.CreateFolder("Assets/YUCP", "ExportProfiles");
                    AssetDatabase.CreateFolder("Assets/YUCP/ExportProfiles", "LinkIcons");
                }
                
                string fileName = Path.GetFileName(iconPath);
                string targetPath = projectPath + fileName;
                
                File.Copy(iconPath, targetPath, true);
                AssetDatabase.ImportAsset(targetPath);
                AssetDatabase.Refresh();
                
                Undo.RecordObject(profile, "Set Custom Link Icon");
                link.customIcon = AssetDatabase.LoadAssetAtPath<Texture2D>(targetPath);
                iconImage.image = link.customIcon;
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
            }
        }

        private void BrowseForPath(ExportProfile profile)
        {
            string selectedPath = EditorUtility.OpenFolderPanel("Select Export Folder", "", "");
            if (!string.IsNullOrEmpty(selectedPath))
            {
                Undo.RecordObject(profile, "Change Export Path");
                profile.exportPath = selectedPath;
                EditorUtility.SetDirty(profile);
                UpdateProfileDetails();
            }
        }

        private void AddFolder(ExportProfile profile)
        {
            string selectedFolder = EditorUtility.OpenFolderPanel("Select Folder to Export", Application.dataPath, "");
            if (!string.IsNullOrEmpty(selectedFolder))
            {
                string relativePath = GetRelativePath(selectedFolder);
                Undo.RecordObject(profile, "Add Export Folder");
                profile.foldersToExport.Add(relativePath);
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                UpdateProfileDetails();
            }
        }

        private void RemoveFolder(ExportProfile profile, int index)
        {
            if (index >= 0 && index < profile.foldersToExport.Count)
            {
                Undo.RecordObject(profile, "Remove Export Folder");
                profile.foldersToExport.RemoveAt(index);
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                UpdateProfileDetails();
            }
        }

        private string GetRelativePath(string absolutePath)
        {
            string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            
            if (absolutePath.StartsWith(projectPath))
            {
                string relative = absolutePath.Substring(projectPath.Length);
                if (relative.StartsWith("\\") || relative.StartsWith("/"))
                {
                    relative = relative.Substring(1);
                }
                return relative;
            }
            
            return absolutePath;
        }

        private void AddDependency(ExportProfile profile)
        {
            var newDep = new PackageDependency("com.example.package", "1.0.0", "Example Package", false);
            Undo.RecordObject(profile, "Add Dependency");
            profile.dependencies.Add(newDep);
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            UpdateProfileDetails();
        }
        

        // Profile CRUD operations
        private void LoadProfiles()
        {
            allProfiles.Clear();
            
            string[] guids = AssetDatabase.FindAssets("t:ExportProfile");
            
            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var profile = AssetDatabase.LoadAssetAtPath<ExportProfile>(path);
                
                if (profile != null)
                {
                    allProfiles.Add(profile);
                }
            }
            
            // Apply custom order if available, otherwise sort alphabetically
            allProfiles = ApplyCustomOrder(allProfiles);
            
            // Reselect if we had a selection
            if (selectedProfile != null)
            {
                int index = allProfiles.IndexOf(selectedProfile);
                if (index < 0)
                {
                    selectedProfile = null;
                    selectedProfileIndices.Clear();
                }
            }
        }
        
        /// <summary>
        /// Applies custom order from EditorPrefs, or falls back to alphabetical sorting
        /// </summary>
        private List<ExportProfile> ApplyCustomOrder(List<ExportProfile> profiles)
        {
            string orderJson = EditorPrefs.GetString(PackageOrderKey, "");
            
            if (string.IsNullOrEmpty(orderJson))
            {
                // No custom order, sort alphabetically
                return profiles.OrderBy(p => p.packageName).ToList();
            }
            
            try
            {
                // Parse the stored order (list of GUIDs)
                var orderedGuids = JsonUtility.FromJson<SerializableStringList>(orderJson);
                if (orderedGuids == null || orderedGuids.items == null || orderedGuids.items.Count == 0)
                {
                    return profiles.OrderBy(p => p.packageName).ToList();
                }
                
                // Create a dictionary for quick lookup
                var profileDict = profiles.ToDictionary(p => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p)), p => p);
                
                // Build ordered list
                var ordered = new List<ExportProfile>();
                var usedGuids = new HashSet<string>();
                
                // Add profiles in stored order
                foreach (string guid in orderedGuids.items)
                {
                    if (profileDict.TryGetValue(guid, out var profile))
                    {
                        ordered.Add(profile);
                        usedGuids.Add(guid);
                    }
                }
                
                // Add any new profiles that weren't in the stored order (alphabetically)
                var newProfiles = profiles.Where(p => 
                {
                    string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p));
                    return !usedGuids.Contains(guid);
                }).OrderBy(p => p.packageName).ToList();
                
                ordered.AddRange(newProfiles);
                
                return ordered;
            }
            catch
            {
                // If parsing fails, fall back to alphabetical
                return profiles.OrderBy(p => p.packageName).ToList();
            }
        }
        
        /// <summary>
        /// Saves the current profile order to EditorPrefs
        /// </summary>
        private void SaveCustomOrder()
        {
            var guids = allProfiles.Select(p => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p))).ToList();
            var serializable = new SerializableStringList { items = guids };
            string json = JsonUtility.ToJson(serializable);
            EditorPrefs.SetString(PackageOrderKey, json);
            
            // Also save unified order
            SaveUnifiedOrder();
        }
        
        /// <summary>
        /// Migrates existing order and folders to unified order format
        /// </summary>
        private void MigrateToUnifiedOrder()
        {
            // Check if already migrated
            if (EditorPrefs.GetBool(UnifiedOrderMigratedKey, false))
                return;
            
            unifiedOrder.Clear();
            
            // Load existing order
            string orderJson = EditorPrefs.GetString(PackageOrderKey, "");
            List<string> orderedGuids = new List<string>();
            
            if (!string.IsNullOrEmpty(orderJson))
            {
                try
                {
                    var orderedGuidsObj = JsonUtility.FromJson<SerializableStringList>(orderJson);
                    if (orderedGuidsObj != null && orderedGuidsObj.items != null)
                    {
                        orderedGuids = orderedGuidsObj.items;
                    }
                }
                catch
                {
                    // If parsing fails, start fresh
                }
            }
            
            // Build unified order from existing data
            // First, add folders in their current order (alphabetically sorted)
            var folders = new List<string>(projectFolders);
            folders.Sort();
            
            foreach (var folderName in folders)
            {
                unifiedOrder.Add(new UnifiedOrderItem { isFolder = true, identifier = folderName });
            }
            
            // Then add profiles in their stored order (only those not in folders)
            foreach (string guid in orderedGuids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var profile = AssetDatabase.LoadAssetAtPath<ExportProfile>(path);
                if (profile != null && string.IsNullOrEmpty(profile.folderName))
                {
                    unifiedOrder.Add(new UnifiedOrderItem { isFolder = false, identifier = guid });
                }
            }
            
            // Add any new profiles not in order (alphabetically)
            var allProfileGuids = allProfiles.Select(p => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p))).ToHashSet();
            var orderedProfileGuids = orderedGuids.ToHashSet();
            var newProfiles = allProfiles.Where(p =>
            {
                string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p));
                return !orderedProfileGuids.Contains(guid) && string.IsNullOrEmpty(p.folderName);
            }).OrderBy(p => p.packageName).ToList();
            
            foreach (var profile in newProfiles)
            {
                string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profile));
                unifiedOrder.Add(new UnifiedOrderItem { isFolder = false, identifier = guid });
            }
            
            // Save unified order
            SaveUnifiedOrder();
            
            // Mark as migrated
            EditorPrefs.SetBool(UnifiedOrderMigratedKey, true);
        }
        
        /// <summary>
        /// Loads unified order from EditorPrefs
        /// </summary>
        private void LoadUnifiedOrder()
        {
            string orderJson = EditorPrefs.GetString(UnifiedOrderKey, "");
            
            if (string.IsNullOrEmpty(orderJson))
            {
                // If no unified order exists, build it from current state
                BuildUnifiedOrderFromCurrentState();
                return;
            }
            
            try
            {
                var orderList = JsonUtility.FromJson<UnifiedOrderList>(orderJson);
                if (orderList != null && orderList.items != null)
                {
                    unifiedOrder = orderList.items;
                    // Validate and clean up order (remove invalid items)
                    ValidateAndCleanUnifiedOrder();
                }
                else
                {
                    BuildUnifiedOrderFromCurrentState();
                }
            }
            catch
            {
                // If parsing fails, rebuild from current state
                BuildUnifiedOrderFromCurrentState();
            }
        }
        
        /// <summary>
        /// Builds unified order from current profiles and folders state
        /// </summary>
        private void BuildUnifiedOrderFromCurrentState()
        {
            unifiedOrder.Clear();
            
            // Add folders first (sorted)
            var folders = new List<string>(projectFolders);
            folders.Sort();
            foreach (var folderName in folders)
            {
                unifiedOrder.Add(new UnifiedOrderItem { isFolder = true, identifier = folderName });
            }
            
            // Add uncategorized profiles (sorted alphabetically)
            var uncategorizedProfiles = allProfiles
                .Where(p => string.IsNullOrEmpty(p.folderName) || !projectFolders.Contains(p.folderName))
                .OrderBy(p => p.packageName)
                .ToList();
            
            foreach (var profile in uncategorizedProfiles)
            {
                string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profile));
                unifiedOrder.Add(new UnifiedOrderItem { isFolder = false, identifier = guid });
            }
        }
        
        /// <summary>
        /// Validates unified order and removes invalid items
        /// </summary>
        private void ValidateAndCleanUnifiedOrder()
        {
            var validOrder = new List<UnifiedOrderItem>();
            var seenFolders = new HashSet<string>();
            var seenProfiles = new HashSet<string>();
            
            // Get all valid folders and profiles
            var validFolders = projectFolders.ToHashSet();
            var validProfileGuids = allProfiles.ToDictionary(
                p => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(p)),
                p => p
            );
            
            foreach (var item in unifiedOrder)
            {
                if (item.isFolder)
                {
                    // Validate folder exists
                    if (validFolders.Contains(item.identifier) && !seenFolders.Contains(item.identifier))
                    {
                        validOrder.Add(item);
                        seenFolders.Add(item.identifier);
                    }
                }
                else
                {
                    // Validate profile exists and is not in a folder
                    if (validProfileGuids.TryGetValue(item.identifier, out var profile))
                    {
                        // Only add if not in a folder (folders handle their own profiles)
                        if (string.IsNullOrEmpty(profile.folderName) && !seenProfiles.Contains(item.identifier))
                        {
                            validOrder.Add(item);
                            seenProfiles.Add(item.identifier);
                        }
                    }
                }
            }
            
            // Add any missing folders
            foreach (var folder in validFolders)
            {
                if (!seenFolders.Contains(folder))
                {
                    validOrder.Add(new UnifiedOrderItem { isFolder = true, identifier = folder });
                }
            }
            
            // Add any missing uncategorized profiles
            foreach (var profile in allProfiles)
            {
                if (string.IsNullOrEmpty(profile.folderName))
                {
                    string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profile));
                    if (!seenProfiles.Contains(guid))
                    {
                        validOrder.Add(new UnifiedOrderItem { isFolder = false, identifier = guid });
                    }
                }
            }
            
            unifiedOrder = validOrder;
        }
        
        /// <summary>
        /// Saves unified order to EditorPrefs
        /// </summary>
        private void SaveUnifiedOrder()
        {
            var orderList = new UnifiedOrderList { items = unifiedOrder };
            string json = JsonUtility.ToJson(orderList);
            EditorPrefs.SetString(UnifiedOrderKey, json);
        }
        
        /// <summary>
        /// Helper class for JSON serialization of string lists
        /// </summary>
        [Serializable]
        private class SerializableStringList
        {
            public List<string> items = new List<string>();
        }
        
        /// <summary>
        /// Represents an item in the unified order (either a profile or a folder)
        /// </summary>
        [Serializable]
        private class UnifiedOrderItem
        {
            public bool isFolder;
            public string identifier; // GUID for profiles, folder name for folders
        }
        
        /// <summary>
        /// Helper class for JSON serialization of unified order
        /// </summary>
        [Serializable]
        private class UnifiedOrderList
        {
            public List<UnifiedOrderItem> items = new List<UnifiedOrderItem>();
        }

        private void RefreshProfiles()
        {
            LoadProfiles();
            UpdateProfileList();
            UpdateProfileDetails();
            UpdateBottomBar();
        }

        private void CreateNewProfile()
        {
            string profilesDir = "Assets/YUCP/ExportProfiles";
            if (!Directory.Exists(profilesDir))
            {
                Directory.CreateDirectory(profilesDir);
            }
            
            var profile = ScriptableObject.CreateInstance<ExportProfile>();
            profile.packageName = "NewPackage";
            profile.profileName = profile.packageName;
            profile.version = "1.0.0";
            
            string assetPath = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(profilesDir, "NewExportProfile.asset"));
            
            AssetDatabase.CreateAsset(profile, assetPath);
            AssetDatabase.SaveAssets();
            
            // Update profile count for milestones
            try
            {
                System.Type milestoneTrackerType = null;
                
                // Try to find the type by searching through all loaded assemblies
                foreach (var assembly in System.AppDomain.CurrentDomain.GetAssemblies())
                {
                    milestoneTrackerType = assembly.GetType("YUCP.Components.Editor.SupportBanner.MilestoneTracker");
                    if (milestoneTrackerType != null)
                        break;
                }
                
                if (milestoneTrackerType != null)
                {
                    var updateMethod = milestoneTrackerType.GetMethod("UpdateProfileCountFromAssets", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                    updateMethod?.Invoke(null, null);
                }
            }
            catch
            {
                // Silently fail if milestone tracker is not available
            }
            
            LoadProfiles();
            
            // Add new profile to unified order if not in a folder
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(profile));
            if (string.IsNullOrEmpty(profile.folderName))
            {
                if (!unifiedOrder.Any(item => !item.isFolder && item.identifier == guid))
                {
                    unifiedOrder.Add(new UnifiedOrderItem { isFolder = false, identifier = guid });
                    SaveUnifiedOrder();
                }
            }
            
            selectedProfile = profile;
            int index = allProfiles.IndexOf(profile);
            selectedProfileIndices.Clear();
            selectedProfileIndices.Add(index);
            lastClickedProfileIndex = index;
            
            UpdateProfileList();
            UpdateProfileDetails();
            UpdateBottomBar();
            
            EditorGUIUtility.PingObject(profile);
        }

        private void CloneProfile(ExportProfile source)
        {
            if (source == null)
                return;
            
            var clone = Instantiate(source);
            clone.name = source.name + " (Clone)";
            
            string profilesDir = "Assets/YUCP/ExportProfiles";
            if (!Directory.Exists(profilesDir))
            {
                Directory.CreateDirectory(profilesDir);
            }
            
            string assetPath = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(profilesDir, clone.name + ".asset"));
            
            AssetDatabase.CreateAsset(clone, assetPath);
            AssetDatabase.SaveAssets();
            
            LoadProfiles();
            
            // Add cloned profile to unified order if not in a folder
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(clone));
            if (string.IsNullOrEmpty(clone.folderName))
            {
                if (!unifiedOrder.Any(item => !item.isFolder && item.identifier == guid))
                {
                    // Add after the source profile if possible
                    string sourceGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(source));
                    int insertIndex = -1;
                    for (int i = 0; i < unifiedOrder.Count; i++)
                    {
                        if (!unifiedOrder[i].isFolder && unifiedOrder[i].identifier == sourceGuid)
                        {
                            insertIndex = i + 1;
                            break;
                        }
                    }
                    
                    var newItem = new UnifiedOrderItem { isFolder = false, identifier = guid };
                    if (insertIndex >= 0 && insertIndex <= unifiedOrder.Count)
                    {
                        unifiedOrder.Insert(insertIndex, newItem);
                    }
                    else
                    {
                        unifiedOrder.Add(newItem);
                    }
                    SaveUnifiedOrder();
                }
            }
            
            selectedProfile = clone;
            int index = allProfiles.IndexOf(clone);
            selectedProfileIndices.Clear();
            selectedProfileIndices.Add(index);
            lastClickedProfileIndex = index;
            
            UpdateProfileList();
            UpdateProfileDetails();
            UpdateBottomBar();
        }

        private void DeleteProfile(ExportProfile profile)
        {
            if (profile == null)
                return;
            
            bool confirm = EditorUtility.DisplayDialog(
                "Delete Export Profile",
                $"Are you sure you want to delete the profile '{profile.name}'?\n\nThis cannot be undone.",
                "Delete",
                "Cancel"
            );
            
            if (!confirm)
                return;
            
            string assetPath = AssetDatabase.GetAssetPath(profile);
            string guid = AssetDatabase.AssetPathToGUID(assetPath);
            
            // Remove from unified order
            unifiedOrder.RemoveAll(item => !item.isFolder && item.identifier == guid);
            
            if (selectedProfile == profile)
            {
                selectedProfile = null;
                selectedProfileIndices.Clear();
            }
            
            AssetDatabase.DeleteAsset(assetPath);
            AssetDatabase.SaveAssets();
            
            SaveUnifiedOrder();
            
            // Update profile count for milestones
            try
            {
                System.Type milestoneTrackerType = null;
                
                // Try to find the type by searching through all loaded assemblies
                foreach (var assembly in System.AppDomain.CurrentDomain.GetAssemblies())
                {
                    milestoneTrackerType = assembly.GetType("YUCP.Components.Editor.SupportBanner.MilestoneTracker");
                    if (milestoneTrackerType != null)
                        break;
                }
                
                if (milestoneTrackerType != null)
                {
                    var updateMethod = milestoneTrackerType.GetMethod("UpdateProfileCountFromAssets", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                    updateMethod?.Invoke(null, null);
                }
            }
            catch
            {
                // Silently fail if milestone tracker is not available
            }
            
            LoadProfiles();
            UpdateProfileList();
            UpdateProfileDetails();
            UpdateBottomBar();
        }

        // Export operations
        private void ExportSelectedProfiles()
        {
            if (selectedProfileIndices.Count == 0)
            {
                EditorUtility.DisplayDialog("No Selection", "No profiles are selected.", "OK");
                return;
            }
            
            if (selectedProfileIndices.Count == 1)
            {
                ExportProfile(selectedProfile);
            }
            else
            {
                var selectedProfiles = selectedProfileIndices.OrderBy(i => i).Select(i => allProfiles[i]).ToList();
                ExportAllProfiles(selectedProfiles);
            }
        }

        private void ExportProfile(ExportProfile profile)
        {
            if (profile == null)
                return;
            
            if (!profile.Validate(out string errorMessage))
            {
                EditorUtility.DisplayDialog("Validation Error", errorMessage, "OK");
                return;
            }
            
            string foldersList = profile.foldersToExport.Count > 0 
                ? string.Join("\n", profile.foldersToExport.Take(5)) + (profile.foldersToExport.Count > 5 ? $"\n... and {profile.foldersToExport.Count - 5} more" : "")
                : "None configured";
            
            int bundledDeps = profile.dependencies.Count(d => d.enabled && d.exportMode == DependencyExportMode.Bundle);
            int refDeps = profile.dependencies.Count(d => d.enabled && d.exportMode == DependencyExportMode.Dependency);
            
            bool confirm = EditorUtility.DisplayDialog(
                "Export Package",
                $"Export package: {profile.packageName} v{profile.version}\n\n" +
                $"Export Folders ({profile.foldersToExport.Count}):\n{foldersList}\n\n" +
                $"Dependencies:\n" +
                $"  Bundled: {bundledDeps}\n" +
                $"  Referenced: {refDeps}\n\n" +
                $"Obfuscation: {(profile.enableObfuscation ? $"Enabled ({profile.obfuscationPreset}, {profile.assembliesToObfuscate.Count(a => a.enabled)} assemblies)" : "Disabled")}\n\n" +
                $"Output: {profile.GetOutputFilePath()}",
                "Export",
                "Cancel"
            );
            
            if (!confirm)
                return;
            
            isExporting = true;
            _progressContainer.style.display = DisplayStyle.Flex;
            UpdateProgress(0f, "Starting export...");
            UpdateBottomBar();
            
            try
            {
                var result = PackageBuilder.ExportPackage(profile, (progress, status) =>
                {
                    UpdateProgress(progress, status);
                });
                
                isExporting = false;
                _progressContainer.style.display = DisplayStyle.None;
                UpdateBottomBar();
                
                if (result.success)
                {
                    bool openFolder = EditorUtility.DisplayDialog(
                        "Export Successful",
                        $"Package exported successfully!\n\n" +
                        $"Package: {profile.packageName} v{profile.version}\n" +
                        $"Output: {result.outputPath}\n" +
                        $"Files: {result.filesExported}\n" +
                        $"Assemblies Obfuscated: {result.assembliesObfuscated}\n" +
                        $"Build Time: {result.buildTimeSeconds:F2}s",
                        "Open Folder",
                        "OK"
                    );
                    
                    if (openFolder)
                    {
                        EditorUtility.RevealInFinder(result.outputPath);
                    }
                    
                    LoadProfiles();
                    UpdateProfileDetails();
                }
                else
                {
                    EditorUtility.DisplayDialog(
                        "Export Failed",
                        $"Export failed: {result.errorMessage}\n\n" +
                        "Check the console for more details.",
                        "OK"
                    );
                }
            }
            catch (Exception ex)
            {
                isExporting = false;
                _progressContainer.style.display = DisplayStyle.None;
                UpdateBottomBar();
                
                Debug.LogError($"[Package Exporter] Export failed: {ex.Message}");
                EditorUtility.DisplayDialog("Export Failed", $"An error occurred: {ex.Message}", "OK");
            }
        }

        private void ExportAllProfiles(List<ExportProfile> profilesToExport = null)
        {
            var profiles = profilesToExport ?? allProfiles;
            if (profiles.Count == 0)
                return;
            
            var invalidProfiles = new List<string>();
            foreach (var profile in profiles)
            {
                if (!profile.Validate(out string error))
                {
                    invalidProfiles.Add($"{profile.name}: {error}");
                }
            }
            
            if (invalidProfiles.Count > 0)
            {
                string message = "The following profiles have validation errors:\n\n" + string.Join("\n", invalidProfiles);
                EditorUtility.DisplayDialog("Validation Errors", message, "OK");
                return;
            }
            
            bool confirm = EditorUtility.DisplayDialog(
                "Export Profiles",
                $"This will export {profiles.Count} package(s):\n\n" +
                string.Join("\n", profiles.Select(p => $"• {p.packageName} v{p.version}")) +
                "\n\nThis may take several minutes.",
                "Export All",
                "Cancel"
            );
            
            if (!confirm)
                return;
            
            isExporting = true;
            _progressContainer.style.display = DisplayStyle.Flex;
            UpdateBottomBar();
            
            try
            {
                var results = PackageBuilder.ExportMultiple(profiles, (index, total, progress, status) =>
                {
                    float overallProgress = (index + progress) / total;
                    UpdateProgress(overallProgress, $"[{index + 1}/{total}] {status}");
                });
                
                isExporting = false;
                _progressContainer.style.display = DisplayStyle.None;
                UpdateBottomBar();
                
                int successCount = results.Count(r => r.success);
                int failCount = results.Count - successCount;
                
                string summaryMessage = $"Batch export complete!\n\n" +
                                      $"Successful: {successCount}\n" +
                                      $"Failed: {failCount}\n\n";
                
                if (failCount > 0)
                {
                    var failures = results.Where(r => !r.success).ToList();
                    summaryMessage += "Failed profiles:\n" + string.Join("\n", failures.Select(r => $"• {r.errorMessage}"));
                }
                
                EditorUtility.DisplayDialog("Batch Export Complete", summaryMessage, "OK");
                
                LoadProfiles();
                UpdateProfileDetails();
            }
            catch (Exception ex)
            {
                isExporting = false;
                _progressContainer.style.display = DisplayStyle.None;
                UpdateBottomBar();
                
                Debug.LogError($"[Package Exporter] Batch export failed: {ex.Message}");
                EditorUtility.DisplayDialog("Batch Export Failed", $"An error occurred: {ex.Message}", "OK");
            }
        }

        // Scanning operations (simplified implementations)
        private void ScanAssetsForInspector(ExportProfile profile, bool silent = false)
        {
            EditorUtility.DisplayProgressBar("Scanning Assets", "Discovering assets from export folders...", 0f);
            
            try
            {
                var allAssets = new List<DiscoveredAsset>();
                
                // Scan parent profile assets
                var parentAssets = AssetCollector.ScanExportFolders(profile, profile.includeDependencies, profile.packageName);
                allAssets.AddRange(parentAssets);
                
                // Scan bundled profiles if this is a composite profile
                if (profile.HasIncludedProfiles())
                {
                    List<ExportProfile> resolved;
                    List<string> cycles;
                    CompositeProfileResolver.ResolveIncludedProfiles(profile, out resolved, out cycles);
                    
                    foreach (var bundledProfile in resolved)
                    {
                        if (bundledProfile != null)
                        {
                            EditorUtility.DisplayProgressBar("Scanning Assets", $"Scanning bundled profile: {bundledProfile.packageName}...", 0.5f);
                            var bundledAssets = AssetCollector.ScanExportFolders(bundledProfile, bundledProfile.includeDependencies, bundledProfile.packageName);
                            allAssets.AddRange(bundledAssets);
                        }
                    }
                }
                
                profile.discoveredAssets = allAssets;
                profile.MarkScanned();
                EditorUtility.SetDirty(profile);
                
                if (!silent)
                {
                    EditorUtility.DisplayDialog(
                        "Scan Complete",
                        $"Discovered {profile.discoveredAssets.Count} assets.\n\n" +
                        AssetCollector.GetAssetSummary(profile.discoveredAssets),
                        "OK");
                }
                
                UpdateProfileDetails();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Package Exporter] Asset scan failed: {ex.Message}");
                if (!silent)
                {
                    EditorUtility.DisplayDialog("Scan Failed", $"Failed to scan assets:\n{ex.Message}", "OK");
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private void ScanProfileDependencies(ExportProfile profile, bool silent = false)
        {
            if (!silent)
            {
                EditorUtility.DisplayProgressBar("Scanning Dependencies", "Finding installed packages...", 0.3f);
            }
            
            try
            {
                var foundPackages = DependencyScanner.ScanInstalledPackages();
                
                if (foundPackages.Count == 0)
                {
                    if (!silent)
                    {
                        EditorUtility.ClearProgressBar();
                        EditorUtility.DisplayDialog("No Packages Found", 
                            "No installed packages were found in the project.", 
                            "OK");
                    }
                    return;
                }
                
                if (!silent)
                {
                    EditorUtility.DisplayProgressBar("Scanning Dependencies", "Processing packages...", 0.6f);
                }
                
                // Preserve existing dependency settings (enabled state and exportMode) before clearing
                var existingSettings = new Dictionary<string, (bool enabled, DependencyExportMode exportMode)>();
                foreach (var existingDep in profile.dependencies)
                {
                    if (!string.IsNullOrEmpty(existingDep.packageName))
                    {
                        existingSettings[existingDep.packageName] = (existingDep.enabled, existingDep.exportMode);
                    }
                }
                
                profile.dependencies.Clear();
                
                // Normalize package name for comparison (same normalization as in GeneratePackageJson)
                string normalizedPackageName = profile.packageName.ToLower().Replace(" ", ".");
                
                var dependencies = DependencyScanner.ConvertToPackageDependencies(foundPackages);
                foreach (var dep in dependencies)
                {
                    // Skip the package itself - prevent self-referential dependencies
                    if (string.Equals(dep.packageName, normalizedPackageName, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    
                    if (existingSettings.TryGetValue(dep.packageName, out var settings))
                    {
                        dep.enabled = settings.enabled;
                        dep.exportMode = settings.exportMode;
                    }
                    profile.dependencies.Add(dep);
                }
                
                if (!profile.dependencies.Any(d => d.packageName == "com.yucp.devtools"))
                {
                    var devtoolsDep = new PackageDependency("com.yucp.devtools", "*", "YUCP Dev Tools", false);
                    profile.dependencies.Add(devtoolsDep);
                }
                
                if (!silent)
                {
                    EditorUtility.DisplayProgressBar("Scanning Dependencies", "Auto-detecting usage...", 0.8f);
                }
                
                if (profile.foldersToExport.Count > 0)
                {
                    DependencyScanner.AutoDetectUsedDependencies(profile);
                }
                
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                
                if (!silent)
                {
                    int vpmCount = dependencies.Count(d => d.isVpmDependency);
                    int autoEnabled = dependencies.Count(d => d.enabled);
                    
                    string message = $"Found {dependencies.Count} packages:\n\n" +
                                   $"• {vpmCount} VRChat (VPM) packages\n" +
                                   $"• {dependencies.Count - vpmCount} Unity packages\n" +
                                   $"• {autoEnabled} auto-enabled (detected in use)\n\n" +
                                   "Dependencies detected in your export folders have been automatically enabled.";
                    
                    EditorUtility.DisplayDialog("Scan Complete", message, "OK");
                }
                
                UpdateProfileDetails();
            }
            finally
            {
                if (!silent)
                {
                    EditorUtility.ClearProgressBar();
                }
            }
        }

        private void ScanAllAssemblies(ExportProfile profile)
        {
            try
            {
                EditorUtility.DisplayProgressBar("Scanning Assemblies", "Initializing...", 0f);
                
                var foundAssemblies = new List<AssemblyScanner.AssemblyInfo>();
                
                EditorUtility.DisplayProgressBar("Scanning Assemblies", $"Scanning {profile.foldersToExport.Count} export folders...", 0.2f);
                var folderAssemblies = AssemblyScanner.ScanFolders(profile.foldersToExport);
                foundAssemblies.AddRange(folderAssemblies);
                
                EditorUtility.DisplayProgressBar("Scanning Assemblies", $"Found {folderAssemblies.Count} assemblies in export folders", 0.5f);
                
                int bundledDepsCount = profile.dependencies.Count(d => d.enabled && d.exportMode == DependencyExportMode.Bundle);
                
                if (bundledDepsCount > 0)
                {
                    EditorUtility.DisplayProgressBar("Scanning Assemblies", $"Scanning {bundledDepsCount} bundled dependencies...", 0.6f);
                }
                
                var dependencyAssemblies = AssemblyScanner.ScanVpmPackages(profile.dependencies);
                foundAssemblies.AddRange(dependencyAssemblies);
                
                EditorUtility.DisplayProgressBar("Scanning Assemblies", $"Found {dependencyAssemblies.Count} assemblies in bundled dependencies", 0.8f);
                
                if (foundAssemblies.Count == 0)
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("No Assemblies Found", 
                        "No .asmdef files were found in export folders or enabled dependencies.", 
                        "OK");
                    return;
                }
                
                EditorUtility.DisplayProgressBar("Scanning Assemblies", "Processing assembly list...", 0.9f);
                
                profile.assembliesToObfuscate.Clear();
                
                foreach (var assemblyInfo in foundAssemblies)
                {
                    var settings = new AssemblyObfuscationSettings(assemblyInfo.assemblyName, assemblyInfo.asmdefPath);
                    settings.enabled = assemblyInfo.exists;
                    profile.assembliesToObfuscate.Add(settings);
                }
                
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                
                int existingCount = foundAssemblies.Count(a => a.exists);
                EditorUtility.DisplayDialog("Scan Complete", 
                    $"Found {foundAssemblies.Count} assemblies ({existingCount} compiled)\n\nFrom export folders: {folderAssemblies.Count}\nFrom bundled dependencies: {dependencyAssemblies.Count}", 
                    "OK");
                
                UpdateProfileDetails();
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        // Helper methods for Export Inspector
        private string GetAssetTypeIcon(string assetType)
        {
            return assetType switch
            {
                "Script" => "C#",
                "Prefab" => "P",
                "Material" => "M",
                "Texture" => "T",
                "Scene" => "S",
                "Shader" => "SH",
                "Model" => "3D",
                "Animation" => "A",
                "Animator" => "AC",
                "Assembly" => "DLL",
                "Audio" => "AU",
                "Font" => "F",
                _ => "F"
            };
        }

        private string FormatBytes(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;
            
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }
            
            return $"{len:0.##} {sizes[order]}";
        }

        private void ClearAssetScan(ExportProfile profile)
        {
            if (EditorUtility.DisplayDialog("Clear Scan", 
                "Clear all discovered assets and rescan later?", "Clear", "Cancel"))
            {
                profile.ClearScan();
                EditorUtility.SetDirty(profile);
                UpdateProfileDetails();
            }
        }

        private void AddFolderToIgnoreList(ExportProfile profile, string folderPath)
        {
            var ignoreFolders = profile.PermanentIgnoreFolders;
            if (!ignoreFolders.Contains(folderPath))
            {
                ignoreFolders.Add(folderPath);
                EditorUtility.SetDirty(profile);
                
                // Automatically rescan without popup
                ScanAssetsForInspector(profile, silent: true);
            }
            else
            {
                EditorUtility.DisplayDialog("Already Ignored", $"'{folderPath}' is already in the ignore list.", "OK");
            }
        }

        private void RemoveFromIgnoreList(ExportProfile profile, string folderPath)
        {
            var ignoreFolders = profile.PermanentIgnoreFolders;
            if (ignoreFolders != null && ignoreFolders.Contains(folderPath))
            {
                ignoreFolders.Remove(folderPath);
                EditorUtility.SetDirty(profile);
                UpdateProfileDetails();
            }
        }

        private void AutoDetectUsedDependencies(ExportProfile profile)
        {
            if (profile.dependencies.Count == 0)
            {
                EditorUtility.DisplayDialog("No Dependencies", 
                    "Scan for installed packages first before auto-detecting.", 
                    "OK");
                return;
            }
            
            EditorUtility.DisplayProgressBar("Auto-Detecting Dependencies", "Scanning assets...", 0.5f);
            
            try
            {
                DependencyScanner.AutoDetectUsedDependencies(profile);
                
                EditorUtility.ClearProgressBar();
                
                int enabledCount = profile.dependencies.Count(d => d.enabled);
                int disabledCount = profile.dependencies.Count - enabledCount;
                
                string message = $"Auto-detection complete!\n\n" +
                               $"• {enabledCount} dependencies enabled (used in export)\n" +
                               $"• {disabledCount} dependencies disabled (not used)\n\n" +
                               "Review the dependency list and adjust as needed.";
                
                EditorUtility.DisplayDialog("Auto-Detection Complete", message, "OK");
                
                EditorUtility.SetDirty(profile);
                AssetDatabase.SaveAssets();
                UpdateProfileDetails();
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private void CreateYucpIgnoreFile(ExportProfile profile, string folderPath)
        {
            if (YucpIgnoreHandler.CreateIgnoreFile(folderPath))
            {
                AssetDatabase.Refresh();
                
                if (EditorUtility.DisplayDialog(
                    "Created .yucpignore",
                    $"Created .yucpignore file in:\n{folderPath}\n\nOpen the file to edit ignore patterns?",
                    "Open",
                    "Later"))
                {
                    OpenYucpIgnoreFile(folderPath);
                }
                
                if (EditorUtility.DisplayDialog(
                    "Rescan Assets",
                    "Rescan assets now to apply the new ignore file?",
                    "Rescan",
                    "Later"))
                {
                    ScanAssetsForInspector(profile);
                }
                else
                {
                    UpdateProfileDetails();
                }
            }
        }

        private void OpenYucpIgnoreFile(string folderPath)
        {
            string ignoreFilePath = YucpIgnoreHandler.GetIgnoreFilePath(folderPath);
            
            if (File.Exists(ignoreFilePath))
            {
                System.Diagnostics.Process.Start(ignoreFilePath);
            }
            else
            {
                EditorUtility.DisplayDialog("File Not Found", $".yucpignore file not found:\n{ignoreFilePath}", "OK");
            }
        }

        private void ScanAndBumpVersionsInProfile(ExportProfile profile)
        {
            if (profile == null || profile.foldersToExport == null || profile.foldersToExport.Count == 0)
            {
                EditorUtility.DisplayDialog("No Folders", 
                    "No folders to scan. Add folders to export first.", 
                    "OK");
                return;
            }
            
            // Preview first
            EditorUtility.DisplayProgressBar("Scanning for Version Directives", "Finding files...", 0.3f);
            
            var previewResults = ProjectVersionScanner.PreviewBumpInProfile(profile);
            
            EditorUtility.ClearProgressBar();
            
            if (previewResults.Count == 0)
            {
                EditorUtility.DisplayDialog("No Directives Found", 
                    "No version bump directives (@bump) found in export folders.\n\n" +
                    "Add directives like:\n" +
                    "  // @bump semver:patch\n" +
                    "  // @bump dotted_tail\n" +
                    "  // @bump wordnum\n\n" +
                    "to your source files.", 
                    "OK");
                return;
            }
            
            // Show preview dialog
            string previewMessage = SmartVersionBumper.GetBumpSummary(previewResults);
            bool confirmed = EditorUtility.DisplayDialog(
                "Version Bump Preview",
                $"Found {previewResults.Count} version(s) to bump:\n\n{previewMessage}\n\nApply these changes?",
                "Apply",
                "Cancel"
            );
            
            if (!confirmed)
                return;
            
            // Apply the bumps
            EditorUtility.DisplayProgressBar("Bumping Versions", "Updating files...", 0.7f);
            
            var results = ProjectVersionScanner.BumpVersionsInProfile(profile, writeBack: true);
            
            EditorUtility.ClearProgressBar();
            
            int successful = results.Count(r => r.Success);
            int failed = results.Count(r => !r.Success);
            
            string resultMessage = $"Version bump complete!\n\n" +
                                 $"Successful: {successful}\n" +
                                 $"Failed: {failed}";
            
            if (failed > 0)
            {
                resultMessage += "\n\nCheck the console for details on failures.";
                foreach (var failure in results.Where(r => !r.Success))
                {
                    Debug.LogWarning($"[YUCP] Version bump failed: {failure}");
                }
            }
            
            EditorUtility.DisplayDialog("Version Bump Complete", resultMessage, "OK");
            
            // Log successful bumps
            
            AssetDatabase.Refresh();
        }

        private void CreateCustomRule(ExportProfile profile)
        {
            string savePath = EditorUtility.SaveFilePanelInProject(
                "Create Custom Version Rule",
                "CustomVersionRule",
                "asset",
                "Create a new custom version rule asset"
            );
            
            if (string.IsNullOrEmpty(savePath))
                return;
            
            var customRule = ScriptableObject.CreateInstance<CustomVersionRule>();
            customRule.ruleName = "my_custom_rule";
            customRule.displayName = "My Custom Rule";
            customRule.description = "Custom version bumping rule";
            customRule.regexPattern = @"\b(?<major>\d+)\.(?<minor>\d+)\.(?<patch>\d+)\b";
            customRule.ruleType = CustomVersionRule.RuleType.Semver;
            customRule.exampleInput = "1.0.0";
            customRule.exampleOutput = "1.0.1";
            
            AssetDatabase.CreateAsset(customRule, savePath);
            AssetDatabase.SaveAssets();
            
            Selection.activeObject = customRule;
            EditorGUIUtility.PingObject(customRule);
            
            // Auto-assign to profile
            if (profile != null)
            {
                Undo.RecordObject(profile, "Assign Custom Rule");
                profile.customVersionRule = customRule;
                customRule.RegisterRule();
                EditorUtility.SetDirty(profile);
                UpdateProfileDetails();
            }
            
            EditorUtility.DisplayDialog(
                "Custom Rule Created",
                $"Custom version rule created at:\n{savePath}\n\n" +
                "Edit the asset to configure:\n" +
                "• Rule name\n" +
                "• Regex pattern\n" +
                "• Rule type\n" +
                "• Test with examples",
                "OK"
            );
        }

        private void TestCustomRule(CustomVersionRule rule)
        {
            if (rule == null)
                return;
            
            string result = rule.TestRule();
            
            EditorUtility.DisplayDialog(
                $"Test Rule: {rule.displayName}",
                $"Rule Name: {rule.ruleName}\n" +
                $"Type: {rule.ruleType}\n" +
                $"Pattern: {rule.regexPattern}\n\n" +
                $"Example Input: {rule.exampleInput}\n" +
                $"Expected Output: {rule.exampleOutput}\n" +
                $"Actual Output: {result}\n\n" +
                (result == rule.exampleOutput ? "[OK] Test PASSED" : "[X] Test FAILED"),
                "OK"
            );
        }

        private string GetStrategyExplanation(VersionIncrementStrategy strategy)
        {
            return strategy switch
            {
                VersionIncrementStrategy.Major => "Breaking changes: 1.0.0 → 2.0.0",
                VersionIncrementStrategy.Minor => "New features: 1.0.0 → 1.1.0",
                VersionIncrementStrategy.Patch => "Bug fixes: 1.0.0 → 1.0.1",
                VersionIncrementStrategy.Build => "Build number: 1.0.0.0 → 1.0.0.1",
                _ => ""
            };
        }

        private VisualElement CreateCustomRuleEditor(ExportProfile profile)
        {
            var rule = profile.customVersionRule;
            if (rule == null) return new VisualElement();
            
            var editorContainer = new VisualElement();
            editorContainer.style.backgroundColor = new UnityEngine.UIElements.StyleColor(new Color(0.25f, 0.3f, 0.35f, 0.3f));
            editorContainer.style.borderTopWidth = 1;
            editorContainer.style.borderBottomWidth = 1;
            editorContainer.style.borderLeftWidth = 1;
            editorContainer.style.borderRightWidth = 1;
            editorContainer.style.borderTopColor = new UnityEngine.UIElements.StyleColor(new Color(0.3f, 0.4f, 0.5f));
            editorContainer.style.borderBottomColor = new UnityEngine.UIElements.StyleColor(new Color(0.3f, 0.4f, 0.5f));
            editorContainer.style.borderLeftColor = new UnityEngine.UIElements.StyleColor(new Color(0.3f, 0.4f, 0.5f));
            editorContainer.style.borderRightColor = new UnityEngine.UIElements.StyleColor(new Color(0.3f, 0.4f, 0.5f));
            editorContainer.style.borderTopLeftRadius = 4;
            editorContainer.style.borderTopRightRadius = 4;
            editorContainer.style.borderBottomLeftRadius = 4;
            editorContainer.style.borderBottomRightRadius = 4;
            editorContainer.style.paddingTop = 10;
            editorContainer.style.paddingBottom = 10;
            editorContainer.style.paddingLeft = 10;
            editorContainer.style.paddingRight = 10;
            editorContainer.style.marginTop = 8;
            editorContainer.style.marginBottom = 8;
            
            var title = new Label($"Editing: {rule.displayName}");
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.fontSize = 12;
            title.style.marginBottom = 8;
            editorContainer.Add(title);
            
            // Rule Name
            var ruleNameRow = CreateFormRow("Rule Name", tooltip: "Identifier used in @bump directives (lowercase, no spaces)");
            var ruleNameField = new TextField { value = rule.ruleName };
            ruleNameField.AddToClassList("yucp-input");
            ruleNameField.AddToClassList("yucp-form-field");
            ruleNameField.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Rule Name");
                rule.ruleName = evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            ruleNameRow.Add(ruleNameField);
            editorContainer.Add(ruleNameRow);
            
            // Display Name
            var displayNameRow = CreateFormRow("Display Name", tooltip: "Human-readable name");
            var displayNameField = new TextField { value = rule.displayName };
            displayNameField.AddToClassList("yucp-input");
            displayNameField.AddToClassList("yucp-form-field");
            displayNameField.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Display Name");
                rule.displayName = evt.newValue;
                EditorUtility.SetDirty(rule);
                UpdateProfileDetails(); // Refresh title
            });
            displayNameRow.Add(displayNameField);
            editorContainer.Add(displayNameRow);
            
            // Description
            var descLabel = new Label("Description");
            descLabel.AddToClassList("yucp-label");
            descLabel.style.marginTop = 8;
            descLabel.style.marginBottom = 4;
            editorContainer.Add(descLabel);
            
            var descField = new TextField { value = rule.description, multiline = true };
            descField.AddToClassList("yucp-input");
            descField.AddToClassList("yucp-input-multiline");
            descField.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Description");
                rule.description = evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            editorContainer.Add(descField);
            
            // Regex Pattern
            var patternLabel = new Label("Regex Pattern");
            patternLabel.AddToClassList("yucp-label");
            patternLabel.style.marginTop = 8;
            patternLabel.style.marginBottom = 4;
            editorContainer.Add(patternLabel);
            
            var patternField = new TextField { value = rule.regexPattern, multiline = true };
            patternField.AddToClassList("yucp-input");
            patternField.AddToClassList("yucp-input-multiline");
            patternField.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Regex Pattern");
                rule.regexPattern = evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            editorContainer.Add(patternField);
            
            // Rule Type
            var ruleTypeRow = CreateFormRow("Rule Type", tooltip: "Base behavior for this rule");
            var ruleTypeField = new EnumField(rule.ruleType);
            ruleTypeField.AddToClassList("yucp-form-field");
            ruleTypeField.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Rule Type");
                rule.ruleType = (CustomVersionRule.RuleType)evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            ruleTypeRow.Add(ruleTypeField);
            editorContainer.Add(ruleTypeRow);
            
            // Options row
            var optionsRow = new VisualElement();
            optionsRow.style.flexDirection = FlexDirection.Row;
            optionsRow.style.marginTop = 8;
            
            var supportsPartsToggle = new Toggle("Supports Parts") { value = rule.supportsParts };
            supportsPartsToggle.AddToClassList("yucp-toggle");
            supportsPartsToggle.tooltip = "Whether the rule understands major/minor/patch";
            supportsPartsToggle.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Supports Parts");
                rule.supportsParts = evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            optionsRow.Add(supportsPartsToggle);
            
            var preservePaddingToggle = new Toggle("Preserve Padding") { value = rule.preservePadding };
            preservePaddingToggle.AddToClassList("yucp-toggle");
            preservePaddingToggle.tooltip = "Keep zero padding in numbers (007 → 008)";
            preservePaddingToggle.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Preserve Padding");
                rule.preservePadding = evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            optionsRow.Add(preservePaddingToggle);
            
            editorContainer.Add(optionsRow);
            
            // Test section
            var testLabel = new Label("Test");
            testLabel.AddToClassList("yucp-label");
            testLabel.style.marginTop = 12;
            testLabel.style.marginBottom = 4;
            editorContainer.Add(testLabel);
            
            var testRow = new VisualElement();
            testRow.style.flexDirection = FlexDirection.Row;
            testRow.style.marginBottom = 4;
            
            var inputLabel = new Label("Input:");
            inputLabel.style.width = 60;
            inputLabel.style.marginRight = 4;
            testRow.Add(inputLabel);
            
            var exampleInputField = new TextField { value = rule.exampleInput };
            exampleInputField.AddToClassList("yucp-input");
            exampleInputField.style.flexGrow = 1;
            exampleInputField.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Example Input");
                rule.exampleInput = evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            testRow.Add(exampleInputField);
            
            editorContainer.Add(testRow);
            
            var expectedRow = new VisualElement();
            expectedRow.style.flexDirection = FlexDirection.Row;
            expectedRow.style.marginBottom = 8;
            
            var expectedLabel = new Label("Expected:");
            expectedLabel.style.width = 60;
            expectedLabel.style.marginRight = 4;
            expectedRow.Add(expectedLabel);
            
            var exampleOutputField = new TextField { value = rule.exampleOutput };
            exampleOutputField.AddToClassList("yucp-input");
            exampleOutputField.style.flexGrow = 1;
            exampleOutputField.RegisterValueChangedCallback(evt =>
            {
                Undo.RecordObject(rule, "Change Example Output");
                rule.exampleOutput = evt.newValue;
                EditorUtility.SetDirty(rule);
            });
            expectedRow.Add(exampleOutputField);
            
            editorContainer.Add(expectedRow);
            
            // Action buttons
            var buttonRow = new VisualElement();
            buttonRow.style.flexDirection = FlexDirection.Row;
            buttonRow.style.justifyContent = Justify.FlexEnd;
            buttonRow.style.marginTop = 8;
            
            var testBtn = new Button(() => TestCustomRule(rule)) { text = "Test Rule" };
            testBtn.AddToClassList("yucp-button");
            testBtn.tooltip = "Test the rule with the example input";
            buttonRow.Add(testBtn);
            
            var registerBtn = new Button(() => 
            {
                rule.RegisterRule();
                EditorUtility.DisplayDialog("Rule Registered", $"Rule '{rule.ruleName}' has been registered and is ready to use.", "OK");
            }) { text = "Save & Register" };
            registerBtn.AddToClassList("yucp-button");
            registerBtn.tooltip = "Register this rule so it can be used";
            buttonRow.Add(registerBtn);
            
            var selectBtn = new Button(() => 
            {
                Selection.activeObject = rule;
                EditorGUIUtility.PingObject(rule);
            }) { text = "Select Asset" };
            selectBtn.AddToClassList("yucp-button");
            selectBtn.tooltip = "Select the rule asset in the project";
            buttonRow.Add(selectBtn);
            
            editorContainer.Add(buttonRow);
            
            return editorContainer;
        }
        
        // ============================================================================
        // RESPONSIVE DESIGN METHODS
        // ============================================================================
        
        private void OnGeometryChanged(GeometryChangedEvent evt)
        {
            UpdateResponsiveLayout(evt.newRect.width);
        }
        
        private void UpdateResponsiveLayout(float width)
        {
            var root = rootVisualElement;
            
            // Remove all responsive classes first
            root.RemoveFromClassList("yucp-window-narrow");
            root.RemoveFromClassList("yucp-window-medium");
            root.RemoveFromClassList("yucp-window-wide");
            
            // Apply appropriate class
            if (width < 700f)
            {
                root.AddToClassList("yucp-window-narrow");
            }
            else if (width < 900f)
            {
                root.AddToClassList("yucp-window-medium");
            }
            else
            {
                root.AddToClassList("yucp-window-wide");
            }
            
            // Close overlay if window is wide enough
            if (width >= 700f && _isOverlayOpen)
            {
                CloseOverlay();
            }
        }
        
        private void ToggleOverlay()
        {
            if (_isOverlayOpen)
            {
                CloseOverlay();
            }
            else
            {
                OpenOverlay();
            }
        }
        
        private void OpenOverlay()
        {
            _isOverlayOpen = true;
            
            // Show backdrop first
            if (_overlayBackdrop != null)
            {
                _overlayBackdrop.style.display = DisplayStyle.Flex;
                _overlayBackdrop.style.visibility = Visibility.Visible;
                _overlayBackdrop.style.position = Position.Absolute;
                _overlayBackdrop.style.left = 0;
                _overlayBackdrop.style.right = 0;
                _overlayBackdrop.style.top = 0;
                _overlayBackdrop.style.bottom = 0;
                _overlayBackdrop.style.opacity = 0;
                _overlayBackdrop.BringToFront();
                
                // Fade in backdrop
                _overlayBackdrop.schedule.Execute(() => 
                {
                    if (_overlayBackdrop != null)
                    {
                        _overlayBackdrop.style.opacity = 1;
                    }
                }).StartingIn(10);
            }
            
            // Show overlay
            if (_leftPaneOverlay != null)
            {
                // Force dimensions and positioning with inline styles
                _leftPaneOverlay.style.display = DisplayStyle.Flex;
                _leftPaneOverlay.style.visibility = Visibility.Visible;
                _leftPaneOverlay.style.position = Position.Absolute;
                _leftPaneOverlay.style.width = 270;
                _leftPaneOverlay.style.top = 0;
                _leftPaneOverlay.style.bottom = 0;
                _leftPaneOverlay.style.left = -270;
                _leftPaneOverlay.style.opacity = 0;
                
                // Ensure it's in front
                _leftPaneOverlay.BringToFront();
                
                // Animate to visible position
                _leftPaneOverlay.schedule.Execute(() => 
                {
                    if (_leftPaneOverlay != null)
                    {
                        _leftPaneOverlay.style.left = 0;
                        _leftPaneOverlay.style.opacity = 1;
                    }
                }).StartingIn(10);
            }
        }
        
        // ============================================================================
        // BULK EDIT METHODS
        // ============================================================================
        
        private VisualElement CreateBulkEditorSection()
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var title = new Label($"Bulk Edit ({selectedProfileIndices.Count} profiles selected)");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var helpBox = new VisualElement();
            helpBox.AddToClassList("yucp-help-box");
            var helpText = new Label("Changes made here will be applied to all selected profiles. Package names remain unique to each profile.");
            helpText.AddToClassList("yucp-help-box-text");
            helpBox.Add(helpText);
            section.Add(helpBox);
            
            // Get selected profiles
            var selectedProfiles = selectedProfileIndices
                .Select(i => allProfiles[i])
                .Where(p => p != null)
                .ToList();
            
            // Version field
            var versionRow = CreateFormRow("Version", tooltip: "Set version for all selected profiles");
            var versionField = new TextField();
            versionField.AddToClassList("yucp-input");
            versionField.AddToClassList("yucp-form-field");
            
            // Show current version if all are the same, otherwise show placeholder
            var versions = selectedProfiles.Select(p => p.version).Distinct().ToList();
            Label versionPlaceholder = null;
            if (versions.Count == 1)
            {
                versionField.value = versions[0];
            }
            else
            {
                versionField.value = "";
                versionField.style.opacity = 0.7f;
                // Add placeholder label
                versionPlaceholder = new Label("Mixed values - enter new version");
                versionPlaceholder.AddToClassList("yucp-label-secondary");
                versionPlaceholder.style.position = Position.Absolute;
                versionPlaceholder.style.left = 8;
                versionPlaceholder.style.top = 4;
                versionPlaceholder.pickingMode = PickingMode.Ignore;
                versionRow.style.position = Position.Relative;
                versionRow.Add(versionPlaceholder);
            }
            
            versionField.RegisterValueChangedCallback(evt =>
            {
                if (versionPlaceholder != null)
                {
                    if (string.IsNullOrEmpty(evt.newValue))
                    {
                        versionPlaceholder.style.display = DisplayStyle.Flex;
                        versionField.style.opacity = 0.7f;
                    }
                    else
                    {
                        versionPlaceholder.style.display = DisplayStyle.None;
                        versionField.style.opacity = 1f;
                    }
                }
                
                // Apply changes to all selected profiles
                if (!string.IsNullOrEmpty(evt.newValue))
                {
                    ApplyToAllSelected(profile => 
                    {
                        Undo.RecordObject(profile, "Bulk Change Version");
                        profile.version = evt.newValue;
                        EditorUtility.SetDirty(profile);
                    });
                    // Refresh to show updated value
                    UpdateProfileDetails();
                }
            });
            versionRow.Add(versionField);
            section.Add(versionRow);
            
            // Author field
            var authorRow = CreateFormRow("Author", tooltip: "Set author for all selected profiles");
            var authorField = new TextField();
            authorField.AddToClassList("yucp-input");
            authorField.AddToClassList("yucp-form-field");
            
            var authors = selectedProfiles.Select(p => p.author ?? "").Distinct().ToList();
            Label authorPlaceholder = null;
            if (authors.Count == 1)
            {
                authorField.value = authors[0];
            }
            else
            {
                authorField.value = "";
                authorField.style.opacity = 0.7f;
                authorPlaceholder = new Label("Mixed values - enter new author");
                authorPlaceholder.AddToClassList("yucp-label-secondary");
                authorPlaceholder.style.position = Position.Absolute;
                authorPlaceholder.style.left = 8;
                authorPlaceholder.style.top = 4;
                authorPlaceholder.pickingMode = PickingMode.Ignore;
                authorRow.style.position = Position.Relative;
                authorRow.Add(authorPlaceholder);
            }
            
            authorField.RegisterValueChangedCallback(evt =>
            {
                if (authorPlaceholder != null)
                {
                    if (string.IsNullOrEmpty(evt.newValue))
                    {
                        authorPlaceholder.style.display = DisplayStyle.Flex;
                        authorField.style.opacity = 0.7f;
                    }
                    else
                    {
                        authorPlaceholder.style.display = DisplayStyle.None;
                        authorField.style.opacity = 1f;
                    }
                }
                
                if (!string.IsNullOrEmpty(evt.newValue))
                {
                    ApplyToAllSelected(profile => 
                    {
                        Undo.RecordObject(profile, "Bulk Change Author");
                        profile.author = evt.newValue;
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                }
            });
            authorRow.Add(authorField);
            section.Add(authorRow);
            
            // Description field
            var descriptionRow = CreateFormRow("Description", tooltip: "Set description for all selected profiles");
            var descriptionField = new TextField();
            descriptionField.AddToClassList("yucp-input");
            descriptionField.AddToClassList("yucp-form-field");
            descriptionField.multiline = true;
            descriptionField.style.height = 60;
            
            var descriptions = selectedProfiles.Select(p => p.description ?? "").Distinct().ToList();
            Label descriptionPlaceholder = null;
            if (descriptions.Count == 1)
            {
                descriptionField.value = descriptions[0];
            }
            else
            {
                descriptionField.value = "";
                descriptionField.style.opacity = 0.7f;
                descriptionPlaceholder = new Label("Mixed values - enter new description");
                descriptionPlaceholder.AddToClassList("yucp-label-secondary");
                descriptionPlaceholder.style.position = Position.Absolute;
                descriptionPlaceholder.style.left = 8;
                descriptionPlaceholder.style.top = 4;
                descriptionPlaceholder.pickingMode = PickingMode.Ignore;
                descriptionRow.style.position = Position.Relative;
                descriptionRow.Add(descriptionPlaceholder);
            }
            
            descriptionField.RegisterValueChangedCallback(evt =>
            {
                if (descriptionPlaceholder != null)
                {
                    if (string.IsNullOrEmpty(evt.newValue))
                    {
                        descriptionPlaceholder.style.display = DisplayStyle.Flex;
                        descriptionField.style.opacity = 0.7f;
                    }
                    else
                    {
                        descriptionPlaceholder.style.display = DisplayStyle.None;
                        descriptionField.style.opacity = 1f;
                    }
                }
                
                if (!string.IsNullOrEmpty(evt.newValue))
                {
                    ApplyToAllSelected(profile => 
                    {
                        Undo.RecordObject(profile, "Bulk Change Description");
                        profile.description = evt.newValue;
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                }
            });
            descriptionRow.Add(descriptionField);
            section.Add(descriptionRow);
            
            // Icon field
            var iconRow = CreateFormRow("Icon", tooltip: "Set icon for all selected profiles");
            var icons = selectedProfiles.Select(p => p.icon).Distinct().ToList();
            var iconField = new ObjectField();
            iconField.objectType = typeof(Texture2D);
            iconField.AddToClassList("yucp-form-field");
            if (icons.Count == 1)
            {
                iconField.value = icons[0];
            }
            else
            {
                iconField.value = null;
            }
            iconField.RegisterValueChangedCallback(evt =>
            {
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Change Icon");
                    profile.icon = evt.newValue as Texture2D;
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            });
            iconRow.Add(iconField);
            section.Add(iconRow);
            
            // Export Path
            var pathRow = CreateFormRow("Export Path", tooltip: "Set export path for all selected profiles");
            var pathField = new TextField();
            pathField.AddToClassList("yucp-input");
            pathField.AddToClassList("yucp-form-field");
            
            var paths = selectedProfiles.Select(p => p.exportPath ?? "").Distinct().ToList();
            Label pathPlaceholder = null;
            if (paths.Count == 1)
            {
                pathField.value = paths[0];
            }
            else
            {
                pathField.value = "";
                pathField.style.opacity = 0.7f;
                // Add placeholder label
                pathPlaceholder = new Label("Mixed values - use Browse to set");
                pathPlaceholder.AddToClassList("yucp-label-secondary");
                pathPlaceholder.style.position = Position.Absolute;
                pathPlaceholder.style.left = 8;
                pathPlaceholder.style.top = 4;
                pathPlaceholder.pickingMode = PickingMode.Ignore;
                pathField.RegisterValueChangedCallback(evt => 
                {
                    if (string.IsNullOrEmpty(evt.newValue) && pathPlaceholder != null)
                    {
                        pathPlaceholder.style.display = DisplayStyle.Flex;
                        pathField.style.opacity = 0.7f;
                    }
                    else
                    {
                        if (pathPlaceholder != null)
                            pathPlaceholder.style.display = DisplayStyle.None;
                        pathField.style.opacity = 1f;
                    }
                });
                pathRow.style.position = Position.Relative;
                pathRow.Add(pathPlaceholder);
            }
            
            var browseButton = new Button(() => 
            {
                string currentPath = pathField.value;
                if (string.IsNullOrEmpty(currentPath))
                {
                    currentPath = "";
                }
                string newPath = EditorUtility.OpenFolderPanel("Select Export Path", currentPath, "");
                if (!string.IsNullOrEmpty(newPath))
                {
                    pathField.value = newPath;
                    // Hide placeholder if it exists
                    if (pathPlaceholder != null)
                    {
                        pathPlaceholder.style.display = DisplayStyle.None;
                        pathField.style.opacity = 1f;
                    }
                    ApplyToAllSelected(profile => 
                    {
                        Undo.RecordObject(profile, "Bulk Change Export Path");
                        profile.exportPath = newPath;
                        EditorUtility.SetDirty(profile);
                    });
                    // Refresh to show updated value
                    UpdateProfileDetails();
                }
            }) { text = "Browse" };
            browseButton.AddToClassList("yucp-button");
            browseButton.AddToClassList("yucp-button-action");
            pathRow.Add(pathField);
            pathRow.Add(browseButton);
            section.Add(pathRow);
            
            // Profile Save Location
            var profileSaveRow = CreateFormRow("Profile Save Location", tooltip: "Custom location to save profiles");
            var profileSaveField = new TextField();
            profileSaveField.AddToClassList("yucp-input");
            profileSaveField.AddToClassList("yucp-form-field");
            
            var saveLocs = selectedProfiles.Select(p => p.profileSaveLocation ?? "").Distinct().ToList();
            Label savePlaceholder = null;
            if (saveLocs.Count == 1)
            {
                profileSaveField.value = saveLocs[0];
            }
            else
            {
                profileSaveField.value = "";
                profileSaveField.style.opacity = 0.7f;
                savePlaceholder = new Label("Mixed values - use Browse to set");
                savePlaceholder.AddToClassList("yucp-label-secondary");
                savePlaceholder.style.position = Position.Absolute;
                savePlaceholder.style.left = 8;
                savePlaceholder.style.top = 4;
                savePlaceholder.pickingMode = PickingMode.Ignore;
                profileSaveField.RegisterValueChangedCallback(evt => 
                {
                    if (string.IsNullOrEmpty(evt.newValue) && savePlaceholder != null)
                    {
                        savePlaceholder.style.display = DisplayStyle.Flex;
                        profileSaveField.style.opacity = 0.7f;
                    }
                    else
                    {
                        if (savePlaceholder != null)
                            savePlaceholder.style.display = DisplayStyle.None;
                        profileSaveField.style.opacity = 1f;
                    }
                });
                profileSaveRow.style.position = Position.Relative;
                profileSaveRow.Add(savePlaceholder);
            }
            
            var browseSaveButton = new Button(() => 
            {
                string currentPath = profileSaveField.value;
                if (string.IsNullOrEmpty(currentPath))
                {
                    currentPath = "";
                }
                string newPath = EditorUtility.OpenFolderPanel("Select Profile Save Location", currentPath, "");
                if (!string.IsNullOrEmpty(newPath))
                {
                    profileSaveField.value = newPath;
                    if (savePlaceholder != null)
                    {
                        savePlaceholder.style.display = DisplayStyle.None;
                        profileSaveField.style.opacity = 1f;
                    }
                    ApplyToAllSelected(profile => 
                    {
                        Undo.RecordObject(profile, "Bulk Change Profile Save Location");
                        profile.profileSaveLocation = newPath;
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                }
            }) { text = "Browse" };
            browseSaveButton.AddToClassList("yucp-button");
            browseSaveButton.AddToClassList("yucp-button-action");
            profileSaveRow.Add(profileSaveField);
            profileSaveRow.Add(browseSaveButton);
            section.Add(profileSaveRow);
            
            // Export Options Toggles
            var optionsTitle = new Label("Export Options");
            optionsTitle.AddToClassList("yucp-section-title");
            optionsTitle.style.marginTop = 16;
            optionsTitle.style.marginBottom = 8;
            section.Add(optionsTitle);
            
            // Get common values for toggles
            bool allIncludeDeps = selectedProfiles.All(p => p.includeDependencies);
            bool allRecurse = selectedProfiles.All(p => p.recurseFolders);
            bool allGenerateJson = selectedProfiles.All(p => p.generatePackageJson);
            
            // Include Dependencies
            var includeDepsToggle = CreateBulkToggle("Include Dependencies", allIncludeDeps, 
                profile => profile.includeDependencies,
                (profile, value) => profile.includeDependencies = value);
            section.Add(includeDepsToggle);
            
            // Recurse Folders
            var recurseToggle = CreateBulkToggle("Recurse Folders", allRecurse,
                profile => profile.recurseFolders,
                (profile, value) => profile.recurseFolders = value);
            section.Add(recurseToggle);
            
            // Generate Package JSON
            var generateJsonToggle = CreateBulkToggle("Generate package.json", allGenerateJson,
                profile => profile.generatePackageJson,
                (profile, value) => profile.generatePackageJson = value);
            section.Add(generateJsonToggle);
            
            // Version Management Section
            var versionMgmtTitle = new Label("Version Management");
            versionMgmtTitle.AddToClassList("yucp-section-title");
            versionMgmtTitle.style.marginTop = 16;
            versionMgmtTitle.style.marginBottom = 8;
            section.Add(versionMgmtTitle);
            
            bool allAutoIncrement = selectedProfiles.All(p => p.autoIncrementVersion);
            bool allBumpDirectives = selectedProfiles.All(p => p.bumpDirectivesInFiles);
            
            var autoIncrementToggle = CreateBulkToggle("Auto-Increment Version", allAutoIncrement,
                profile => profile.autoIncrementVersion,
                (profile, value) => profile.autoIncrementVersion = value);
            section.Add(autoIncrementToggle);
            
            // Increment Strategy (only if all have same value)
            var strategies = selectedProfiles.Select(p => p.incrementStrategy).Distinct().ToList();
            if (strategies.Count == 1)
            {
                var strategyRow = CreateFormRow("Increment Strategy");
                var strategyField = new EnumField(strategies[0]);
                strategyField.AddToClassList("yucp-form-field");
                strategyField.RegisterValueChangedCallback(evt =>
                {
                    ApplyToAllSelected(profile =>
                    {
                        Undo.RecordObject(profile, "Bulk Change Increment Strategy");
                        profile.incrementStrategy = (VersionIncrementStrategy)evt.newValue;
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                });
                strategyRow.Add(strategyField);
                section.Add(strategyRow);
            }
            
            var bumpDirectivesToggle = CreateBulkToggle("Bump @bump Directives in Files", allBumpDirectives,
                profile => profile.bumpDirectivesInFiles,
                (profile, value) => profile.bumpDirectivesInFiles = value);
            section.Add(bumpDirectivesToggle);
            
            // Custom Version Rule
            var customRules = selectedProfiles.Select(p => p.customVersionRule).Distinct().ToList();
            var ruleRow = CreateFormRow("Custom Version Rule");
            var ruleField = new ObjectField();
            ruleField.objectType = typeof(CustomVersionRule);
            ruleField.AddToClassList("yucp-form-field");
            if (customRules.Count == 1)
            {
                ruleField.value = customRules[0];
            }
            else
            {
                ruleField.value = null;
                // Add mixed label
                var mixedLabel = new Label(" (Mixed values)");
                mixedLabel.AddToClassList("yucp-label-secondary");
                mixedLabel.style.marginLeft = 4;
                ruleRow.Add(mixedLabel);
            }
            ruleField.RegisterValueChangedCallback(evt =>
            {
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Change Custom Version Rule");
                    profile.customVersionRule = evt.newValue as CustomVersionRule;
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            });
            ruleRow.Add(ruleField);
            section.Add(ruleRow);
            
            // Add Folders Section
            var foldersSection = CreateBulkFoldersSection(selectedProfiles);
            section.Add(foldersSection);
            
            // Add Dependencies Section
            var dependenciesSection = CreateBulkDependenciesSection(selectedProfiles);
            section.Add(dependenciesSection);
            
            // Add Exclusion Filters Section
            var exclusionSection = CreateBulkExclusionFiltersSection(selectedProfiles);
            section.Add(exclusionSection);
            
            // Add Permanent Ignore Folders Section
            var ignoreSection = CreateBulkPermanentIgnoreFoldersSection(selectedProfiles);
            section.Add(ignoreSection);
            
            // Add Obfuscation Section
            var obfuscationSection = CreateBulkObfuscationSection(selectedProfiles);
            section.Add(obfuscationSection);
            
            // Add Assembly Obfuscation Section
            var assemblySection = CreateBulkAssemblyObfuscationSection(selectedProfiles);
            section.Add(assemblySection);
            
            return section;
        }
        
        private VisualElement CreateBulkPermanentIgnoreFoldersSection(List<ExportProfile> selectedProfiles)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.style.marginTop = 16;
            
            var title = new Label("Permanent Ignore Folders");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var helpText = new Label("Folders permanently excluded from all exports");
            helpText.AddToClassList("yucp-label-secondary");
            helpText.style.marginBottom = 8;
            section.Add(helpText);
            
            var allIgnoreFolders = selectedProfiles
                .SelectMany(p => p.PermanentIgnoreFolders ?? new List<string>())
                .Distinct()
                .OrderBy(f => f)
                .ToList();
            
            var folderList = new VisualElement();
            folderList.style.maxHeight = 150;
            var scrollView = new ScrollView();
            
            foreach (var folder in allIgnoreFolders)
            {
                bool allHaveFolder = selectedProfiles.All(p => p.PermanentIgnoreFolders != null && p.PermanentIgnoreFolders.Contains(folder));
                bool someHaveFolder = selectedProfiles.Any(p => p.PermanentIgnoreFolders != null && p.PermanentIgnoreFolders.Contains(folder));
                
                var folderItem = CreateBulkStringListItem(folder, allHaveFolder, someHaveFolder,
                    (profile, value) =>
                    {
                        var ignoreFolders = profile.PermanentIgnoreFolders;
                        
                        if (value)
                        {
                            if (!ignoreFolders.Contains(folder))
                                ignoreFolders.Add(folder);
                        }
                        else
                        {
                            ignoreFolders.Remove(folder);
                        }
                    });
                scrollView.Add(folderItem);
            }
            
            folderList.Add(scrollView);
            section.Add(folderList);
            
            var addButton = new Button(() =>
            {
                string folderPath = EditorUtility.OpenFolderPanel("Select Folder to Ignore", Application.dataPath, "");
                if (!string.IsNullOrEmpty(folderPath))
                {
                    string relativePath = GetRelativePath(folderPath);
                    if (string.IsNullOrEmpty(relativePath))
                    {
                        EditorUtility.DisplayDialog("Invalid Path", "Please select a folder within the Unity project.", "OK");
                        return;
                    }
                    
                    ApplyToAllSelected(profile =>
                    {
                        Undo.RecordObject(profile, "Bulk Add Ignore Folder");
                        var ignoreFolders = profile.PermanentIgnoreFolders;
                        if (!ignoreFolders.Contains(relativePath))
                        {
                            ignoreFolders.Add(relativePath);
                        }
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                }
            }) { text = "+ Add Ignore Folder to All" };
            addButton.AddToClassList("yucp-button");
            addButton.AddToClassList("yucp-button-action");
            addButton.style.marginTop = 8;
            section.Add(addButton);
            
            return section;
        }
        
        private VisualElement CreateBulkAssemblyObfuscationSection(List<ExportProfile> selectedProfiles)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.style.marginTop = 16;
            
            var title = new Label("Assembly Obfuscation Settings");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var helpText = new Label("Configure which assemblies to obfuscate");
            helpText.AddToClassList("yucp-label-secondary");
            helpText.style.marginBottom = 8;
            section.Add(helpText);
            
            var allAssemblies = selectedProfiles
                .SelectMany(p => p.assembliesToObfuscate ?? new List<AssemblyObfuscationSettings>())
                .GroupBy(a => a.assemblyName)
                .Select(g => g.First())
                .OrderBy(a => a.assemblyName)
                .ToList();
            
            var assemblyList = new VisualElement();
            assemblyList.style.maxHeight = 200;
            var scrollView = new ScrollView();
            
            foreach (var assembly in allAssemblies)
            {
                var assemblyItem = new VisualElement();
                assemblyItem.AddToClassList("yucp-folder-item");
                
                bool allHaveAssembly = selectedProfiles.All(p => p.assembliesToObfuscate.Any(a => a.assemblyName == assembly.assemblyName));
                bool someHaveAssembly = selectedProfiles.Any(p => p.assembliesToObfuscate.Any(a => a.assemblyName == assembly.assemblyName));
                
                var checkbox = new Toggle();
                checkbox.value = allHaveAssembly;
                checkbox.AddToClassList("yucp-toggle");
                checkbox.RegisterValueChangedCallback(evt =>
                {
                    ApplyToAllSelected(profile =>
                    {
                        Undo.RecordObject(profile, "Bulk Change Assembly Obfuscation");
                        var existingAssembly = profile.assembliesToObfuscate.FirstOrDefault(a => a.assemblyName == assembly.assemblyName);
                        if (evt.newValue)
                        {
                            if (existingAssembly == null)
                            {
                                var newAssembly = new AssemblyObfuscationSettings
                                {
                                    assemblyName = assembly.assemblyName,
                                    enabled = assembly.enabled,
                                    asmdefPath = assembly.asmdefPath
                                };
                                profile.assembliesToObfuscate.Add(newAssembly);
                            }
                        }
                        else
                        {
                            if (existingAssembly != null)
                            {
                                profile.assembliesToObfuscate.Remove(existingAssembly);
                            }
                        }
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                });
                assemblyItem.Add(checkbox);
                
                var assemblyLabel = new Label($"{assembly.assemblyName} ({(assembly.enabled ? "Enabled" : "Disabled")})");
                assemblyLabel.AddToClassList("yucp-folder-item-path");
                if (!allHaveAssembly && someHaveAssembly)
                {
                    assemblyLabel.style.opacity = 0.7f;
                    var mixedLabel = new Label(" (Mixed)");
                    mixedLabel.AddToClassList("yucp-label-secondary");
                    mixedLabel.style.marginLeft = 4;
                    assemblyItem.Add(mixedLabel);
                }
                assemblyItem.Add(assemblyLabel);
                
                scrollView.Add(assemblyItem);
            }
            
            assemblyList.Add(scrollView);
            section.Add(assemblyList);
            
            var addButton = new Button(() =>
            {
                var newAssembly = new AssemblyObfuscationSettings
                {
                    assemblyName = "Assembly-CSharp",
                    enabled = true,
                    asmdefPath = ""
                };
                
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Add Assembly");
                    if (!profile.assembliesToObfuscate.Any(a => a.assemblyName == newAssembly.assemblyName))
                    {
                        var clonedAssembly = new AssemblyObfuscationSettings
                        {
                            assemblyName = newAssembly.assemblyName,
                            enabled = newAssembly.enabled,
                            asmdefPath = newAssembly.asmdefPath
                        };
                        profile.assembliesToObfuscate.Add(clonedAssembly);
                    }
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            }) { text = "+ Add Assembly to All" };
            addButton.AddToClassList("yucp-button");
            addButton.AddToClassList("yucp-button-action");
            addButton.style.marginTop = 8;
            section.Add(addButton);
            
            return section;
        }
        
        private VisualElement CreateBulkFoldersSection(List<ExportProfile> selectedProfiles)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.style.marginTop = 16;
            
            var title = new Label("Export Folders");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var helpText = new Label("Add or remove folders to/from all selected profiles");
            helpText.AddToClassList("yucp-label-secondary");
            helpText.style.marginBottom = 8;
            section.Add(helpText);
            
            // Get unique folders across all profiles
            var allFolders = selectedProfiles
                .SelectMany(p => p.foldersToExport ?? new List<string>())
                .Distinct()
                .OrderBy(f => f)
                .ToList();
            
            var folderList = new VisualElement();
            folderList.AddToClassList("yucp-folder-list");
            folderList.style.maxHeight = 200;
            folderList.style.overflow = Overflow.Hidden;
            
            var scrollView = new ScrollView();
            
            foreach (var folder in allFolders)
            {
                var folderItem = new VisualElement();
                folderItem.AddToClassList("yucp-folder-item");
                
                // Check if all profiles have this folder
                bool allHaveFolder = selectedProfiles.All(p => p.foldersToExport.Contains(folder));
                bool someHaveFolder = selectedProfiles.Any(p => p.foldersToExport.Contains(folder));
                
                var checkbox = new Toggle();
                checkbox.value = allHaveFolder;
                checkbox.AddToClassList("yucp-toggle");
                checkbox.RegisterValueChangedCallback(evt =>
                {
                    ApplyToAllSelected(profile =>
                    {
                        Undo.RecordObject(profile, "Bulk Change Folder");
                        if (evt.newValue)
                        {
                            if (!profile.foldersToExport.Contains(folder))
                            {
                                profile.foldersToExport.Add(folder);
                            }
                        }
                        else
                        {
                            profile.foldersToExport.Remove(folder);
                        }
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                });
                folderItem.Add(checkbox);
                
                var pathLabel = new Label(folder);
                pathLabel.AddToClassList("yucp-folder-item-path");
                if (!allHaveFolder && someHaveFolder)
                {
                    pathLabel.style.opacity = 0.7f;
                    var mixedLabel = new Label(" (Mixed)");
                    mixedLabel.AddToClassList("yucp-label-secondary");
                    mixedLabel.style.marginLeft = 4;
                    folderItem.Add(mixedLabel);
                }
                folderItem.Add(pathLabel);
                
                scrollView.Add(folderItem);
            }
            
            folderList.Add(scrollView);
            section.Add(folderList);
            
            // Add folder button
            var addButton = new Button(() => 
            {
                string folderPath = EditorUtility.OpenFolderPanel("Select Folder to Add", Application.dataPath, "");
                if (!string.IsNullOrEmpty(folderPath))
                {
                    // Convert to relative path
                    string relativePath = GetRelativePath(folderPath);
                    if (string.IsNullOrEmpty(relativePath))
                    {
                        EditorUtility.DisplayDialog("Invalid Path", "Please select a folder within the Unity project.", "OK");
                        return;
                    }
                    
                    ApplyToAllSelected(profile =>
                    {
                        Undo.RecordObject(profile, "Bulk Add Folder");
                        if (!profile.foldersToExport.Contains(relativePath))
                        {
                            profile.foldersToExport.Add(relativePath);
                        }
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                }
            }) { text = "+ Add Folder to All" };
            addButton.AddToClassList("yucp-button");
            addButton.AddToClassList("yucp-button-action");
            addButton.style.marginTop = 8;
            section.Add(addButton);
            
            return section;
        }
        
        private VisualElement CreateBulkDependenciesSection(List<ExportProfile> selectedProfiles)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.style.marginTop = 16;
            
            var title = new Label("Package Dependencies");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var helpText = new Label("Add or remove dependencies across all selected profiles");
            helpText.AddToClassList("yucp-label-secondary");
            helpText.style.marginBottom = 8;
            section.Add(helpText);
            
            // Get unique dependencies across all profiles
            var allDependencies = selectedProfiles
                .SelectMany(p => p.dependencies ?? new List<PackageDependency>())
                .GroupBy(d => d.packageName)
                .Select(g => g.First())
                .OrderBy(d => d.packageName)
                .ToList();
            
            var depsList = new VisualElement();
            depsList.AddToClassList("yucp-folder-list");
            depsList.style.maxHeight = 200;
            
            var scrollView = new ScrollView();
            
            foreach (var dep in allDependencies)
            {
                var depItem = new VisualElement();
                depItem.AddToClassList("yucp-folder-item");
                
                // Check if all profiles have this dependency and if it's enabled
                bool allHaveDep = selectedProfiles.All(p => p.dependencies.Any(d => d.packageName == dep.packageName));
                bool someHaveDep = selectedProfiles.Any(p => p.dependencies.Any(d => d.packageName == dep.packageName));
                int enabledCount = selectedProfiles.Count(p => p.dependencies.Any(d => d.packageName == dep.packageName && d.enabled));
                int totalCount = selectedProfiles.Count;
                
                var checkbox = new Toggle();
                checkbox.value = allHaveDep;
                checkbox.AddToClassList("yucp-toggle");
                checkbox.RegisterValueChangedCallback(evt =>
                {
                    ApplyToAllSelected(profile =>
                    {
                        Undo.RecordObject(profile, "Bulk Change Dependency");
                        var existingDep = profile.dependencies.FirstOrDefault(d => d.packageName == dep.packageName);
                        if (evt.newValue)
                        {
                            if (existingDep == null)
                            {
                                // Clone the dependency to add to this profile
                                var newDep = new PackageDependency(dep.packageName, dep.packageVersion, dep.displayName, dep.isVpmDependency);
                                newDep.enabled = dep.enabled;
                                newDep.exportMode = dep.exportMode;
                                profile.dependencies.Add(newDep);
                            }
                        }
                        else
                        {
                            if (existingDep != null)
                            {
                                profile.dependencies.Remove(existingDep);
                            }
                        }
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                });
                depItem.Add(checkbox);
                
                // Create container for label and status
                var labelContainer = new VisualElement();
                labelContainer.style.flexDirection = FlexDirection.Row;
                labelContainer.style.flexGrow = 1;
                labelContainer.style.alignItems = Align.Center;
                
                var depLabel = new Label($"{dep.displayName} ({dep.packageName}@{dep.packageVersion})");
                depLabel.AddToClassList("yucp-folder-item-path");
                depLabel.style.flexGrow = 1;
                if (!allHaveDep && someHaveDep)
                {
                    depLabel.style.opacity = 0.7f;
                }
                labelContainer.Add(depLabel);
                
                // Add status indicator showing how many profiles have this dependency enabled
                if (someHaveDep)
                {
                    var statusLabel = new Label();
                    statusLabel.AddToClassList("yucp-label-secondary");
                    statusLabel.style.marginLeft = 8;
                    statusLabel.style.fontSize = 10;
                    
                    if (allHaveDep)
                    {
                        if (enabledCount == totalCount)
                        {
                            statusLabel.text = $"[OK] All ({enabledCount}/{totalCount} enabled)";
                            statusLabel.style.color = new Color(0.3f, 0.8f, 0.3f);
                        }
                        else if (enabledCount == 0)
                        {
                            statusLabel.text = $"All ({enabledCount}/{totalCount} enabled)";
                            statusLabel.style.color = new Color(0.8f, 0.5f, 0.3f);
                        }
                        else
                        {
                            statusLabel.text = $"All ({enabledCount}/{totalCount} enabled)";
                            statusLabel.style.color = new Color(0.8f, 0.8f, 0.3f);
                        }
                    }
                    else
                    {
                        int haveCount = selectedProfiles.Count(p => p.dependencies.Any(d => d.packageName == dep.packageName));
                        statusLabel.text = $"Mixed ({haveCount}/{totalCount} have it, {enabledCount} enabled)";
                        statusLabel.style.color = new Color(0.7f, 0.7f, 0.7f);
                    }
                    labelContainer.Add(statusLabel);
                }
                
                depItem.Add(labelContainer);
                
                scrollView.Add(depItem);
            }
            
            depsList.Add(scrollView);
            section.Add(depsList);
            
            // Add dependency button
            var addButton = new Button(() => 
            {
                // Create a default dependency - users can edit it after adding
                var newDep = new PackageDependency("com.example.package", "1.0.0", "Example Package", false);
                
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Add Dependency");
                    // Check if a dependency with this name already exists
                    if (!profile.dependencies.Any(d => d.packageName == newDep.packageName))
                    {
                        // Clone the dependency for each profile
                        var clonedDep = new PackageDependency(newDep.packageName, newDep.packageVersion, newDep.displayName, newDep.isVpmDependency);
                        clonedDep.enabled = newDep.enabled;
                        clonedDep.exportMode = newDep.exportMode;
                        profile.dependencies.Add(clonedDep);
                    }
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            }) { text = "+ Add Dependency to All" };
            addButton.AddToClassList("yucp-button");
            addButton.AddToClassList("yucp-button-action");
            addButton.style.marginTop = 8;
            section.Add(addButton);
            
            return section;
        }
        
        private VisualElement CreateBulkExclusionFiltersSection(List<ExportProfile> selectedProfiles)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.style.marginTop = 16;
            
            var title = new Label("Exclusion Filters");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var helpText = new Label("Add or remove exclusion patterns across all selected profiles");
            helpText.AddToClassList("yucp-label-secondary");
            helpText.style.marginBottom = 8;
            section.Add(helpText);
            
            // File Patterns
            var filePatternsLabel = new Label("File Patterns");
            filePatternsLabel.AddToClassList("yucp-label");
            filePatternsLabel.style.marginTop = 8;
            filePatternsLabel.style.marginBottom = 4;
            filePatternsLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            section.Add(filePatternsLabel);
            
            var allFilePatterns = selectedProfiles
                .SelectMany(p => p.excludeFilePatterns ?? new List<string>())
                .Distinct()
                .OrderBy(p => p)
                .ToList();
            
            var filePatternsContainer = new VisualElement();
            filePatternsContainer.style.maxHeight = 150;
            var fileScrollView = new ScrollView();
            
            foreach (var pattern in allFilePatterns)
            {
                bool allHavePattern = selectedProfiles.All(p => p.excludeFilePatterns.Contains(pattern));
                bool someHavePattern = selectedProfiles.Any(p => p.excludeFilePatterns.Contains(pattern));
                
                var patternItem = CreateBulkStringListItem(pattern, allHavePattern, someHavePattern,
                    (profile, value) =>
                    {
                        if (value)
                        {
                            if (!profile.excludeFilePatterns.Contains(pattern))
                                profile.excludeFilePatterns.Add(pattern);
                        }
                        else
                        {
                            profile.excludeFilePatterns.Remove(pattern);
                        }
                    });
                fileScrollView.Add(patternItem);
            }
            
            filePatternsContainer.Add(fileScrollView);
            section.Add(filePatternsContainer);
            
            var addFilePatternButton = new Button(() =>
            {
                // Add a default pattern - users can edit it after adding
                string pattern = "*.tmp";
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Add File Pattern");
                    if (!profile.excludeFilePatterns.Contains(pattern))
                    {
                        profile.excludeFilePatterns.Add(pattern);
                    }
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            }) { text = "+ Add Pattern to All" };
            addFilePatternButton.AddToClassList("yucp-button");
            addFilePatternButton.style.marginBottom = 12;
            section.Add(addFilePatternButton);
            
            // Folder Names
            var folderNamesLabel = new Label("Folder Names");
            folderNamesLabel.AddToClassList("yucp-label");
            folderNamesLabel.style.marginTop = 8;
            folderNamesLabel.style.marginBottom = 4;
            folderNamesLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            section.Add(folderNamesLabel);
            
            var allFolderNames = selectedProfiles
                .SelectMany(p => p.excludeFolderNames ?? new List<string>())
                .Distinct()
                .OrderBy(f => f)
                .ToList();
            
            var folderNamesContainer = new VisualElement();
            folderNamesContainer.style.maxHeight = 150;
            var folderScrollView = new ScrollView();
            
            foreach (var folderName in allFolderNames)
            {
                bool allHaveFolder = selectedProfiles.All(p => p.excludeFolderNames.Contains(folderName));
                bool someHaveFolder = selectedProfiles.Any(p => p.excludeFolderNames.Contains(folderName));
                
                var folderItem = CreateBulkStringListItem(folderName, allHaveFolder, someHaveFolder,
                    (profile, value) =>
                    {
                        if (value)
                        {
                            if (!profile.excludeFolderNames.Contains(folderName))
                                profile.excludeFolderNames.Add(folderName);
                        }
                        else
                        {
                            profile.excludeFolderNames.Remove(folderName);
                        }
                    });
                folderScrollView.Add(folderItem);
            }
            
            folderNamesContainer.Add(folderScrollView);
            section.Add(folderNamesContainer);
            
            var addFolderNameButton = new Button(() =>
            {
                // Add a default folder name - users can edit it after adding
                string folderName = ".git";
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Add Folder Name");
                    if (!profile.excludeFolderNames.Contains(folderName))
                    {
                        profile.excludeFolderNames.Add(folderName);
                    }
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            }) { text = "+ Add Folder Name to All" };
            addFolderNameButton.AddToClassList("yucp-button");
            section.Add(addFolderNameButton);
            
            return section;
        }
        
        private VisualElement CreateBulkStringListItem(string value, bool allHave, bool someHave, 
            System.Action<ExportProfile, bool> toggleAction)
        {
            var item = new VisualElement();
            item.AddToClassList("yucp-folder-item");
            
            var checkbox = new Toggle();
            checkbox.value = allHave;
            checkbox.AddToClassList("yucp-toggle");
            checkbox.RegisterValueChangedCallback(evt =>
            {
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Change Exclusion");
                    toggleAction(profile, evt.newValue);
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            });
            item.Add(checkbox);
            
            var textField = new TextField { value = value };
            textField.AddToClassList("yucp-input");
            textField.style.flexGrow = 1;
            textField.isReadOnly = true;
            if (!allHave && someHave)
            {
                textField.style.opacity = 0.7f;
                var mixedLabel = new Label(" (Mixed)");
                mixedLabel.AddToClassList("yucp-label-secondary");
                mixedLabel.style.marginLeft = 4;
                item.Add(mixedLabel);
            }
            item.Add(textField);
            
            var removeButton = new Button(() =>
            {
                ApplyToAllSelected(profile =>
                {
                    Undo.RecordObject(profile, "Bulk Remove Exclusion");
                    toggleAction(profile, false);
                    EditorUtility.SetDirty(profile);
                });
                UpdateProfileDetails();
            }) { text = "×" };
            removeButton.AddToClassList("yucp-button");
            removeButton.AddToClassList("yucp-folder-item-remove");
            item.Add(removeButton);
            
            return item;
        }
        
        private VisualElement CreateBulkObfuscationSection(List<ExportProfile> selectedProfiles)
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            section.style.marginTop = 16;
            
            var title = new Label("Obfuscation Settings");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            bool allObfuscation = selectedProfiles.All(p => p.enableObfuscation);
            bool allStripDebug = selectedProfiles.All(p => p.stripDebugSymbols);
            
            var obfuscationToggle = CreateBulkToggle("Enable Obfuscation", allObfuscation,
                profile => profile.enableObfuscation,
                (profile, value) => profile.enableObfuscation = value);
            section.Add(obfuscationToggle);
            
            var stripDebugToggle = CreateBulkToggle("Strip Debug Symbols", allStripDebug,
                profile => profile.stripDebugSymbols,
                (profile, value) => profile.stripDebugSymbols = value);
            section.Add(stripDebugToggle);
            
            // Obfuscation Preset (only if all have same value)
            var presets = selectedProfiles.Select(p => p.obfuscationPreset).Distinct().ToList();
            if (presets.Count == 1)
            {
                var presetRow = CreateFormRow("Obfuscation Preset");
                var presetField = new EnumField(presets[0]);
                presetField.AddToClassList("yucp-form-field");
                presetField.RegisterValueChangedCallback(evt =>
                {
                    ApplyToAllSelected(profile =>
                    {
                        Undo.RecordObject(profile, "Bulk Change Obfuscation Preset");
                        profile.obfuscationPreset = (ConfuserExPreset)evt.newValue;
                        EditorUtility.SetDirty(profile);
                    });
                    UpdateProfileDetails();
                });
                presetRow.Add(presetField);
                section.Add(presetRow);
            }
            
            return section;
        }
        
        private VisualElement CreateBulkToggle(string label, bool allSame, 
            System.Func<ExportProfile, bool> getValue, 
            System.Action<ExportProfile, bool> setValue)
        {
            var container = new VisualElement();
            container.style.flexDirection = FlexDirection.Row;
            container.style.alignItems = Align.Center;
            container.style.marginBottom = 4;
            
            var toggle = new Toggle(label);
            toggle.AddToClassList("yucp-toggle");
            toggle.value = allSame;
            
            if (!allSame)
            {
                // When mixed, show indeterminate state but allow toggling
                var mixedLabel = new Label(" (Mixed - click to set all)");
                mixedLabel.AddToClassList("yucp-label-secondary");
                mixedLabel.style.marginLeft = 4;
                container.Add(mixedLabel);
            }
            
            toggle.RegisterValueChangedCallback(evt =>
            {
                // Apply the new value to all selected profiles
                bool newValue = evt.newValue;
                ApplyToAllSelected(profile => 
                {
                    Undo.RecordObject(profile, $"Bulk Toggle {label}");
                    setValue(profile, newValue);
                    EditorUtility.SetDirty(profile);
                });
                // Refresh to update UI
                UpdateProfileDetails();
            });
            
            container.Add(toggle);
            return container;
        }
        
        private void ApplyToAllSelected(System.Action<ExportProfile> action)
        {
            foreach (int index in selectedProfileIndices)
            {
                if (index >= 0 && index < allProfiles.Count)
                {
                    var profile = allProfiles[index];
                    if (profile != null)
                    {
                        action(profile);
                    }
                }
            }
            UpdateProfileDetails(); // Refresh to show changes
        }
        
        private VisualElement CreateMultiProfileSummarySection()
        {
            var section = new VisualElement();
            section.AddToClassList("yucp-section");
            
            var title = new Label("Selected Profiles");
            title.AddToClassList("yucp-section-title");
            section.Add(title);
            
            var list = new ScrollView();
            list.style.maxHeight = 300;
            
            foreach (int index in selectedProfileIndices.OrderBy(i => i))
            {
                if (index >= 0 && index < allProfiles.Count)
                {
                    var profile = allProfiles[index];
                    if (profile != null)
                    {
                        var item = new VisualElement();
                        item.style.flexDirection = FlexDirection.Row;
                        item.style.alignItems = Align.Center;
                        item.style.paddingTop = 4;
                        item.style.paddingBottom = 4;
                        item.style.paddingLeft = 8;
                        item.style.paddingRight = 8;
                        item.style.marginBottom = 2;
                        item.style.backgroundColor = new Color(0.1f, 0.1f, 0.1f);
                        
                        var nameLabel = new Label(GetProfileDisplayName(profile));
                        nameLabel.AddToClassList("yucp-label");
                        nameLabel.style.flexGrow = 1;
                        item.Add(nameLabel);
                        
                        var versionLabel = new Label($"v{profile.version}");
                        versionLabel.AddToClassList("yucp-label-secondary");
                        versionLabel.style.marginLeft = 8;
                        item.Add(versionLabel);
                        
                        list.Add(item);
                    }
                }
            }
            
            section.Add(list);
            return section;
        }
        
        private void CloseOverlay()
        {
            _isOverlayOpen = false;
            
            // Animate overlay out
            if (_leftPaneOverlay != null)
            {
                _leftPaneOverlay.style.left = -270;
                _leftPaneOverlay.style.opacity = 0;
            }
            
            // Fade out backdrop
            if (_overlayBackdrop != null)
            {
                _overlayBackdrop.style.opacity = 0;
            }
            
            // Hide after animation completes (300ms)
            rootVisualElement.schedule.Execute(() => 
            {
                if (_leftPaneOverlay != null && !_isOverlayOpen)
                {
                    _leftPaneOverlay.style.display = DisplayStyle.None;
                    _leftPaneOverlay.style.visibility = Visibility.Hidden;
                }
                if (_overlayBackdrop != null && !_isOverlayOpen)
                {
                    _overlayBackdrop.style.display = DisplayStyle.None;
                    _overlayBackdrop.style.visibility = Visibility.Hidden;
                }
            }).StartingIn(300);
        }
        
        // Animated GIF support
        private class AnimatedGifData
        {
            public List<Texture2D> frames = new List<Texture2D>();
            public List<float> frameDelays = new List<float>(); // Delay in seconds
            public int currentFrame = 0;
            public float timeSinceLastFrame = 0f;
            public VisualElement targetElement;
            public string gifPath;
            public bool isAnimating = false;
        }
        
        private void StartGifAnimation(VisualElement element, string gifPath)
        {
            if (string.IsNullOrEmpty(gifPath) || element == null)
                return;
                
            // Stop any existing animation for this element
            if (animatedGifs.ContainsKey(gifPath))
            {
                var existing = animatedGifs[gifPath];
                if (existing.targetElement == element && existing.isAnimating)
                {
                    return; // Already animating
                }
                else
                {
                    // Clean up old animation
                    existing.isAnimating = false;
                    animatedGifs.Remove(gifPath);
                }
            }
            
            // Try to extract frames from GIF file
            // Note: Unity's Texture2D.LoadImage only loads the first frame
            // For full animation, we need to parse the GIF file manually
            try
            {
                byte[] gifData = File.ReadAllBytes(gifPath);
                var frames = ExtractGifFrames(gifData);
                
                if (frames != null && frames.Count > 1)
                {
                    var gifData_obj = new AnimatedGifData
                    {
                        frames = frames,
                        frameDelays = ExtractGifDelays(gifData),
                        currentFrame = 0,
                        timeSinceLastFrame = 0f,
                        targetElement = element,
                        gifPath = gifPath,
                        isAnimating = true
                    };
                    
                    // Default delay if extraction fails
                    if (gifData_obj.frameDelays.Count == 0)
                    {
                        for (int i = 0; i < frames.Count; i++)
                        {
                            gifData_obj.frameDelays.Add(0.1f); // 100ms default
                        }
                    }
                    
                    animatedGifs[gifPath] = gifData_obj;
                    element.style.backgroundImage = new StyleBackground(frames[0]);
                    
                    // Start animation update loop
                    if (!EditorApplication.update.GetInvocationList().Contains(new System.Action(UpdateGifAnimations)))
                    {
                        EditorApplication.update += UpdateGifAnimations;
                    }
                }
                else
                {
                    // Single frame or extraction failed, just display first frame
                    Texture2D firstFrame = AssetDatabase.LoadAssetAtPath<Texture2D>(gifPath);
                    if (firstFrame != null)
                    {
                        element.style.backgroundImage = new StyleBackground(firstFrame);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[Package Exporter] Failed to load animated GIF at {gifPath}: {ex.Message}");
                // Fallback to first frame
                Texture2D firstFrame = AssetDatabase.LoadAssetAtPath<Texture2D>(gifPath);
                if (firstFrame != null)
                {
                    element.style.backgroundImage = new StyleBackground(firstFrame);
                }
            }
        }
        
        private void UpdateGifAnimations()
        {
            if (animatedGifs.Count == 0)
            {
                EditorApplication.update -= UpdateGifAnimations;
                return;
            }
            
            float currentTime = (float)EditorApplication.timeSinceStartup;
            float deltaTime = currentTime - (lastGifUpdateTime > 0 ? lastGifUpdateTime : currentTime);
            lastGifUpdateTime = currentTime;
            
            var keysToRemove = new List<string>();
            foreach (var kvp in animatedGifs.ToList())
            {
                var gif = kvp.Value;
                if (!gif.isAnimating || gif.targetElement == null || gif.frames.Count == 0)
                {
                    keysToRemove.Add(kvp.Key);
                    continue;
                }
                
                gif.timeSinceLastFrame += deltaTime;
                
                if (gif.timeSinceLastFrame >= gif.frameDelays[gif.currentFrame])
                {
                    gif.currentFrame = (gif.currentFrame + 1) % gif.frames.Count;
                    gif.timeSinceLastFrame = 0f;
                    
                    if (gif.targetElement != null && gif.frames[gif.currentFrame] != null)
                    {
                        gif.targetElement.style.backgroundImage = new StyleBackground(gif.frames[gif.currentFrame]);
                    }
                }
            }
            
            foreach (var key in keysToRemove)
            {
                animatedGifs.Remove(key);
            }
        }
        
        private float lastGifUpdateTime = 0f;
        
        // Basic GIF frame extraction (simplified - handles common cases)
        private List<Texture2D> ExtractGifFrames(byte[] gifData)
        {
            var frames = new List<Texture2D>();
            
            // Unity's Texture2D.LoadImage can only load the first frame
            // For full GIF support, you would need a proper GIF decoder library
            // This is a basic implementation that attempts to extract frames
            
            try
            {
                // Try to load first frame using Unity's built-in loader
                Texture2D firstFrame = new Texture2D(2, 2);
                if (firstFrame.LoadImage(gifData))
                {
                    frames.Add(firstFrame);
                }
                
                // For additional frames, we would need to parse the GIF file structure
                // This requires implementing a GIF decoder or using a library
                // For now, we'll return just the first frame
                // A proper implementation would:
                // 1. Parse GIF header
                // 2. Extract each frame's image data
                // 3. Decompress using LZW
                // 4. Convert to Texture2D
                
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[Package Exporter] Failed to extract GIF frames: {ex.Message}");
            }
            
            return frames;
        }
        
        private List<float> ExtractGifDelays(byte[] gifData)
        {
            var delays = new List<float>();
            
            // Extract frame delays from GIF file
            // This requires parsing the GIF file structure
            // For now, return empty list (will use default delays)
            
            return delays;
        }
    }
}
